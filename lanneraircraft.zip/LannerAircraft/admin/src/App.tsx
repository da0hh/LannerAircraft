import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Modal } from "@/components/Modal";
import { Field } from "@/components/Field";

interface Banner {
  id: string;
  title: string;
  image_url: string;
  link: string | null;
  position: number;
  is_active: boolean;
}

const emptyBanner = { title: "", image_url: "", link: "", is_active: true };

export function BannersPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyBanner);
  const [saving, setSaving] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-banners"],
    queryFn: () => api.get<Banner[]>("/admin/banners"),
  });

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const upload = async (file: File) => {
    const res = await api.upload<{ url: string }>("/admin/upload", file);
    set("image_url", res.url);
  };

  const save = async () => {
    setSaving(true);
    try {
      await api.post("/admin/banners", {
        title: form.title,
        image_url: form.image_url,
        link: form.link || null,
        is_active: form.is_active,
      });
      await qc.invalidateQueries({ queryKey: ["admin-banners"] });
      setOpen(false);
      setForm(emptyBanner);
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (b: Banner) => {
    await api.patch(`/admin/banners/${b.id}`, { is_active: !b.is_active });
    await qc.invalidateQueries({ queryKey: ["admin-banners"] });
  };

  const remove = async (b: Banner) => {
    if (!confirm("Удалить баннер?")) return;
    await api.del(`/admin/banners/${b.id}`);
    await qc.invalidateQueries({ queryKey: ["admin-banners"] });
  };

  return (
    <div className="page">
      <div className="page__header">
        <h1 className="page__title">Баннеры</h1>
        <button className="btn btn--primary" onClick={() => setOpen(true)}>+ Добавить</button>
      </div>

      {isLoading ? (
        <div className="loading">Загрузка…</div>
      ) : (
        <div className="banners-admin">
          {(data ?? []).map((b) => (
            <div key={b.id} className={`banner-admin ${!b.is_active ? "banner-admin--off" : ""}`}>
              <img src={b.image_url} alt={b.title} />
              <div className="banner-admin__overlay">
                <span className="banner-admin__title">{b.title}</span>
                <div className="banner-admin__actions">
                  <button className="btn btn--sm" onClick={() => toggle(b)}>
                    {b.is_active ? "Скрыть" : "Показать"}
                  </button>
                  <button className="btn btn--sm btn--danger" onClick={() => remove(b)}>Удалить</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={open}
        title="Новый баннер"
        onClose={() => setOpen(false)}
        footer={
          <>
            <button className="btn btn--secondary" onClick={() => setOpen(false)}>Отмена</button>
            <button className="btn btn--primary" onClick={save} disabled={saving || !form.title || !form.image_url}>
              {saving ? "Сохранение…" : "Создать"}
            </button>
          </>
        }
      >
        <Field label="Заголовок">
          <input value={form.title} onChange={(e) => set("title", e.target.value)} />
        </Field>
        <Field label="Ссылка (deep-link или slug)" hint="Необязательно">
          <input value={form.link} onChange={(e) => set("link", e.target.value)} placeholder="/product/... или slug" />
        </Field>
        <Field label="Изображение">
          {form.image_url ? (
            <div className="image-item image-item--single">
              <img src={form.image_url} alt="" />
              <button className="image-item__del" onClick={() => set("image_url", "")}>×</button>
            </div>
          ) : (
            <label className="image-upload image-upload--wide">
              Загрузить изображение
              <input
                type="file"
                accept="image/*"
                hidden
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) upload(f);
                  e.target.value = "";
                }}
              />
            </label>
          )}
        </Field>
      </Modal>
    </div>
  );
}