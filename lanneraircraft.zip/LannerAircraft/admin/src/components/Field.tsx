import type { ReactNode } from "react";

interface Props {
  label: string;
  children: ReactNode;
  hint?: string;
}

export function Field({ label, children, hint }: Props) {
  return (
    <div className="field">
      <label className="field__label">{label}</label>
      {children}
      {hint && <div className="field__hint">{hint}</div>}
    </div>
  );
}