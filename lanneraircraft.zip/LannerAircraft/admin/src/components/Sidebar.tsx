import { NavLink } from "react-router-dom";
import { useAuth } from "@/store/auth";

const links = [
  { to: "/", label: "Дашборд", icon: "📊", end: true },
  { to: "/products", label: "Товары", icon: "👕" },
  { to: "/orders", label: "Заказы", icon: "📦" },
  { to: "/promos", label: "Промокоды", icon: "🎟️" },
  { to: "/banners", label: "Баннеры", icon: "🖼️" },
];

export function Sidebar() {
  const { user, logout } = useAuth();
  return (
    <aside className="sidebar">
      <div className="sidebar__logo">TeeShop</div>
      <nav className="sidebar__nav">
        {links.map((l) => (
          <NavLink
            key={l.to}
            to={l.to}
            end={l.end}
            className={({ isActive }) =>
              `sidebar__link ${isActive ? "sidebar__link--active" : ""}`
            }
          >
            <span>{l.icon}</span>
            <span>{l.label}</span>
          </NavLink>
        ))}
      </nav>
      <div className="sidebar__footer">
        <div className="sidebar__user">{user?.name ?? user?.email}</div>
        <button className="sidebar__logout" onClick={logout}>Выйти</button>
      </div>
    </aside>
  );
}