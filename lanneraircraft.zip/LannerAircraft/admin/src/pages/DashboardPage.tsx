import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { formatPrice, formatDateTime, STATUS_LABELS } from "@/lib/format";
import { useNavigate } from "react-router-dom";

interface Stats {
  orders_total: number;
  orders_today: number;
  revenue_total: string;
  revenue_today: string;
  pending_orders: number;
  low_stock_count: number;
  recent_orders: {
    id: string;
    number: number;
    total: string;
    status: string;
    customer_name: string;
    created_at: string;
  }[];
}

export function DashboardPage() {
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: () => api.get<Stats>("/admin/stats"),
  });

  if (isLoading || !data) return <div className="loading">Загрузка…</div>;

  const cards = [
    { label: "Заказов всего", value: data.orders_total },
    { label: "Заказов сегодня", value: data.orders_today },
    { label: "Выручка всего", value: formatPrice(data.revenue_total) },
    { label: "Выручка сегодня", value: formatPrice(data.revenue_today) },
    { label: "Ожидают обработки", value: data.pending_orders, warn: data.pending_orders > 0 },
    { label: "Мало на складе", value: data.low_stock_count, warn: data.low_stock_count > 0 },
  ];

  return (
    <div className="page">
      <h1 className="page__title">Дашборд</h1>
      <div className="stat-grid">
        {cards.map((c) => (
          <div key={c.label} className={`stat-card ${c.warn ? "stat-card--warn" : ""}`}>
            <div className="stat-card__value">{c.value}</div>
            <div className="stat-card__label">{c.label}</div>
          </div>
        ))}
      </div>

      <h2 className="section-title">Последние заказы</h2>
      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              <th>№</th><th>Клиент</th><th>Сумма</th><th>Статус</th><th>Дата</th>
            </tr>
          </thead>
          <tbody>
            {data.recent_orders.map((o) => (
              <tr
                key={o.id}
                className="table__row--clickable"
                onClick={() => navigate(`/orders/${o.id}`)}
              >
                <td>#{o.number}</td>
                <td>{o.customer_name}</td>
                <td>{formatPrice(o.total)}</td>
                <td><span className={`badge badge--${o.status}`}>{STATUS_LABELS[o.status]}</span></td>
                <td>{formatDateTime(o.created_at)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}