import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { formatPrice, formatDateTime, STATUS_LABELS, ORDER_STATUSES } from "@/lib/format";

interface OrderItem {
  product_name: string;
  color_name: string;
  size_label: string;
  quantity: number;
  unit_price: string;
  image_url: string | null;
}

interface OrderDetail {
  id: string;
  number: number;
  status: string;
  subtotal: string;
  discount: string;
  delivery_cost: string;
  total: string;
  promo_code: string | null;
  created_at: string;
  customer: { first_name: string; last_name: string; phone: string; telegram_id: number };
  delivery: { method: string; address: string | null; pvz_code: string | null; comment: string | null; tracking: string | null };
  items: OrderItem[];
}

export function OrderDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["admin-order", id],
    queryFn: () => api.get<OrderDetail>(`/admin/orders/${id}`),
  });

  const [status, setStatus] = useState("");
  const [tracking, setTracking] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (data) {
      setStatus(data.status);
      setTracking(data.delivery.tracking ?? "");
    }
  }, [data]);

  const save = async () => {
    setSaving(true);
    try {
      await api.patch(`/admin/orders/${id}`, { status, tracking: tracking || null });
      await qc.invalidateQueries({ queryKey: ["admin-order", id] });
      await qc.invalidateQueries({ queryKey: ["admin-orders"] });
    } finally {
      setSaving(false);
    }
  };

  if (isLoading || !data) return <div className="loading">Загрузка…</div>;

  return (
    <div className="page">
      <button className="btn btn--secondary btn--back" onClick={() => navigate("/orders")}>
        ← К заказам
      </button>
      <h1 className="page__title">Заказ #{data.number}</h1>
      <div className="muted">{formatDateTime(data.created_at)}</div>

      <div className="detail-grid">
        <div className="panel">
          <h3>Состав заказа</h3>
          {data.items.map((it, i) => (
            <div key={i} className="detail-line">
              <div className="detail-line__img">
                {it.image_url ? <img src={it.image_url} alt="" /> : <div className="thumb-cell__ph" />}
              </div>
              <div className="detail-line__body">
                <div>{it.product_name}</div>
                <div className="muted">{it.color_name} · {it.size_label} · {it.quantity} шт.</div>
              </div>
              <div>{formatPrice(it.unit_price)}</div>
            </div>
          ))}
          <div className="totals">
            <div><span>Товары</span><span>{formatPrice(data.subtotal)}</span></div>
            {parseFloat(data.discount) > 0 && (
              <div><span>Скидка{data.promo_code ? ` (${data.promo_code})` : ""}</span><span>−{formatPrice(data.discount)}</span></div>
            )}
            <div><span>Доставка</span><span>{formatPrice(data.delivery_cost)}</span></div>
            <div className="totals__total"><span>Итого</span><span>{formatPrice(data.total)}</span></div>
          </div>
        </div>

        <div className="panel">
          <h3>Клиент</h3>
          <div className="kv"><span>Имя</span><span>{data.customer.first_name} {data.customer.last_name}</span></div>
          <div className="kv"><span>Телефон</span><span>{data.customer.phone}</span></div>
          <div className="kv"><span>Telegram ID</span><span>{data.customer.telegram_id}</span></div>

          <h3>Доставка</h3>
          <div className="kv"><span>Способ</span><span>{data.delivery.method}</span></div>
          {data.delivery.address && <div className="kv"><span>Адрес</span><span>{data.delivery.address}</span></div>}
          {data.delivery.pvz_code && <div className="kv"><span>ПВЗ</span><span>{data.delivery.pvz_code}</span></div>}
          {data.delivery.comment && <div className="kv"><span>Комментарий</span><span>{data.delivery.comment}</span></div>}

          <h3>Управление</h3>
          <label className="field__label">Статус</label>
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            {ORDER_STATUSES.map((s) => (
              <option key={s} value={s}>{STATUS_LABELS[s]}</option>
            ))}
          </select>
          <label className="field__label">Трек-номер</label>
          <input value={tracking} onChange={(e) => setTracking(e.target.value)} placeholder="Трек-номер" />
          <button className="btn btn--primary" onClick={save} disabled={saving} style={{ marginTop: 12 }}>
            {saving ? "Сохранение…" : "Сохранить"}
          </button>
        </div>
      </div>
    </div>
  );
}