import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { api } from "@/lib/api";
import { Table } from "@/components/Table";
import { formatPrice, formatDateTime, STATUS_LABELS, ORDER_STATUSES } from "@/lib/format";

interface AdminOrder {
  id: string;
  number: number;
  customer_name: string;
  phone: string;
  total: string;
  status: string;
  delivery_method: string;
  created_at: string;
}

export function OrdersPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<string>("");

  const { data, isLoading } = useQuery({
    queryKey: ["admin-orders", status],
    queryFn: () =>
      api.get<AdminOrder[]>(`/admin/orders${status ? `?status=${status}` : ""}`),
  });

  return (
    <div className="page">
      <h1 className="page__title">Заказы</h1>

      <div className="filter-chips">
        <button className={`chip ${!status ? "chip--active" : ""}`} onClick={() => setStatus("")}>
          Все
        </button>
        {ORDER_STATUSES.map((s) => (
          <button
            key={s}
            className={`chip ${status === s ? "chip--active" : ""}`}
            onClick={() => setStatus(s)}
          >
            {STATUS_LABELS[s]}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="loading">Загрузка…</div>
      ) : (
        <Table<AdminOrder>
          rows={data ?? []}
          onRowClick={(r) => navigate(`/orders/${r.id}`)}
          columns={[
            { key: "number", header: "№", render: (r) => `#${r.number}` },
            { key: "customer_name", header: "Клиент" },
            { key: "phone", header: "Телефон" },
            { key: "total", header: "Сумма", render: (r) => formatPrice(r.total) },
            { key: "delivery_method", header: "Доставка" },
            {
              key: "status", header: "Статус",
              render: (r) => <span className={`badge badge--${r.status}`}>{STATUS_LABELS[r.status]}</span>,
            },
            { key: "created_at", header: "Дата", render: (r) => formatDateTime(r.created_at) },
          ]}
        />
      )}
    </div>
  );
}