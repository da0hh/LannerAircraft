import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Field } from "@/components/Field";

interface Category { id: string; name: string; }
interface Color { id: string; name: string; hex: string; }
interface Size { id: string; label: string; }

interface Variant {
  id?: string;
  color_id: string;
  size_id: string;
  stock: number;
}

interface ProductImage { id?: string; url: string; position: number; }

interface ProductForm {
  name: string;
  sku: string;
  description: string;
  composition: string;
  density: string;
  care: string;
  price: string;
  category_id: string | null;
  is_active: boolean;
  images: ProductImage[];
  variants: Variant[];
}

const empty: ProductForm = {
  name: "", sku: "", description: "", composition: "",
  density: "", care: "", price: "", category_id: null,
  is_active: true, images: [], variants: [],
};

export function ProductEditPage() {
  const { id } = useParams();
  const isNew = id === "new";
  const navigate = useNavigate();
  const qc = useQueryClient();

  const [form, setForm] = useState<ProductForm>(empty);
  const [saving, setSaving] = useState(false);

  const { data: refs } = useQuery({
    queryKey: ["product-refs"],
    queryFn: async () => ({
      categories: await api.get<Category[]>("/admin/categories"),
      colors: await api.get<Color[]>("/admin/colors"),
      sizes: await api.get<Size[]>("/admin/sizes"),
    }),
  });

  const { data: product } = useQuery({
    queryKey: ["admin-product", id],
    queryFn: () => api.get<ProductForm>(`/admin/products/${id}`),
    enabled: !isNew,
  });

  useEffect(() => {
    if (product) setForm(product);
  }, [product]);

  const set = <K extends keyof ProductForm>(key: K, val: ProductForm[K]) =>
    setForm((f) => ({ ...f, [key]: val }));

  const addVariant = () =>
    set("variants", [...form.variants, { color_id: "", size_id: "", stock: 0 }]);

  const updateVariant = (i: number, patch: Partial<Variant>) =>
    set("variants", form.variants.map((v, idx) => (idx === i ? { ...v, ...patch } : v)));

  const removeVariant = (i: number) =>
    set("variants", form.variants.filter((_, idx) => idx !== i));

  const handleUpload = async (file: File) => {
    const res = await api.upload<{ url: string }>("/admin/upload", file);
    set("images", [...form.images, { url: res.url, position: form.images.length }]);
  };

  const removeImage = (i: number) =>
    set("images", form.images.filter((_, idx) => idx !== i));

  const save = async () => {
    setSaving(true);
    try {
      const payload = {
        ...form,
        price: form.price,
        images: form.images.map((img, i) => ({ ...img, position: i })),
      };
      if (isNew) {
        const created = await api.post<{ id: string }>("/admin/products", payload);
        await qc.invalidateQueries({ queryKey: ["admin-products"] });
        navigate(`/products/${created.id}`);
      } else {
        await api.put(`/admin/products/${id}`, payload);
        await qc.invalidateQueries({ queryKey: ["admin-products"] });
        await qc.invalidateQueries({ queryKey: ["admin-product", id] });
      }
    } finally {
      setSaving(false);
    }
  };

  const remove = async () => {
    if (!confirm("Удалить товар?")) return;
    await api.del(`/admin/products/${id}`);
    await qc.invalidateQueries({ queryKey: ["admin-products"] });
    navigate("/products");
  };

  return (
    <div className="page">
      <div className="page__header">
        <h1 className="page__title">{isNew ? "Новый товар" : form.name || "Товар"}</h1>
        <div className="btn-row">
          {!isNew && <button className="btn btn--danger" onClick={remove}>Удалить</button>}
          <button className="btn btn--primary" onClick={save} disabled={saving}>
            {saving ? "Сохранение…" : "Сохранить"}
          </button>
        </div>
      </div>

      <div className="edit-grid">
        <div className="edit-col">
          <Field label="Название">
            <input value={form.name} onChange={(e) => set("name", e.target.value)} />
          </Field>
          <Field label="Артикул (SKU)">
            <input value={form.sku} onChange={(e) => set("sku", e.target.value)} />
          </Field>
          <Field label="Цена, ₽">
            <input type="number" value={form.price} onChange={(e) => set("price", e.target.value)} />
          </Field>
          <Field label="Категория">
            <select
              value={form.category_id ?? ""}
              onChange={(e) => set("category_id", e.target.value || null)}
            >
              <option value="">— не выбрана —</option>
              {refs?.categories.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </Field>
          <Field label="Описание">
            <textarea value={form.description} onChange={(e) => set("description", e.target.value)} />
          </Field>
          <Field label="Состав">
            <input value={form.composition} onChange={(e) => set("composition", e.target.value)} />
          </Field>
          <Field label="Плотность">
            <input value={form.density} onChange={(e) => set("density", e.target.value)} />
          </Field>
          <Field label="Уход">
            <textarea value={form.care} onChange={(e) => set("care", e.target.value)} />
          </Field>
          <Field label="Статус">
            <label className="checkbox">
              <input
                type="checkbox"
                checked={form.is_active}
                onChange={(e) => set("is_active", e.target.checked)}
              />
              Активен (виден в каталоге)
            </label>
          </Field>
        </div>

        <div className="edit-col">
          <h3 className="section-title">Изображения</h3>
          <div className="images-grid">
            {form.images.map((img, i) => (
              <div key={i} className="image-item">
                <img src={img.url} alt="" />
                <button className="image-item__del" onClick={() => removeImage(i)}>×</button>
              </div>
            ))}
            <label className="image-upload">
              +
              <input
                type="file"
                accept="image/*"
                hidden
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleUpload(f);
                  e.target.value = "";
                }}
              />
            </label>
          </div>

          <h3 className="section-title">Варианты (цвет × размер × остаток)</h3>
          <div className="variants">
            {form.variants.map((v, i) => (
              <div key={i} className="variant-row">
                <select value={v.color_id} onChange={(e) => updateVariant(i, { color_id: e.target.value })}>
                  <option value="">Цвет</option>
                  {refs?.colors.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
                <select value={v.size_id} onChange={(e) => updateVariant(i, { size_id: e.target.value })}>
                  <option value="">Размер</option>
                  {refs?.sizes.map((s) => (
                    <option key={s.id} value={s.id}>{s.label}</option>
                  ))}
                </select>
                <input
                  type="number"
                  placeholder="Остаток"
                  value={v.stock}
                  onChange={(e) => updateVariant(i, { stock: parseInt(e.target.value) || 0 })}
                />
                <button className="btn btn--icon" onClick={() => removeVariant(i)}>×</button>
              </div>
            ))}
          </div>
          <button className="btn btn--secondary" onClick={addVariant}>+ Добавить вариант</button>
        </div>
      </div>
    </div>
  );
}