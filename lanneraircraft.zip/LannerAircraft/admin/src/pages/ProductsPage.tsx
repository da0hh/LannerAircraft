import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { api } from "@/lib/api";
import { Table } from "@/components/Table";
import { formatPrice } from "@/lib/format";

interface AdminProduct {
  id: string;
  name: string;
  sku: string;
  price: string;
  category_name: string | null;
  total_stock: number;
  is_active: boolean;
  image_url: string | null;
}

export function ProductsPage() {
  const navigate = useNavigate();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-products"],
    queryFn: () => api.get<AdminProduct[]>("/admin/products"),
  });

  return (
    <div className="page">
      <div className="page__header">
        <h1 className="page__title">Товары</h1>
        <button className="btn btn--primary" onClick={() => navigate("/products/new")}>
          + Добавить товар
        </button>
      </div>

      {isLoading ? (
        <div className="loading">Загрузка…</div>
      ) : (
        <Table<AdminProduct>
          rows={data ?? []}
          onRowClick={(row) => navigate(`/products/${row.id}`)}
          columns={[
            {
              key: "image", header: "", width: "56px",
              render: (r) => (
                <div className="thumb-cell">
                  {r.image_url ? <img src={r.image_url} alt="" /> : <div className="thumb-cell__ph" />}
                </div>
              ),
            },
            { key: "name", header: "Название" },
            { key: "sku", header: "Артикул" },
            { key: "category_name", header: "Категория", render: (r) => r.category_name ?? "—" },
            { key: "price", header: "Цена", render: (r) => formatPrice(r.price) },
            {
              key: "total_stock", header: "Остаток",
              render: (r) => (
                <span className={r.total_stock < 10 ? "text-warn" : ""}>{r.total_stock}</span>
              ),
            },
            {
              key: "is_active", header: "Статус",
              render: (r) => (
                <span className={`badge ${r.is_active ? "badge--paid" : "badge--cancelled"}`}>
                  {r.is_active ? "Активен" : "Скрыт"}
                </span>
              ),
            },
          ]}
        />
      )}
    </div>
  );
}