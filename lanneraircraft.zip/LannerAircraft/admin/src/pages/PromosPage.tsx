import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Table } from "@/components/Table";
import { Modal } from "@/components/Modal";
import { Field } from "@/components/Field";
import { formatPrice, formatDateTime } from "@/lib/format";

interface Promo {
  id: string;
  code: string;
  discount_type: "percent" | "fixed";
  discount_value: string;
  min_subtotal: string | null;
  max_uses: number | null;
  used_count: number;
  expires_at: string | null;
  is_active: boolean;
}

const emptyPromo = {
  code: "",
  discount_type: "percent" as "percent" | "fixed",
  discount_value: "",
  min_subtotal: "",
  max_uses: "",
  expires_at: "",
  is_active: true,
};

export function PromosPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(emptyPromo);
  const [saving, setSaving] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-promos"],
    queryFn: () => api.get<Promo[]>("/admin/promos"),
  });

  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const save = async () => {
    setSaving(true);
    try {
      await api.post("/admin/promos", {
        code: form.code.trim().toUpperCase(),
        discount_type: form.discount_type,
        discount_value: form.discount_value,
        min_subtotal: form.min_subtotal || null,
        max_uses: form.max_uses ? parseInt(form.max_uses) : null,
        expires_at: form.expires_at || null,
        is_active: form.is_active,
      });
      await qc.invalidateQueries({ queryKey: ["admin-promos"] });
      setOpen(false);
      setForm(emptyPromo);
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (p: Promo) => {
    await api.patch(`/admin/promos/${p.id}`, { is_active: !p.is_active });
    await qc.invalidateQueries({ queryKey: ["admin-promos"] });
  };

  const remove = async (p: Promo) => {
    if (!confirm(`Удалить промокод ${p.code}?`)) return;
    await api.del(`/admin/promos/${p.id}`);
    await qc.invalidateQueries({ queryKey: ["admin-promos"] });
  };

  return (
    <div className="page">
      <div className="page__header">
        <h1 className="page__title">Промокоды</h1>
        <button className="btn btn--primary" onClick={() => setOpen(true)}>+ Создать</button>
      </div>

      {isLoading ? (
        <div className="loading">Загрузка…</div>
      ) : (
        <Table<Promo>
          rows={data ?? []}
          columns={[
            { key: "code", header: "Код", render: (r) => <b>{r.code}</b> },
            {
              key: "discount", header: "Скидка",
              render: (r) => r.discount_type === "percent"
                ? `${r.discount_value}%`
                : formatPrice(r.discount_value),
            },
            {
              key: "min_subtotal", header: "Мин. сумма",
              render: (r) => r.min_subtotal ? formatPrice(r.min_subtotal) : "—",
            },
            {
              key: "uses", header: "Использований",
              render: (r) => `${r.used_count}${r.max_uses ? ` / ${r.max_uses}` : ""}`,
            },
            {
              key: "expires_at", header: "Действует до",
              render: (r) => r.expires_at ? formatDateTime(r.expires_at) : "—",
            },
            {
              key: "is_active", header: "Статус",
              render: (r) => (
                <button
                  className={`badge ${r.is_active ? "badge--paid" : "badge--cancelled"}`}
                  onClick={() => toggle(r)}
                >
                  {r.is_active ? "Активен" : "Выключен"}
                </button>
              ),
            },
            {
              key: "actions", header: "",
              render: (r) => (
                <button className="btn btn--icon btn--danger" onClick={() => remove(r)}>×</button>
              ),
            },
          ]}
        />
      )}

      <Modal
        open={open}
        title="Новый промокод"
        onClose={() => setOpen(false)}
        footer={
          <>
            <button className="btn btn--secondary" onClick={() => setOpen(false)}>Отмена</button>
            <button className="btn btn--primary" onClick={save} disabled={saving || !form.code || !form.discount_value}>
              {saving ? "Сохранение…" : "Создать"}
            </button>
          </>
        }
      >
        <Field label="Код">
          <input value={form.code} onChange={(e) => set("code", e.target.value.toUpperCase())} placeholder="SALE20" />
        </Field>
        <Field label="Тип скидки">
          <select value={form.discount_type} onChange={(e) => set("discount_type", e.target.value as "percent" | "fixed")}>
            <option value="percent">Процент</option>
            <option value="fixed">Фиксированная сумма</option>
          </select>
        </Field>
        <Field label={form.discount_type === "percent" ? "Процент (%)" : "Сумма (₽)"}>
          <input type="number" value={form.discount_value} onChange={(e) => set("discount_value", e.target.value)} />
        </Field>
        <Field label="Минимальная сумма заказа (₽)" hint="Необязательно">
          <input type="number" value={form.min_subtotal} onChange={(e) => set("min_subtotal", e.target.value)} />
        </Field>
        <Field label="Лимит использований" hint="Пусто = без лимита">
          <input type="number" value={form.max_uses} onChange={(e) => set("max_uses", e.target.value)} />
        </Field>
        <Field label="Действует до" hint="Необязательно">
          <input type="datetime-local" value={form.expires_at} onChange={(e) => set("expires_at", e.target.value)} />
        </Field>
      </Modal>
    </div>
  );
}