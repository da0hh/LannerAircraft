import { create } from "zustand";
import { api } from "@/lib/api";

interface AdminUser {
  id: string;
  email: string;
  name: string;
}

interface AuthState {
  user: AdminUser | null;
  token: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  fetchMe: () => Promise<void>;
}

export const useAuth = create<AuthState>((set) => ({
  user: null,
  token: localStorage.getItem("admin_token"),
  loading: false,

  login: async (email, password) => {
    set({ loading: true });
    try {
      const res = await api.post<{ token: string; user: AdminUser }>(
        "/admin/auth/login",
        { email, password }
      );
      localStorage.setItem("admin_token", res.token);
      set({ token: res.token, user: res.user });
    } finally {
      set({ loading: false });
    }
  },

  logout: () => {
    localStorage.removeItem("admin_token");
    set({ token: null, user: null });
    location.href = "/login";
  },

  fetchMe: async () => {
    try {
      const user = await api.get<AdminUser>("/admin/auth/me");
      set({ user });
    } catch {
      set({ user: null, token: null });
    }
  },
}));