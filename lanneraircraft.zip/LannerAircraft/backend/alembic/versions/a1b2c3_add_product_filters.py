"""add product filter fields

Revision ID: a1b2c3d4e5f6
Revises: 51006cc0dab5
Create Date: 2024-01-01 00:00:00
"""
from alembic import op
import sqlalchemy as sa

revision = "a1b2c3d4e5f6"
down_revision = "51006cc0dab5"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("products", sa.Column("type", sa.String(16), nullable=True))
    op.add_column("products", sa.Column("gender", sa.String(16), nullable=True))
    op.add_column("products", sa.Column("fit", sa.String(16), nullable=True))
    op.add_column("products", sa.Column("neckline", sa.String(16), nullable=True))
    op.create_index("ix_products_type", "products", ["type"])
    op.create_index("ix_products_gender", "products", ["gender"])
    op.create_index("ix_products_fit", "products", ["fit"])
    op.create_index("ix_products_neckline", "products", ["neckline"])


def downgrade() -> None:
    op.drop_index("ix_products_neckline", "products")
    op.drop_index("ix_products_fit", "products")
    op.drop_index("ix_products_gender", "products")
    op.drop_index("ix_products_type", "products")
    op.drop_column("products", "neckline")
    op.drop_column("products", "fit")
    op.drop_column("products", "gender")
    op.drop_column("products", "type")