from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    ENV: str = "development"
    DEV_MODE: bool = True
    SESSION_SECRET: str = "dev_secret_change_me_change_me_change_me"

    BOT_TOKEN: str = "8936966062:AAGo864XU3xrpx1eAddcCx4LxOfS5s8LhZ0"
    WEBAPP_URL: str = "http://localhost:5173"
    TELEGRAM_INITDATA_TTL: int = 86400
    ADMIN_TELEGRAM_IDS: str = ""

    PAYMENT_PROVIDER: str = "mock"
    TELEGRAM_PROVIDER_TOKEN: str = ""
    PAYMENT_CURRENCY: str = "RUB"

    DELIVERY_PROVIDER: str = "mock"

    DATABASE_URL: str = "postgresql+asyncpg://teeshop:teeshop_pass@localhost:5432/teeshop"
    REDIS_URL: str = "redis://localhost:6379/0"

    CORS_ORIGINS: str = "http://localhost:5173"

    PUBLIC_MEDIA_URL: str = "http://localhost:8000/media"

    YOOKASSA_SHOP_ID: str = "" # <-------
    YOOKASSA_SECRET_KEY: str = "" # <-------
    PAYMENT_RETURN_URL: str = "https://t.me/TeeMarket_bot"

    @property
    def admin_ids(self) -> set[int]:
        return {
            int(x) for x in self.ADMIN_TELEGRAM_IDS.split(",") if x.strip().isdigit()
        }

    @property
    def cors_list(self) -> list[str]:
        return [x.strip() for x in self.CORS_ORIGINS.split(",") if x.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()