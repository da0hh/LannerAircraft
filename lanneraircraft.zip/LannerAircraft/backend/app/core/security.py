import base64
import hmac
import hashlib
import json
import time

from app.config.settings import settings
from app.core.errors import UnauthorizedError

_SESSION_TTL = 60 * 60 * 24 * 7  # 7 дней


def _b64e(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def _b64d(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def create_session_token(user_id: str, telegram_id: int, is_admin: bool) -> str:
    payload = {
        "uid": user_id,
        "tg": telegram_id,
        "adm": is_admin,
        "exp": int(time.time()) + _SESSION_TTL,
    }
    body = _b64e(json.dumps(payload, separators=(",", ":")).encode())
    sig = hmac.new(settings.SESSION_SECRET.encode(), body.encode(), hashlib.sha256).digest()
    return f"{body}.{_b64e(sig)}"


def verify_session_token(token: str) -> dict:
    try:
        body, sig = token.split(".")
    except ValueError:
        raise UnauthorizedError("Malformed token", code="TOKEN_MALFORMED")

    expected = hmac.new(settings.SESSION_SECRET.encode(), body.encode(), hashlib.sha256).digest()
    if not hmac.compare_digest(_b64e(expected), sig):
        raise UnauthorizedError("Bad token signature", code="TOKEN_SIGNATURE")

    payload = json.loads(_b64d(body))
    if payload.get("exp", 0) < time.time():
        raise UnauthorizedError("Token expired", code="TOKEN_EXPIRED")
    return payload