import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl

from app.config.settings import settings
from app.core.errors import UnauthorizedError


def _build_data_check_string(pairs: list[tuple[str, str]]) -> str:
    filtered = [(k, v) for k, v in pairs if k != "hash"]
    filtered.sort(key=lambda kv: kv[0])
    return "\n".join(f"{k}={v}" for k, v in filtered)


def validate_init_data(init_data: str) -> dict:
    """
    Проверяет подпись Telegram WebApp initData.

    Алгоритм:
      secret_key = HMAC_SHA256(key="WebAppData", msg=bot_token)
      calc_hash  = HMAC_SHA256(key=secret_key, msg=data_check_string)
      calc_hash == hash из initData
    """
    if not init_data:
        raise UnauthorizedError("Empty initData", code="INITDATA_EMPTY")

    pairs = parse_qsl(init_data, keep_blank_values=True)
    data = dict(pairs)

    received_hash = data.get("hash")
    if not received_hash:
        raise UnauthorizedError("Missing hash", code="INITDATA_NO_HASH")

    if not settings.BOT_TOKEN:
        raise UnauthorizedError("Bot token not configured", code="BOT_TOKEN_MISSING")

    data_check_string = _build_data_check_string(pairs)

    secret_key = hmac.new(b"WebAppData", settings.BOT_TOKEN.encode(), hashlib.sha256).digest()
    calc_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(calc_hash, received_hash):
        raise UnauthorizedError("Invalid initData signature", code="INITDATA_INVALID")

    # Проверка срока действия
    auth_date = int(data.get("auth_date", "0"))
    if auth_date <= 0:
        raise UnauthorizedError("Invalid auth_date", code="INITDATA_AUTH_DATE")

    if time.time() - auth_date > settings.TELEGRAM_INITDATA_TTL:
        raise UnauthorizedError("initData expired", code="INITDATA_EXPIRED")

    user_raw = data.get("user")
    if not user_raw:
        raise UnauthorizedError("No user in initData", code="INITDATA_NO_USER")

    try:
        user = json.loads(user_raw)
    except json.JSONDecodeError:
        raise UnauthorizedError("Bad user payload", code="INITDATA_BAD_USER")

    return user  # {id, first_name, last_name, username, ...}


def dev_mock_user() -> dict:
    return {
        "id": 999000999,
        "first_name": "Dev",
        "last_name": "User",
        "username": "dev_user",
        "language_code": "ru",
    }