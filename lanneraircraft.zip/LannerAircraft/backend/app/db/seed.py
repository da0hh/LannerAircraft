import asyncio
from decimal import Decimal

from sqlalchemy import select

from app.config.settings import settings
from app.db.session import AsyncSessionLocal
from app.modules.categories.models import Category
from app.modules.products.models import (
    Product, ProductImage, ProductColor, ProductVariant, ProductSize,
)


async def seed_categories(db):
    res = await db.execute(select(Category))
    existing = {c.slug: c for c in res.scalars().all()}
    if existing:
        return existing

    data = [
        ("Базовые", "basic"),
        ("С принтом", "print"),
        ("Оверсайз", "oversize"),
    ]
    cats = {}
    for name, slug in data:
        c = Category(name=name, slug=slug)
        db.add(c)
        cats[slug] = c
    await db.flush()
    return cats


async def seed_sizes(db):
    res = await db.execute(select(ProductSize))
    if res.scalars().first():
        return
    for pos, label in enumerate(["S", "M", "L", "XL"]):
        db.add(ProductSize(label=label, position=pos))
    await db.flush()


async def seed_products(db, cats):
    res = await db.execute(select(Product))
    if res.scalars().first():
        return

    sizes = list((await db.execute(select(ProductSize))).scalars().all())

    demo = [
        ("Базовая футболка", "TSHIRT-001", Decimal("1490"), cats.get("basic")),
        ("Базовая футболка Premium", "TSHIRT-002", Decimal("1690"), cats.get("basic")),
        ("Футболка с принтом «Wave»", "TSHIRT-003", Decimal("1890"), cats.get("print")),
        ("Футболка с принтом «Retro»", "TSHIRT-004", Decimal("1990"), cats.get("print")),
        ("Оверсайз футболка", "TSHIRT-005", Decimal("2190"), cats.get("oversize")),
        ("Оверсайз футболка Heavy", "TSHIRT-006", Decimal("2390"), cats.get("oversize")),
    ]

    colors_data = [("Чёрный", "#000000"), ("Белый", "#FFFFFF"), ("Серый", "#808080")]

    for name, sku, price, cat in demo:
        p = Product(
            name=name, sku=sku, price=price,
            description="Качественная футболка из премиального хлопка.",
            composition="100% хлопок", density="180 г/м²",
            care="Стирка при 30°, не отбеливать",
            category_id=cat.id if cat else None, is_active=True,
        )
        db.add(p)
        await db.flush()

        db.add(ProductImage(
            product_id=p.id,
            url=f"{settings.PUBLIC_MEDIA_URL}/placeholder-{sku}.jpg",
            position=0,
        ))

        for cname, chex in colors_data:
            color = ProductColor(product_id=p.id, name=cname, hex=chex)
            db.add(color)
            await db.flush()
            for s in sizes:
                db.add(ProductVariant(
                    product_id=p.id, color_id=color.id, size_id=s.id, stock=15,
                ))
    await db.flush()


async def main():
    async with AsyncSessionLocal() as db:
        cats = await seed_categories(db)
        await seed_sizes(db)
        await seed_products(db, cats)
        await db.commit()          # ← без неё всё откатывается (это и был баг)
        print("Seed completed.")


if __name__ == "__main__":
    asyncio.run(main())