from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config.settings import settings
from app.core.logging import configure_logging
from app.core.errors import register_error_handlers
from app.middleware.request_id import RequestIDMiddleware
from app.middleware.rate_limit import RateLimitMiddleware

from app.modules.auth.router import router as auth_router
from app.modules.users.router import router as users_router
from app.modules.categories.router import router as categories_router
from app.modules.products.router import router as products_router
from app.modules.favorites.router import router as favorites_router
from app.modules.cart.router import router as cart_router
from app.modules.promo_codes.router import router as promo_router
from app.modules.delivery.router import router as delivery_router
from app.modules.orders.router import router as orders_router
from app.modules.payments.router import router as payments_router
from app.modules.banners.router import router as banners_router
from app.modules.admin.router import router as admin_router
from app.config.settings import settings

@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging()
    yield


app = FastAPI(title="TeeShop API", version="1.0.0", lifespan=lifespan)

from fastapi.staticfiles import StaticFiles
from pathlib import Path

MEDIA_DIR = Path(__file__).resolve().parent.parent / "media"  # -> backend/media
MEDIA_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/media", StaticFiles(directory=MEDIA_DIR), name="media")

app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r"http://(localhost|127\.0\.0\.1):\d+",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(RateLimitMiddleware, limit=240, window=60)
app.add_middleware(RequestIDMiddleware)
register_error_handlers(app)

API = "/api/v1"
for r in (
    auth_router, users_router, categories_router, products_router,
    favorites_router, cart_router, promo_router, delivery_router,
    orders_router, payments_router, banners_router, admin_router,
):
    app.include_router(r, prefix=API)

@app.get("/health")
async def health():
    return {"status": "ok"}