import uuid
import structlog
from starlette.middleware.base import BaseHTTPMiddleware


class RequestIDMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        req_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        structlog.contextvars.bind_contextvars(request_id=req_id, path=request.url.path)
        response = await call_next(request)
        response.headers["X-Request-ID"] = req_id
        structlog.contextvars.clear_contextvars()
        return response