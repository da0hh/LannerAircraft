from fastapi import APIRouter
from app.shared.deps import DbDep, AdminDep

from app.modules.categories.service import CategoryService
from app.modules.categories.schemas import CategoryOut, CategoryCreate, CategoryUpdate
from app.modules.products.service import ProductService
from app.modules.products.schemas import (
    ProductDetail, ProductCreate, ProductUpdate, ImageCreate, ColorCreate,
    ColorOut, VariantUpsert,
)
from app.modules.promo_codes.service import PromoService
from app.modules.promo_codes.schemas import PromoOut, PromoCreate, PromoUpdate
from app.modules.banners.service import BannerService
from app.modules.banners.schemas import BannerOut, BannerCreate, BannerUpdate
from app.modules.orders.service import OrderService
from app.modules.orders.schemas import OrderOut, OrderStatusUpdate
from app.shared.enums import OrderStatus

router = APIRouter(prefix="/admin", tags=["admin"], dependencies=[])


@router.post("/categories", response_model=CategoryOut)
async def create_category(body: CategoryCreate, db: DbDep, _: AdminDep):
    return await CategoryService(db).create(body)


@router.patch("/categories/{cid}", response_model=CategoryOut)
async def update_category(cid: str, body: CategoryUpdate, db: DbDep, _: AdminDep):
    return await CategoryService(db).update(cid, body)


@router.delete("/categories/{cid}")
async def delete_category(cid: str, db: DbDep, _: AdminDep):
    await CategoryService(db).delete(cid)
    return {"status": "ok"}


@router.post("/products", response_model=ProductDetail)
async def create_product(body: ProductCreate, db: DbDep, _: AdminDep):
    return await ProductService(db).create(body)


@router.patch("/products/{pid}", response_model=ProductDetail)
async def update_product(pid: str, body: ProductUpdate, db: DbDep, _: AdminDep):
    return await ProductService(db).update(pid, body)


@router.delete("/products/{pid}")
async def delete_product(pid: str, db: DbDep, _: AdminDep):
    await ProductService(db).delete(pid)
    return {"status": "ok"}


@router.post("/products/{pid}/images")
async def add_image(pid: str, body: ImageCreate, db: DbDep, _: AdminDep):
    await ProductService(db).add_image(pid, body)
    return {"status": "ok"}


@router.post("/products/{pid}/colors", response_model=ColorOut)
async def add_color(pid: str, body: ColorCreate, db: DbDep, _: AdminDep):
    return await ProductService(db).add_color(pid, body)


@router.post("/products/{pid}/variants")
async def upsert_variant(pid: str, body: VariantUpsert, db: DbDep, _: AdminDep):
    await ProductService(db).upsert_variant(pid, body)
    return {"status": "ok"}


@router.get("/promo-codes", response_model=list[PromoOut])
async def list_promos(db: DbDep, _: AdminDep):
    return await PromoService(db).list()


@router.post("/promo-codes", response_model=PromoOut)
async def create_promo(body: PromoCreate, db: DbDep, _: AdminDep):
    return await PromoService(db).create(body)


@router.patch("/promo-codes/{pid}", response_model=PromoOut)
async def update_promo(pid: str, body: PromoUpdate, db: DbDep, _: AdminDep):
    return await PromoService(db).update(pid, body)


@router.delete("/promo-codes/{pid}")
async def delete_promo(pid: str, db: DbDep, _: AdminDep):
    await PromoService(db).delete(pid)
    return {"status": "ok"}


@router.get("/banners", response_model=list[BannerOut])
async def admin_banners(db: DbDep, _: AdminDep):
    return await BannerService(db).list(active_only=False)


@router.post("/banners", response_model=BannerOut)
async def create_banner(body: BannerCreate, db: DbDep, _: AdminDep):
    return await BannerService(db).create(body)


@router.patch("/banners/{bid}", response_model=BannerOut)
async def update_banner(bid: str, body: BannerUpdate, db: DbDep, _: AdminDep):
    return await BannerService(db).update(bid, body)


@router.delete("/banners/{bid}")
async def delete_banner(bid: str, db: DbDep, _: AdminDep):
    await BannerService(db).delete(bid)
    return {"status": "ok"}


@router.get("/orders", response_model=list[OrderOut])
async def admin_orders(db: DbDep, _: AdminDep, status: OrderStatus | None = None):
    return await OrderService(db).list_all(status)


@router.patch("/orders/{oid}/status", response_model=OrderOut)
async def update_order_status(oid: str, body: OrderStatusUpdate, db: DbDep, _: AdminDep):
    return await OrderService(db).update_status(oid, body.status, body.tracking)