from fastapi import APIRouter
from app.shared.deps import DbDep, UserDep
from app.modules.auth.schemas import TelegramAuthRequest, AuthResponse, UserOut
from app.modules.auth.service import AuthService

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/telegram", response_model=AuthResponse)
async def telegram_auth(body: TelegramAuthRequest, db: DbDep):
    return await AuthService(db).authenticate(body.init_data)


@router.get("/me", response_model=UserOut)
async def me(user: UserDep):
    return UserOut(
        id=str(user.id),
        telegram_id=user.telegram_id,
        username=user.username,
        first_name=user.first_name,
        last_name=user.last_name,
        is_admin=user.is_admin,
    )