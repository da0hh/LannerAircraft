from pydantic import BaseModel


class TelegramAuthRequest(BaseModel):
    init_data: str = ""


class UserOut(BaseModel):
    id: str
    telegram_id: int
    username: str | None = None
    first_name: str | None = None
    last_name: str | None = None
    is_admin: bool


class AuthResponse(BaseModel):
    token: str
    user: UserOut