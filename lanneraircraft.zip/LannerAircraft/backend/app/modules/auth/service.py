from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import settings
from app.core.telegram_auth import validate_init_data, dev_mock_user
from app.core.errors import UnauthorizedError
from app.core.security import create_session_token
from app.modules.users.repository import UserRepository
from app.modules.auth.schemas import AuthResponse, UserOut


class AuthService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.users = UserRepository(db)

    async def authenticate(self, init_data: str) -> AuthResponse:
        if init_data:
            tg_user = validate_init_data(init_data)
        elif settings.DEV_MODE:
            tg_user = dev_mock_user()
        else:
            raise UnauthorizedError("initData required", code="INITDATA_REQUIRED")

        telegram_id = int(tg_user["id"])
        is_admin = telegram_id in settings.admin_ids

        user = await self.users.get_by_telegram_id(telegram_id)
        if not user:
            user = await self.users.create(
                telegram_id=telegram_id,
                username=tg_user.get("username"),
                first_name=tg_user.get("first_name"),
                last_name=tg_user.get("last_name"),
                is_admin=is_admin,
            )
        else:
            user.username = tg_user.get("username")
            user.first_name = tg_user.get("first_name")
            user.last_name = tg_user.get("last_name")
            user.is_admin = is_admin

        await self.db.commit()
        await self.db.refresh(user)

        token = create_session_token(str(user.id), user.telegram_id, user.is_admin)
        return AuthResponse(
            token=token,
            user=UserOut(
                id=str(user.id),
                telegram_id=user.telegram_id,
                username=user.username,
                first_name=user.first_name,
                last_name=user.last_name,
                is_admin=user.is_admin,
            ),
        )