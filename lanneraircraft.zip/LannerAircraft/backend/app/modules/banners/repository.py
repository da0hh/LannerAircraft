import uuid
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.banners.models import Banner


class BannerRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def list(self, active_only=True) -> list[Banner]:
        q = select(Banner).order_by(Banner.position)
        if active_only:
            q = q.where(Banner.is_active.is_(True))
        return list((await self.db.execute(q)).scalars().all())

    async def get(self, bid: uuid.UUID) -> Banner | None:
        return await self.db.get(Banner, bid)

    async def create(self, **kwargs) -> Banner:
        b = Banner(**kwargs)
        self.db.add(b)
        await self.db.flush()
        return b