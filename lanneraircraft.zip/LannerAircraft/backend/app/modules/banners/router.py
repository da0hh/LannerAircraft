from fastapi import APIRouter
from app.shared.deps import DbDep
from app.modules.banners.service import BannerService
from app.modules.banners.schemas import BannerOut

router = APIRouter(prefix="/banners", tags=["banners"])


@router.get("", response_model=list[BannerOut])
async def list_banners(db: DbDep):
    return await BannerService(db).list(active_only=True)