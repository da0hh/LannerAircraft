from pydantic import BaseModel


class BannerOut(BaseModel):
    id: str
    title: str
    image_url: str
    link: str | None
    position: int
    is_active: bool


class BannerCreate(BaseModel):
    title: str = ""
    image_url: str
    link: str | None = None
    position: int = 0
    is_active: bool = True


class BannerUpdate(BaseModel):
    title: str | None = None
    image_url: str | None = None
    link: str | None = None
    position: int | None = None
    is_active: bool | None = None