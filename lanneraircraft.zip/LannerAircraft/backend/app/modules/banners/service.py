import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.errors import NotFoundError
from app.modules.banners.repository import BannerRepository
from app.modules.banners.schemas import BannerOut, BannerCreate, BannerUpdate


class BannerService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = BannerRepository(db)

    @staticmethod
    def _out(b) -> BannerOut:
        return BannerOut(
            id=str(b.id), title=b.title, image_url=b.image_url,
            link=b.link, position=b.position, is_active=b.is_active,
        )

    async def list(self, active_only=True) -> list[BannerOut]:
        return [self._out(b) for b in await self.repo.list(active_only)]

    async def create(self, data: BannerCreate) -> BannerOut:
        b = await self.repo.create(**data.model_dump())
        await self.db.commit()
        return self._out(b)

    async def update(self, bid: str, data: BannerUpdate) -> BannerOut:
        b = await self.repo.get(uuid.UUID(bid))
        if not b:
            raise NotFoundError("Banner not found")
        for k, v in data.model_dump(exclude_unset=True).items():
            setattr(b, k, v)
        await self.db.commit()
        return self._out(b)

    async def delete(self, bid: str):
        b = await self.repo.get(uuid.UUID(bid))
        if not b:
            raise NotFoundError("Banner not found")
        await self.db.delete(b)
        await self.db.commit()