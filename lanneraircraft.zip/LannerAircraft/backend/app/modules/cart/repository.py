import uuid
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.cart.models import Cart, CartItem
from app.modules.products.models import ProductVariant, Product


class CartRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_or_create_cart(self, user_id: uuid.UUID) -> Cart:
        res = await self.db.execute(
            select(Cart).where(Cart.user_id == user_id).options(
                selectinload(Cart.items)
                .selectinload(CartItem.variant)
                .selectinload(ProductVariant.product)
                .selectinload(Product.images),
                selectinload(Cart.items)
                .selectinload(CartItem.variant)
                .selectinload(ProductVariant.color),
                selectinload(Cart.items)
                .selectinload(CartItem.variant)
                .selectinload(ProductVariant.size),
            )
        )
        cart = res.scalars().unique().one_or_none()
        if not cart:
            cart = Cart(user_id=user_id)
            self.db.add(cart)
            await self.db.flush()
            await self.db.refresh(cart, attribute_names=["items"])
        return cart

    async def get_variant(self, variant_id: uuid.UUID) -> ProductVariant | None:
        res = await self.db.execute(
            select(ProductVariant)
            .where(ProductVariant.id == variant_id)
            .options(selectinload(ProductVariant.product))
        )
        return res.scalar_one_or_none()

    async def get_item(self, cart_id, variant_id) -> CartItem | None:
        res = await self.db.execute(
            select(CartItem).where(
                CartItem.cart_id == cart_id, CartItem.variant_id == variant_id,
            )
        )
        return res.scalar_one_or_none()

    async def get_item_by_id(self, item_id: uuid.UUID) -> CartItem | None:
        return await self.db.get(CartItem, item_id)

    async def add_item(self, cart_id, variant_id, quantity) -> CartItem:
        item = CartItem(cart_id=cart_id, variant_id=variant_id, quantity=quantity)
        self.db.add(item)
        await self.db.flush()
        return item

    async def clear(self, cart: Cart):
        for item in list(cart.items):
            await self.db.delete(item)