from fastapi import APIRouter
from app.shared.deps import DbDep, UserDep
from app.modules.cart.service import CartService
from app.modules.cart.schemas import (
    CartOut, AddItemRequest, UpdateItemRequest, ApplyPromoRequest, PromoResult,
)

router = APIRouter(prefix="/cart", tags=["cart"])


@router.get("", response_model=CartOut)
async def get_cart(db: DbDep, user: UserDep):
    return await CartService(db).get(user.id)


@router.post("/items", response_model=CartOut)
async def add_item(body: AddItemRequest, db: DbDep, user: UserDep):
    return await CartService(db).add_item(user.id, body.variant_id, body.quantity)


@router.patch("/items/{item_id}", response_model=CartOut)
async def update_item(item_id: str, body: UpdateItemRequest, db: DbDep, user: UserDep):
    return await CartService(db).update_item(user.id, item_id, body.quantity)


@router.delete("/items/{item_id}", response_model=CartOut)
async def remove_item(item_id: str, db: DbDep, user: UserDep):
    return await CartService(db).remove_item(user.id, item_id)


@router.post("/apply-promo", response_model=PromoResult)
async def apply_promo(body: ApplyPromoRequest, db: DbDep, user: UserDep):
    return await CartService(db).apply_promo(user.id, body.code)