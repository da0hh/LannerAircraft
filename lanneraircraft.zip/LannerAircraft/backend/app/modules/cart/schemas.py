from decimal import Decimal
from pydantic import BaseModel, Field


class CartItemOut(BaseModel):
    id: str
    variant_id: str
    product_id: str
    product_name: str
    color_name: str
    size_label: str
    unit_price: Decimal
    quantity: int
    stock: int
    image: str | None
    line_total: Decimal


class CartOut(BaseModel):
    items: list[CartItemOut]
    subtotal: Decimal
    count: int


class AddItemRequest(BaseModel):
    variant_id: str
    quantity: int = Field(default=1, ge=1, le=99)


class UpdateItemRequest(BaseModel):
    quantity: int = Field(ge=1, le=99)


class ApplyPromoRequest(BaseModel):
    code: str


class PromoResult(BaseModel):
    code: str
    discount: Decimal
    subtotal: Decimal
    total: Decimal