import uuid
from decimal import Decimal
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.errors import NotFoundError, OutOfStockError, ForbiddenError
from app.modules.cart.repository import CartRepository
from app.modules.cart.schemas import CartOut, CartItemOut
from app.modules.promo_codes.service import PromoService


class CartService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = CartRepository(db)

    def _serialize(self, cart) -> CartOut:
        items = []
        subtotal = Decimal("0")
        count = 0
        for it in cart.items:
            v = it.variant
            p = v.product
            line = p.price * it.quantity
            subtotal += line
            count += it.quantity
            items.append(CartItemOut(
                id=str(it.id), variant_id=str(v.id), product_id=str(p.id),
                product_name=p.name, color_name=v.color.name, size_label=v.size.label,
                unit_price=p.price, quantity=it.quantity, stock=v.stock,
                image=p.images[0].url if p.images else None, line_total=line,
            ))
        return CartOut(items=items, subtotal=subtotal, count=count)

    async def get(self, user_id: uuid.UUID) -> CartOut:
        cart = await self.repo.get_or_create_cart(user_id)
        return self._serialize(cart)

    async def add_item(self, user_id, variant_id: str, quantity: int) -> CartOut:
        cart = await self.repo.get_or_create_cart(user_id)
        variant = await self.repo.get_variant(uuid.UUID(variant_id))
        if not variant or not variant.product.is_active:
            raise NotFoundError("Variant not found")

        existing = await self.repo.get_item(cart.id, variant.id)
        desired = quantity + (existing.quantity if existing else 0)
        if desired > variant.stock:
            raise OutOfStockError("Not enough stock for selected variant")

        if existing:
            existing.quantity = desired
        else:
            await self.repo.add_item(cart.id, variant.id, quantity)
        await self.db.commit()
        cart = await self.repo.get_or_create_cart(user_id)
        return self._serialize(cart)

    async def update_item(self, user_id, item_id: str, quantity: int) -> CartOut:
        item = await self.repo.get_item_by_id(uuid.UUID(item_id))
        if not item:
            raise NotFoundError("Cart item not found")
        cart = await self.repo.get_or_create_cart(user_id)
        if item.cart_id != cart.id:
            raise ForbiddenError("Not your cart item")
        variant = await self.repo.get_variant(item.variant_id)
        if quantity > variant.stock:
            raise OutOfStockError("Not enough stock for selected variant")
        item.quantity = quantity
        await self.db.commit()
        cart = await self.repo.get_or_create_cart(user_id)
        return self._serialize(cart)

    async def remove_item(self, user_id, item_id: str) -> CartOut:
        item = await self.repo.get_item_by_id(uuid.UUID(item_id))
        if not item:
            raise NotFoundError("Cart item not found")
        cart = await self.repo.get_or_create_cart(user_id)
        if item.cart_id != cart.id:
            raise ForbiddenError("Not your cart item")
        await self.db.delete(item)
        await self.db.commit()
        cart = await self.repo.get_or_create_cart(user_id)
        return self._serialize(cart)

    async def apply_promo(self, user_id, code: str):
        cart = await self.repo.get_or_create_cart(user_id)
        serialized = self._serialize(cart)
        promo_service = PromoService(self.db)
        discount = await promo_service.calculate_discount(code, serialized.subtotal)
        total = serialized.subtotal - discount
        return {
            "code": code.upper(),
            "discount": discount,
            "subtotal": serialized.subtotal,
            "total": total if total > 0 else Decimal("0"),
        }