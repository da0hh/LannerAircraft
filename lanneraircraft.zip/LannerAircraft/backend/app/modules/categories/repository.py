import uuid
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.categories.models import Category


class CategoryRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def list(self) -> list[Category]:
        res = await self.db.execute(select(Category).order_by(Category.name))
        return list(res.scalars().all())

    async def get(self, cid: uuid.UUID) -> Category | None:
        return await self.db.get(Category, cid)

    async def create(self, **kwargs) -> Category:
        c = Category(**kwargs)
        self.db.add(c)
        await self.db.flush()
        return c

    async def delete(self, c: Category) -> None:
        await self.db.delete(c)