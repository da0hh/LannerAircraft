from fastapi import APIRouter
from app.shared.deps import DbDep
from app.modules.categories.service import CategoryService
from app.modules.categories.schemas import CategoryOut

router = APIRouter(prefix="/categories", tags=["categories"])


@router.get("", response_model=list[CategoryOut])
async def list_categories(db: DbDep):
    return await CategoryService(db).list()