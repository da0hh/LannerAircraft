from pydantic import BaseModel


class CategoryOut(BaseModel):
    id: str
    name: str
    slug: str


class CategoryCreate(BaseModel):
    name: str
    slug: str


class CategoryUpdate(BaseModel):
    name: str | None = None
    slug: str | None = None