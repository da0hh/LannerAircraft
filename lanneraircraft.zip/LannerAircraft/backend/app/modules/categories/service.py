import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.errors import NotFoundError
from app.modules.categories.repository import CategoryRepository
from app.modules.categories.schemas import CategoryOut, CategoryCreate, CategoryUpdate


class CategoryService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = CategoryRepository(db)

    async def list(self) -> list[CategoryOut]:
        rows = await self.repo.list()
        return [CategoryOut(id=str(c.id), name=c.name, slug=c.slug) for c in rows]

    async def create(self, data: CategoryCreate) -> CategoryOut:
        c = await self.repo.create(name=data.name, slug=data.slug)
        await self.db.commit()
        return CategoryOut(id=str(c.id), name=c.name, slug=c.slug)

    async def update(self, cid: str, data: CategoryUpdate) -> CategoryOut:
        c = await self.repo.get(uuid.UUID(cid))
        if not c:
            raise NotFoundError("Category not found")
        if data.name is not None:
            c.name = data.name
        if data.slug is not None:
            c.slug = data.slug
        await self.db.commit()
        return CategoryOut(id=str(c.id), name=c.name, slug=c.slug)

    async def delete(self, cid: str) -> None:
        c = await self.repo.get(uuid.UUID(cid))
        if not c:
            raise NotFoundError("Category not found")
        await self.repo.delete(c)
        await self.db.commit()