from abc import ABC, abstractmethod
from decimal import Decimal
from app.shared.enums import DeliveryMethod
from app.modules.delivery.schemas import DeliveryOption


class DeliveryProvider(ABC):
    method: DeliveryMethod
    title: str

    @abstractmethod
    def quote(self, subtotal: Decimal) -> DeliveryOption: ...


class MockDeliveryProvider(DeliveryProvider):
    def __init__(self, method: DeliveryMethod, title: str, base: Decimal,
                 eta: str, pvz: bool, address: bool):
        self.method = method
        self.title = title
        self._base = base
        self._eta = eta
        self._pvz = pvz
        self._address = address

    def quote(self, subtotal: Decimal) -> DeliveryOption:
        cost = Decimal("0") if subtotal >= Decimal("5000") else self._base
        return DeliveryOption(
            method=self.method, title=self.title, cost=cost, eta_days=self._eta,
            supports_pvz=self._pvz, supports_address=self._address,
        )


class CdekProvider(MockDeliveryProvider): ...
class RussianPostProvider(MockDeliveryProvider): ...
class YandexDeliveryProvider(MockDeliveryProvider): ...
class OzonProvider(MockDeliveryProvider): ...


def build_providers() -> dict[DeliveryMethod, DeliveryProvider]:
    return {
        DeliveryMethod.CDEK: CdekProvider(
            DeliveryMethod.CDEK, "СДЭК", Decimal("350"), "2-4 дня", True, True),
        DeliveryMethod.RUSSIAN_POST: RussianPostProvider(
            DeliveryMethod.RUSSIAN_POST, "Почта России", Decimal("250"), "5-10 дней", True, True),
        DeliveryMethod.YANDEX: YandexDeliveryProvider(
            DeliveryMethod.YANDEX, "Яндекс Доставка", Decimal("400"), "1-3 дня", True, True),
        DeliveryMethod.OZON: OzonProvider(
            DeliveryMethod.OZON, "Ozon", Decimal("300"), "2-5 дней", True, False),
    }