from decimal import Decimal
from fastapi import APIRouter, Query
from app.modules.delivery.service import DeliveryService
from app.modules.delivery.schemas import DeliveryOption

router = APIRouter(prefix="/delivery", tags=["delivery"])


@router.get("/options", response_model=list[DeliveryOption])
async def delivery_options(subtotal: Decimal = Query(Decimal("0"), ge=0)):
    return DeliveryService().options(subtotal)