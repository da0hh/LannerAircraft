from decimal import Decimal
from pydantic import BaseModel
from app.shared.enums import DeliveryMethod


class DeliveryOption(BaseModel):
    method: DeliveryMethod
    title: str
    cost: Decimal
    eta_days: str
    supports_pvz: bool
    supports_address: bool