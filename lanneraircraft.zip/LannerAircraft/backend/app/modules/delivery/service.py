from decimal import Decimal
from app.core.errors import NotFoundError
from app.shared.enums import DeliveryMethod
from app.modules.delivery.providers import build_providers
from app.modules.delivery.schemas import DeliveryOption


class DeliveryService:
    def __init__(self):
        self.providers = build_providers()

    def options(self, subtotal: Decimal) -> list[DeliveryOption]:
        return [p.quote(subtotal) for p in self.providers.values()]

    def quote(self, method: DeliveryMethod, subtotal: Decimal) -> DeliveryOption:
        provider = self.providers.get(method)
        if not provider:
            raise NotFoundError("Delivery method not supported")
        return provider.quote(subtotal)