import uuid
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.favorites.models import Favorite
from app.modules.products.models import Product, ProductVariant


class FavoriteRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def list(self, user_id: uuid.UUID):
        q = (
            select(Favorite)
            .where(Favorite.user_id == user_id)
            .options(
                selectinload(Favorite.product).selectinload(Product.images),
                selectinload(Favorite.product).selectinload(Product.variants),
            )
            .order_by(Favorite.created_at.desc())
        )
        return list((await self.db.execute(q)).scalars().unique().all())

    async def get(self, user_id, product_id) -> Favorite | None:
        q = select(Favorite).where(
            Favorite.user_id == user_id, Favorite.product_id == product_id,
        )
        return (await self.db.execute(q)).scalar_one_or_none()

    async def add(self, user_id, product_id) -> Favorite:
        f = Favorite(user_id=user_id, product_id=product_id)
        self.db.add(f)
        await self.db.flush()
        return f

    async def remove(self, fav: Favorite):
        await self.db.delete(fav)