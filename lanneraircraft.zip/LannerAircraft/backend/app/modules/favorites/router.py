from fastapi import APIRouter
from app.shared.deps import DbDep, UserDep
from app.modules.favorites.service import FavoriteService
from app.modules.favorites.schemas import FavoriteOut

router = APIRouter(prefix="/favorites", tags=["favorites"])


@router.get("", response_model=list[FavoriteOut])
async def list_favorites(db: DbDep, user: UserDep):
    return await FavoriteService(db).list(user.id)


@router.post("/{product_id}", status_code=201)
async def add_favorite(product_id: str, db: DbDep, user: UserDep):
    await FavoriteService(db).add(user.id, product_id)
    return {"status": "ok"}


@router.delete("/{product_id}")
async def remove_favorite(product_id: str, db: DbDep, user: UserDep):
    await FavoriteService(db).remove(user.id, product_id)
    return {"status": "ok"}