from decimal import Decimal
from pydantic import BaseModel


class FavoriteOut(BaseModel):
    id: str
    name: str
    price: Decimal
    image: str | None
    in_stock: bool