import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.errors import NotFoundError
from app.modules.favorites.repository import FavoriteRepository
from app.modules.favorites.schemas import FavoriteOut


class FavoriteService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = FavoriteRepository(db)

    async def list(self, user_id: uuid.UUID) -> list[FavoriteOut]:
        favs = await self.repo.list(user_id)
        result = []
        for f in favs:
            p = f.product
            result.append(FavoriteOut(
                id=str(p.id), name=p.name, price=p.price,
                image=p.images[0].url if p.images else None,
                in_stock=any(v.stock > 0 for v in p.variants),
            ))
        return result

    async def add(self, user_id: uuid.UUID, product_id: str):
        pid = uuid.UUID(product_id)
        existing = await self.repo.get(user_id, pid)
        if not existing:
            await self.repo.add(user_id, pid)
            await self.db.commit()

    async def remove(self, user_id: uuid.UUID, product_id: str):
        pid = uuid.UUID(product_id)
        fav = await self.repo.get(user_id, pid)
        if not fav:
            raise NotFoundError("Favorite not found")
        await self.repo.remove(fav)
        await self.db.commit()