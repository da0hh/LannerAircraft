import uuid
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.orders.models import Order, OrderItem, Delivery


class OrderRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    def _full(self):
        return select(Order).options(
            selectinload(Order.items),
            selectinload(Order.delivery),
        )

    async def get(self, oid: uuid.UUID) -> Order | None:
        return (await self.db.execute(self._full().where(Order.id == oid))
                ).scalars().unique().one_or_none()

    async def get_by_number(self, number: int) -> Order | None:
        return (await self.db.execute(self._full().where(Order.number == number))
                ).scalars().unique().one_or_none()

    async def get_by_charge_id(self, charge_id: str) -> Order | None:
        return (await self.db.execute(
            self._full().where(Order.payment_charge_id == charge_id)
        )).scalars().unique().one_or_none()

    async def list_for_user(self, user_id: uuid.UUID) -> list[Order]:
        q = self._full().where(Order.user_id == user_id).order_by(Order.created_at.desc())
        return list((await self.db.execute(q)).scalars().unique().all())

    async def list_all(self, status=None) -> list[Order]:
        q = self._full().order_by(Order.created_at.desc())
        if status:
            q = q.where(Order.status == status)
        return list((await self.db.execute(q)).scalars().unique().all())