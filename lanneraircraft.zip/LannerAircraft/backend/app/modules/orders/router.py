from fastapi import APIRouter
from app.shared.deps import DbDep, UserDep
from app.modules.orders.service import OrderService
from app.modules.orders.schemas import OrderCreateRequest, OrderOut

router = APIRouter(prefix="/orders", tags=["orders"])


@router.post("", response_model=OrderOut, status_code=201)
async def create_order(body: OrderCreateRequest, db: DbDep, user: UserDep):
    return await OrderService(db).create(user.id, body)


@router.get("", response_model=list[OrderOut])
async def list_orders(db: DbDep, user: UserDep):
    return await OrderService(db).list_for_user(user.id)


@router.get("/{order_id}", response_model=OrderOut)
async def get_order(order_id: str, db: DbDep, user: UserDep):
    return await OrderService(db).get_for_user(user.id, order_id)