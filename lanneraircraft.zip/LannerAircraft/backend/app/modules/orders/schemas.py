from decimal import Decimal
from datetime import datetime
from pydantic import BaseModel, Field, field_validator
from app.shared.enums import OrderStatus, DeliveryMethod


class DeliveryInput(BaseModel):
    method: DeliveryMethod
    first_name: str = Field(min_length=1, max_length=128)
    last_name: str = Field(min_length=1, max_length=128)
    phone: str = Field(min_length=5, max_length=32)
    address: str | None = None
    pvz_code: str | None = None
    comment: str | None = None

    @field_validator("phone")
    @classmethod
    def check_phone(cls, v: str) -> str:
        cleaned = v.strip()
        digits = cleaned.replace("+", "").replace(" ", "").replace("-", "")
        if not digits.isdigit():
            raise ValueError("Invalid phone")
        return cleaned


class OrderCreateRequest(BaseModel):
    delivery: DeliveryInput
    promo_code: str | None = None


class OrderItemOut(BaseModel):
    product_name: str
    color_name: str
    size_label: str
    unit_price: Decimal
    quantity: int
    image_url: str | None


class DeliveryOut(BaseModel):
    method: DeliveryMethod
    first_name: str
    last_name: str
    phone: str
    address: str | None
    pvz_code: str | None
    comment: str | None
    tracking: str | None


class OrderOut(BaseModel):
    id: str
    number: int
    status: OrderStatus
    subtotal: Decimal
    discount: Decimal
    delivery_cost: Decimal
    total: Decimal
    currency: str
    promo_code: str | None
    created_at: datetime
    items: list[OrderItemOut]
    delivery: DeliveryOut | None


class OrderStatusUpdate(BaseModel):
    status: OrderStatus
    tracking: str | None = None