import uuid
from decimal import Decimal, ROUND_HALF_UP
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import settings
from app.core.errors import NotFoundError, OutOfStockError, OrderStateError, ForbiddenError
from app.shared.enums import OrderStatus, DeliveryMethod
from app.modules.orders.models import Order, OrderItem, Delivery
from app.modules.orders.repository import OrderRepository
from app.modules.orders.schemas import (
    OrderCreateRequest, OrderOut, OrderItemOut, DeliveryOut,
)
from app.modules.cart.repository import CartRepository
from app.modules.products.models import ProductVariant, Product
from app.modules.delivery.service import DeliveryService
from app.modules.promo_codes.service import PromoService


def _q(v: Decimal) -> Decimal:
    return v.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


class OrderService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = OrderRepository(db)
        self.carts = CartRepository(db)

    @staticmethod
    def _out(o: Order) -> OrderOut:
        return OrderOut(
            id=str(o.id), number=o.number, status=o.status,
            subtotal=o.subtotal, discount=o.discount,
            delivery_cost=o.delivery_cost, total=o.total, currency=o.currency,
            promo_code=o.promo_code, created_at=o.created_at,
            items=[
                OrderItemOut(
                    product_name=i.product_name, color_name=i.color_name,
                    size_label=i.size_label, unit_price=i.unit_price,
                    quantity=i.quantity, image_url=i.image_url,
                )
                for i in o.items
            ],
            delivery=DeliveryOut(
                method=o.delivery.method, first_name=o.delivery.first_name,
                last_name=o.delivery.last_name, phone=o.delivery.phone,
                address=o.delivery.address, pvz_code=o.delivery.pvz_code,
                comment=o.delivery.comment, tracking=o.delivery.tracking,
            ) if o.delivery else None,
        )

    async def create(self, user_id: uuid.UUID, data: OrderCreateRequest) -> OrderOut:
        cart = await self.carts.get_or_create_cart(user_id)
        if not cart.items:
            raise OrderStateError("Cart is empty", code="CART_EMPTY")

        variant_ids = [it.variant_id for it in cart.items]
        locked = await self.db.execute(
            select(ProductVariant)
            .where(ProductVariant.id.in_(variant_ids))
            .with_for_update()
            .options(
                selectinload(ProductVariant.product).selectinload(Product.images),
                selectinload(ProductVariant.color),
                selectinload(ProductVariant.size),
            )
        )
        variants = {v.id: v for v in locked.scalars().unique().all()}

        subtotal = Decimal("0")
        order_items: list[OrderItem] = []
        for it in cart.items:
            v = variants.get(it.variant_id)
            if not v or not v.product.is_active:
                raise NotFoundError(f"Variant unavailable")
            if v.stock < it.quantity:
                raise OutOfStockError(
                    f"{v.product.name} ({v.color.name}/{v.size.label}) out of stock"
                )
            line_price = v.product.price
            subtotal += line_price * it.quantity
            order_items.append(OrderItem(
                variant_id=v.id, product_name=v.product.name,
                color_name=v.color.name, size_label=v.size.label,
                unit_price=line_price, quantity=it.quantity,
                image_url=v.product.images[0].url if v.product.images else None,
            ))

        subtotal = _q(subtotal)

        discount = Decimal("0")
        promo_code_value = None
        if data.promo_code:
            promo_service = PromoService(self.db)
            discount = await promo_service.consume(data.promo_code, subtotal)
            promo_code_value = data.promo_code.upper()

        delivery_quote = DeliveryService().quote(data.delivery.method, subtotal)
        delivery_cost = _q(delivery_quote.cost)

        total = _q(subtotal - discount + delivery_cost)
        if total < 0:
            total = Decimal("0")

        order = Order(
            user_id=user_id, status=OrderStatus.PENDING_PAYMENT,
            subtotal=subtotal, discount=discount, delivery_cost=delivery_cost,
            total=total, promo_code=promo_code_value, currency=settings.PAYMENT_CURRENCY,
        )
        self.db.add(order)
        await self.db.flush()

        for oi in order_items:
            oi.order_id = order.id
            self.db.add(oi)

        d = data.delivery
        self.db.add(Delivery(
            order_id=order.id, method=d.method, first_name=d.first_name,
            last_name=d.last_name, phone=d.phone, address=d.address,
            pvz_code=d.pvz_code, comment=d.comment,
        ))

        for it in cart.items:
            v = variants[it.variant_id]
            v.stock -= it.quantity

        await self.carts.clear(cart)
        await self.db.commit()

        full = await self.repo.get(order.id)
        return self._out(full)

    async def list_for_user(self, user_id: uuid.UUID) -> list[OrderOut]:
        rows = await self.repo.list_for_user(user_id)
        return [self._out(o) for o in rows]

    async def get_for_user(self, user_id: uuid.UUID, order_id: str) -> OrderOut:
        o = await self.repo.get(uuid.UUID(order_id))
        if not o:
            raise NotFoundError("Order not found")
        if o.user_id != user_id:
            raise ForbiddenError("Not your order")
        return self._out(o)

    async def list_all(self, status: OrderStatus | None = None) -> list[OrderOut]:
        rows = await self.repo.list_all(status)
        return [self._out(o) for o in rows]

    async def update_status(self, order_id: str, status: OrderStatus,
                            tracking: str | None = None) -> OrderOut:
        o = await self.repo.get(uuid.UUID(order_id))
        if not o:
            raise NotFoundError("Order not found")
        o.status = status
        if tracking and o.delivery:
            o.delivery.tracking = tracking
        await self.db.commit()
        full = await self.repo.get(o.id)
        return self._out(full)