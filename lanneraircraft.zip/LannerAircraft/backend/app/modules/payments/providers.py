import uuid
from abc import ABC, abstractmethod
from decimal import Decimal

import httpx

from app.config.settings import settings
from app.core.logging import get_logger

log = get_logger("payments")


class PaymentProvider(ABC):
    name: str

    @abstractmethod
    async def create_invoice(self, *, order_number: int, telegram_id: int,
                             amount: Decimal, currency: str,
                             description: str) -> dict: ...


class MockPaymentProvider(PaymentProvider):
    name = "mock"

    async def create_invoice(self, *, order_number, telegram_id, amount,
                             currency, description) -> dict:
        charge_id = f"mock_{uuid.uuid4().hex}"
        log.info("mock_invoice_created", order=order_number, amount=str(amount))
        return {
            "invoice_sent": True,
            "invoice_url": None,
            "charge_id": charge_id,
        }


class TelegramPaymentProvider(PaymentProvider):
    name = "telegram"

    async def create_invoice(self, *, order_number, telegram_id, amount,
                             currency, description) -> dict:
        amount_minor = int((amount * 100).to_integral_value())
        payload = {
            "chat_id": telegram_id,
            "title": f"Заказ №{order_number}",
            "description": description,
            "payload": f"order_{order_number}",
            "provider_token": settings.TELEGRAM_PROVIDER_TOKEN,
            "currency": currency,
            "prices": [{"label": f"Заказ №{order_number}", "amount": amount_minor}],
        }
        url = f"https://api.telegram.org/bot{settings.BOT_TOKEN}/sendInvoice"
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(url, json=payload)
            data = resp.json()
        ok = data.get("ok", False)
        log.info("telegram_invoice", order=order_number, ok=ok)
        return {
            "invoice_sent": ok,
            "invoice_url": None,
            "charge_id": None,
        }


def get_payment_provider() -> PaymentProvider:
    if settings.PAYMENT_PROVIDER == "telegram":
        return TelegramPaymentProvider()
    return MockPaymentProvider()

class YooKassaProvider(PaymentProvider):
    name = "yookassa"
    API_URL = "https://api.yookassa.ru/v3/payments"

    async def create_invoice(self, *, order_number, telegram_id, amount,
                             currency, description) -> dict:
        idempotence_key = str(uuid.uuid4())
        payload = {
            "amount": {
                "value": f"{amount:.2f}",
                "currency": currency,
            },
            "capture": True,
            "confirmation": {
                "type": "redirect",
                "return_url": settings.PAYMENT_RETURN_URL,
            },
            "description": description,
            "metadata": {"order_number": str(order_number)},
        }
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                self.API_URL,
                json=payload,
                auth=(settings.YOOKASSA_SHOP_ID, settings.YOOKASSA_SECRET_KEY),
                headers={"Idempotence-Key": idempotence_key},
            )
            data = resp.json()

        confirmation_url = data.get("confirmation", {}).get("confirmation_url")
        payment_id = data.get("id")
        log.info("yookassa_invoice", order=order_number,
                 payment_id=payment_id, status=data.get("status"))

        return {
            "invoice_sent": False,
            "invoice_url": confirmation_url,
            "charge_id": payment_id,
        }


def get_payment_provider() -> PaymentProvider:
    if settings.PAYMENT_PROVIDER == "telegram":
        return TelegramPaymentProvider()
    if settings.PAYMENT_PROVIDER == "yookassa":
        return YooKassaProvider()
    return MockPaymentProvider()