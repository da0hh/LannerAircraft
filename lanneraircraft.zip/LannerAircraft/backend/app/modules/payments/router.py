from fastapi import APIRouter, Request
from app.shared.deps import DbDep, UserDep
from app.modules.payments.service import PaymentService
from app.modules.payments.schemas import (
    CreatePaymentRequest, CreatePaymentResponse,
)
from app.modules.orders.repository import OrderRepository

router = APIRouter(prefix="/payments", tags=["payments"])


@router.post("/create", response_model=CreatePaymentResponse)
async def create_payment(body: CreatePaymentRequest, db: DbDep, user: UserDep):
    return await PaymentService(db).create_payment(user.id, body.order_id, user.telegram_id)


@router.post("/webhook")
async def payment_webhook(request: Request, db: DbDep):
    payload = await request.json()
    order_number = int(payload.get("order_number") or payload.get("order_id"))
    charge_id = payload["charge_id"]
    status = payload.get("status", "success")
    paid = await PaymentService(db).handle_webhook(order_number, charge_id, status)
    return {"processed": paid}