from decimal import Decimal
from pydantic import BaseModel


class CreatePaymentRequest(BaseModel):
    order_id: str


class CreatePaymentResponse(BaseModel):
    order_id: str
    provider: str
    amount: Decimal
    currency: str
    invoice_sent: bool
    invoice_url: str | None = None


class WebhookRequest(BaseModel):
    order_id: str
    charge_id: str
    status: str