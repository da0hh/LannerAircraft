import uuid
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.errors import NotFoundError, OrderStateError
from app.core.logging import get_logger
from app.shared.enums import OrderStatus
from app.modules.orders.repository import OrderRepository
from app.modules.payments.providers import get_payment_provider
from app.modules.payments.schemas import CreatePaymentResponse

log = get_logger("payments")


class PaymentService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.orders = OrderRepository(db)
        self.provider = get_payment_provider()

    async def create_payment(self, user_id: uuid.UUID, order_id: str,
                             telegram_id: int) -> CreatePaymentResponse:
        order = await self.orders.get(uuid.UUID(order_id))
        if not order:
            raise NotFoundError("Order not found")
        if order.user_id != user_id:
            raise OrderStateError("Not your order", code="FORBIDDEN")
        if order.status not in (OrderStatus.CREATED, OrderStatus.PENDING_PAYMENT):
            raise OrderStateError("Order is not payable", code="ORDER_NOT_PAYABLE")

        result = await self.provider.create_invoice(
            order_number=order.number, telegram_id=telegram_id,
            amount=order.total, currency=order.currency,
            description=f"Оплата заказа №{order.number} в TeeShop",
        )

        if self.provider.name == "mock" and result.get("charge_id"):
            await self._mark_paid(order.number, result["charge_id"])

        return CreatePaymentResponse(
            order_id=str(order.id), provider=self.provider.name,
            amount=order.total, currency=order.currency,
            invoice_sent=result["invoice_sent"], invoice_url=result.get("invoice_url"),
        )

    async def _mark_paid(self, order_number: int, charge_id: str) -> bool:
        existing = await self.orders.get_by_charge_id(charge_id)
        if existing:
            log.info("payment_idempotent_skip", charge_id=charge_id)
            return False

        order = await self.orders.get_by_number(order_number)
        if not order:
            raise NotFoundError("Order not found")
        if order.status == OrderStatus.PAID:
            return False

        order.payment_charge_id = charge_id
        order.status = OrderStatus.PAID
        await self.db.commit()
        log.info("order_paid", order=order_number)
        return True

    async def handle_webhook(self, order_number: int, charge_id: str,
                             status: str) -> bool:
        if status.lower() != "success":
            log.info("payment_webhook_ignored", status=status)
            return False
        return await self._mark_paid(order_number, charge_id)