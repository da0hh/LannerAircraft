import uuid
from decimal import Decimal
from sqlalchemy import String, Text, Numeric, Integer, Boolean, ForeignKey, UniqueConstraint, CheckConstraint, Index
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import Base, UUIDMixin, TimestampMixin


class Product(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "products"
    __table_args__ = (
        CheckConstraint("price >= 0", name="ck_product_price_positive"),
        Index("ix_products_active", "is_active"),
    )

    name: Mapped[str] = mapped_column(String(200), nullable=False)
    sku: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    description: Mapped[str] = mapped_column(Text, default="")
    price: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)

    composition: Mapped[str] = mapped_column(Text, default="")
    density: Mapped[str] = mapped_column(String(64), default="")
    care: Mapped[str] = mapped_column(Text, default="")
    extra_info: Mapped[str] = mapped_column(Text, default="")

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    type: Mapped[str | None] = mapped_column(String(16), index=True)
    gender: Mapped[str | None] = mapped_column(String(16), index=True)
    fit: Mapped[str | None] = mapped_column(String(16), index=True)
    neckline: Mapped[str | None] = mapped_column(String(16), index=True)

    category_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("categories.id", ondelete="SET NULL"), index=True
    )

    images = relationship("ProductImage", back_populates="product", cascade="all, delete-orphan",
                          order_by="ProductImage.position")
    colors = relationship("ProductColor", back_populates="product", cascade="all, delete-orphan")
    variants = relationship("ProductVariant", back_populates="product", cascade="all, delete-orphan")
    category = relationship("Category")


class ProductImage(UUIDMixin, Base):
    __tablename__ = "product_images"

    product_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("products.id", ondelete="CASCADE"), index=True
    )
    url: Mapped[str] = mapped_column(String(500), nullable=False)
    position: Mapped[int] = mapped_column(Integer, default=0)

    product = relationship("Product", back_populates="images")


class ProductColor(UUIDMixin, Base):
    __tablename__ = "product_colors"
    __table_args__ = (UniqueConstraint("product_id", "name", name="uq_color_per_product"),)

    product_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("products.id", ondelete="CASCADE"), index=True
    )
    name: Mapped[str] = mapped_column(String(60), nullable=False)
    hex: Mapped[str] = mapped_column(String(9), default="#000000")

    product = relationship("Product", back_populates="colors")
    variants = relationship("ProductVariant", back_populates="color", cascade="all, delete-orphan")


class ProductSize(UUIDMixin, Base):
    __tablename__ = "product_sizes"

    label: Mapped[str] = mapped_column(String(8), unique=True)
    position: Mapped[int] = mapped_column(Integer, default=0)


class ProductVariant(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "product_variants"
    __table_args__ = (
        UniqueConstraint("product_id", "color_id", "size_id", name="uq_variant_combo"),
        CheckConstraint("stock >= 0", name="ck_variant_stock_positive"),
        Index("ix_variant_product", "product_id"),
    )

    product_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("products.id", ondelete="CASCADE")
    )
    color_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("product_colors.id", ondelete="CASCADE")
    )
    size_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("product_sizes.id", ondelete="CASCADE")
    )
    stock: Mapped[int] = mapped_column(Integer, default=0)

    product = relationship("Product", back_populates="variants")
    color = relationship("ProductColor", back_populates="variants")
    size = relationship("ProductSize")