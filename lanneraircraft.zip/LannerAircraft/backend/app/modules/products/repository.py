from __future__ import annotations
import uuid
from sqlalchemy import select, func
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.products.models import (
    Product, ProductImage, ProductColor, ProductVariant, ProductSize,
)


class ProductRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    def _full_query(self):
        return select(Product).options(
            selectinload(Product.images),
            selectinload(Product.colors),
            selectinload(Product.variants).selectinload(ProductVariant.color),
            selectinload(Product.variants).selectinload(ProductVariant.size),
        )

    async def list(self, *, category_id=None, search=None, active_only=True,
                   page=1, size=20, sort="new",
                   type_=None, genders=None, fits=None, necklines=None,
                   colors=None, sizes=None, price_min=None, price_max=None):
        q = self._full_query()
        if active_only:
            q = q.where(Product.is_active.is_(True))
        if category_id:
            q = q.where(Product.category_id == category_id)
        if search:
            q = q.where(Product.name.ilike(f"%{search}%"))

        if type_:
            q = q.where(Product.type == type_)
        if genders:
            q = q.where(Product.gender.in_(genders))
        if fits:
            q = q.where(Product.fit.in_(fits))
        if necklines:
            q = q.where(Product.neckline.in_(necklines))
        if price_min is not None:
            q = q.where(Product.price >= price_min)
        if price_max is not None:
            q = q.where(Product.price <= price_max)

        if colors:
            q = q.where(
                Product.id.in_(
                    select(ProductColor.product_id).where(ProductColor.name.in_(colors))
                )
            )
        if sizes:
            q = q.where(
                Product.id.in_(
                    select(ProductVariant.product_id)
                    .join(ProductSize, ProductVariant.size_id == ProductSize.id)
                    .where(ProductSize.label.in_(sizes), ProductVariant.stock > 0)
                )
            )

        count_q = select(func.count()).select_from(q.subquery())
        total = (await self.db.execute(count_q)).scalar_one()

        if sort == "price_asc":
            q = q.order_by(Product.price.asc())
        elif sort == "price_desc":
            q = q.order_by(Product.price.desc())
        elif sort == "popular":
            q = q.order_by(Product.created_at.desc())
        else:
            q = q.order_by(Product.created_at.desc())

        q = q.offset((page - 1) * size).limit(size)
        rows = (await self.db.execute(q)).scalars().unique().all()
        return [*rows], total

    async def get(self, pid: uuid.UUID) -> Product | None:
        q = self._full_query().where(Product.id == pid)
        return (await self.db.execute(q)).scalars().unique().one_or_none()

    async def list_sizes(self) -> list[ProductSize]:
        res = await self.db.execute(select(ProductSize).order_by(ProductSize.position))
        return [*res.scalars().all()]

    async def create(self, **kwargs) -> Product:
        p = Product(**kwargs)
        self.db.add(p)
        await self.db.flush()
        return p

    async def add_image(self, product_id, url, position) -> ProductImage:
        img = ProductImage(product_id=product_id, url=url, position=position)
        self.db.add(img)
        await self.db.flush()
        return img

    async def add_color(self, product_id, name, hex_) -> ProductColor:
        c = ProductColor(product_id=product_id, name=name, hex=hex_)
        self.db.add(c)
        await self.db.flush()
        return c

    async def upsert_variant(self, product_id, color_id, size_id, stock) -> ProductVariant:
        res = await self.db.execute(
            select(ProductVariant).where(
                ProductVariant.product_id == product_id,
                ProductVariant.color_id == color_id,
                ProductVariant.size_id == size_id,
            )
        )
        v = res.scalar_one_or_none()
        if v:
            v.stock = stock
        else:
            v = ProductVariant(product_id=product_id, color_id=color_id,
                               size_id=size_id, stock=stock)
            self.db.add(v)
        await self.db.flush()
        return v