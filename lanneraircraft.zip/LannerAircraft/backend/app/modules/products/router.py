from fastapi import APIRouter, Query
from app.shared.deps import DbDep
from app.shared.pagination import Page
from app.modules.products.service import ProductService
from app.modules.products.schemas import ProductListItem, ProductDetail
from decimal import Decimal

router = APIRouter(prefix="/products", tags=["products"])


@router.get("", response_model=Page[ProductListItem])
async def list_products(
    db: DbDep,
    category_id: str | None = Query(None),
    search: str | None = Query(None),
    page: int = Query(1, ge=1),
    size: int = Query(20, ge=1, le=50),
    sort: str = Query("new"),
    type_: str | None = Query(None, alias="type"),
    gender: list[str] | None = Query(None),
    fit: list[str] | None = Query(None),
    neckline: list[str] | None = Query(None),
    color: list[str] | None = Query(None),
    variant_size: list[str] | None = Query(None, alias="variant_size"),
    price_min: Decimal | None = Query(None),
    price_max: Decimal | None = Query(None),
):
    return await ProductService(db).list(
        category_id=category_id, search=search, page=page, size=size, sort=sort,
        type_=type_, genders=gender, fits=fit, necklines=neckline,
        colors=color, sizes=variant_size, price_min=price_min, price_max=price_max,
    )


@router.get("/{product_id}", response_model=ProductDetail)
async def get_product(product_id: str, db: DbDep):
    return await ProductService(db).get(product_id)