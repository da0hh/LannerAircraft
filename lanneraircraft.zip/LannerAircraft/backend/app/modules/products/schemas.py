from decimal import Decimal
from pydantic import BaseModel


class ImageOut(BaseModel):
    id: str
    url: str
    position: int


class ColorOut(BaseModel):
    id: str
    name: str
    hex: str


class VariantOut(BaseModel):
    id: str
    color_id: str
    size_id: str
    size_label: str
    color_name: str
    stock: int


class SizeOut(BaseModel):
    id: str
    label: str
    position: int


class ProductListItem(BaseModel):
    id: str
    name: str
    sku: str
    price: Decimal
    is_active: bool
    category_id: str | None
    image: str | None
    in_stock: bool
    colors: list[ColorOut] = []


class ProductDetail(BaseModel):
    id: str
    name: str
    sku: str
    description: str
    price: Decimal
    composition: str
    density: str
    care: str
    extra_info: str
    is_active: bool
    category_id: str | None
    images: list[ImageOut]
    colors: list[ColorOut]
    sizes: list[SizeOut]
    variants: list[VariantOut]


class ProductCreate(BaseModel):
    name: str
    sku: str
    description: str = ""
    price: Decimal
    composition: str = ""
    density: str = ""
    care: str = ""
    extra_info: str = ""
    category_id: str | None = None
    is_active: bool = True


class ProductUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    price: Decimal | None = None
    composition: str | None = None
    density: str | None = None
    care: str | None = None
    extra_info: str | None = None
    category_id: str | None = None
    is_active: bool | None = None


class ImageCreate(BaseModel):
    url: str
    position: int = 0


class ColorCreate(BaseModel):
    name: str
    hex: str = "#000000"


class VariantUpsert(BaseModel):
    color_id: str
    size_id: str
    stock: int