import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.errors import NotFoundError
from app.shared.pagination import Page
from app.modules.products.repository import ProductRepository
from app.modules.products.schemas import (
    ProductListItem, ProductDetail, ImageOut, ColorOut, SizeOut, VariantOut,
    ProductCreate, ProductUpdate, ImageCreate, ColorCreate, VariantUpsert,
)


class ProductService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = ProductRepository(db)

    @staticmethod
    def _primary_image(p) -> str | None:
        return p.images[0].url if p.images else None

    @staticmethod
    def _in_stock(p) -> bool:
        return any(v.stock > 0 for v in p.variants)

    async def list(self, *, category_id, search, page, size, sort,
                   type_=None, genders=None, fits=None, necklines=None,
                   colors=None, sizes=None, price_min=None, price_max=None) -> Page[ProductListItem]:
        cid = uuid.UUID(category_id) if category_id else None
        rows, total = await self.repo.list(
            category_id=cid, search=search, page=page, size=size, sort=sort,
            type_=type_, genders=genders, fits=fits, necklines=necklines,
            colors=colors, sizes=sizes, price_min=price_min, price_max=price_max,
        )
        items = [
            ProductListItem(
                id=str(p.id), name=p.name, sku=p.sku, price=p.price,
                is_active=p.is_active,
                category_id=str(p.category_id) if p.category_id else None,
                image=self._primary_image(p), in_stock=self._in_stock(p),
                colors=[ColorOut(id=str(c.id), name=c.name, hex=c.hex) for c in p.colors],
            )
            for p in rows
        ]
        return Page(items=items, total=total, page=page, size=size)

    async def _detail(self, p) -> ProductDetail:
        sizes = await self.repo.list_sizes()
        return ProductDetail(
            id=str(p.id), name=p.name, sku=p.sku, description=p.description,
            price=p.price, composition=p.composition, density=p.density,
            care=p.care, extra_info=p.extra_info, is_active=p.is_active,
            category_id=str(p.category_id) if p.category_id else None,
            images=[ImageOut(id=str(i.id), url=i.url, position=i.position) for i in p.images],
            colors=[ColorOut(id=str(c.id), name=c.name, hex=c.hex) for c in p.colors],
            sizes=[SizeOut(id=str(s.id), label=s.label, position=s.position) for s in sizes],
            variants=[
                VariantOut(
                    id=str(v.id), color_id=str(v.color_id), size_id=str(v.size_id),
                    size_label=v.size.label, color_name=v.color.name, stock=v.stock,
                )
                for v in p.variants
            ],
        )

    async def get(self, pid: str) -> ProductDetail:
        p = await self.repo.get(uuid.UUID(pid))
        if not p:
            raise NotFoundError("Product not found")
        return await self._detail(p)

    async def create(self, data: ProductCreate) -> ProductDetail:
        p = await self.repo.create(
            name=data.name, sku=data.sku, description=data.description,
            price=data.price, composition=data.composition, density=data.density,
            care=data.care, extra_info=data.extra_info, is_active=data.is_active,
            category_id=uuid.UUID(data.category_id) if data.category_id else None,
        )
        await self.db.commit()
        p = await self.repo.get(p.id)
        return await self._detail(p)

    async def update(self, pid: str, data: ProductUpdate) -> ProductDetail:
        p = await self.repo.get(uuid.UUID(pid))
        if not p:
            raise NotFoundError("Product not found")
        fields = data.model_dump(exclude_unset=True)
        if "category_id" in fields:
            cid = fields.pop("category_id")
            p.category_id = uuid.UUID(cid) if cid else None
        for k, v in fields.items():
            setattr(p, k, v)
        await self.db.commit()
        p = await self.repo.get(p.id)
        return await self._detail(p)

    async def delete(self, pid: str) -> None:
        p = await self.repo.get(uuid.UUID(pid))
        if not p:
            raise NotFoundError("Product not found")
        await self.db.delete(p)
        await self.db.commit()

    async def add_image(self, pid: str, data: ImageCreate):
        await self.repo.add_image(uuid.UUID(pid), data.url, data.position)
        await self.db.commit()

    async def add_color(self, pid: str, data: ColorCreate):
        c = await self.repo.add_color(uuid.UUID(pid), data.name, data.hex)
        await self.db.commit()
        return ColorOut(id=str(c.id), name=c.name, hex=c.hex)

    async def upsert_variant(self, pid: str, data: VariantUpsert):
        await self.repo.upsert_variant(
            uuid.UUID(pid), uuid.UUID(data.color_id), uuid.UUID(data.size_id), data.stock,
        )
        await self.db.commit()