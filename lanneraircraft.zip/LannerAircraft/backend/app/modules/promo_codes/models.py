from decimal import Decimal
from datetime import datetime
from sqlalchemy import String, Numeric, Integer, Boolean, DateTime, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base, UUIDMixin, TimestampMixin
from app.shared.enums import PromoType


class PromoCode(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "promo_codes"
    __table_args__ = (
        CheckConstraint("value >= 0", name="ck_promo_value_positive"),
        CheckConstraint("max_uses >= 0", name="ck_promo_max_uses"),
    )

    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    type: Mapped[PromoType] = mapped_column(String(16), default=PromoType.PERCENT)
    value: Mapped[Decimal] = mapped_column(Numeric(12, 2), default=Decimal("0"))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    max_uses: Mapped[int] = mapped_column(Integer, default=0)  # 0 = безлимит
    used_count: Mapped[int] = mapped_column(Integer, default=0)