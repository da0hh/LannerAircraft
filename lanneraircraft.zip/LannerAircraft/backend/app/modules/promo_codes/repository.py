import uuid
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.modules.promo_codes.models import PromoCode


class PromoRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_code(self, code: str) -> PromoCode | None:
        res = await self.db.execute(
            select(PromoCode).where(PromoCode.code == code.upper())
        )
        return res.scalar_one_or_none()

    async def get_by_code_for_update(self, code: str) -> PromoCode | None:
        res = await self.db.execute(
            select(PromoCode).where(PromoCode.code == code.upper()).with_for_update()
        )
        return res.scalar_one_or_none()

    async def list(self) -> list[PromoCode]:
        res = await self.db.execute(select(PromoCode).order_by(PromoCode.created_at.desc()))
        return list(res.scalars().all())

    async def get(self, pid: uuid.UUID) -> PromoCode | None:
        return await self.db.get(PromoCode, pid)

    async def create(self, **kwargs) -> PromoCode:
        p = PromoCode(**kwargs)
        self.db.add(p)
        await self.db.flush()
        return p