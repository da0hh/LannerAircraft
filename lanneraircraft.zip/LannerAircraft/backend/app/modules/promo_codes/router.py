from fastapi import APIRouter

router = APIRouter(prefix="/promo-codes", tags=["promo-codes"])