from decimal import Decimal
from datetime import datetime
from pydantic import BaseModel
from app.shared.enums import PromoType


class PromoOut(BaseModel):
    id: str
    code: str
    type: PromoType
    value: Decimal
    is_active: bool
    expires_at: datetime | None
    max_uses: int
    used_count: int


class PromoCreate(BaseModel):
    code: str
    type: PromoType = PromoType.PERCENT
    value: Decimal
    is_active: bool = True
    expires_at: datetime | None = None
    max_uses: int = 0


class PromoUpdate(BaseModel):
    type: PromoType | None = None
    value: Decimal | None = None
    is_active: bool | None = None
    expires_at: datetime | None = None
    max_uses: int | None = None