import uuid
from decimal import Decimal, ROUND_HALF_UP
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.errors import PromoInvalidError, NotFoundError
from app.shared.enums import PromoType
from app.modules.promo_codes.repository import PromoRepository
from app.modules.promo_codes.schemas import PromoOut, PromoCreate, PromoUpdate


def _q(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


class PromoService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = PromoRepository(db)

    def _validate(self, promo, subtotal: Decimal) -> Decimal:
        if not promo or not promo.is_active:
            raise PromoInvalidError("Promo code not found or inactive")
        if promo.expires_at and promo.expires_at < datetime.now(timezone.utc):
            raise PromoInvalidError("Promo code expired")
        if promo.max_uses and promo.used_count >= promo.max_uses:
            raise PromoInvalidError("Promo code usage limit reached")

        if promo.type == PromoType.PERCENT:
            discount = subtotal * promo.value / Decimal("100")
        else:
            discount = promo.value
        if discount > subtotal:
            discount = subtotal
        return _q(discount)

    async def calculate_discount(self, code: str, subtotal: Decimal) -> Decimal:
        promo = await self.repo.get_by_code(code)
        return self._validate(promo, subtotal)

    async def consume(self, code: str, subtotal: Decimal) -> Decimal:
        promo = await self.repo.get_by_code_for_update(code)
        discount = self._validate(promo, subtotal)
        promo.used_count += 1
        return discount

    async def list(self) -> list[PromoOut]:
        rows = await self.repo.list()
        return [self._out(p) for p in rows]

    @staticmethod
    def _out(p) -> PromoOut:
        return PromoOut(
            id=str(p.id), code=p.code, type=p.type, value=p.value,
            is_active=p.is_active, expires_at=p.expires_at,
            max_uses=p.max_uses, used_count=p.used_count,
        )

    async def create(self, data: PromoCreate) -> PromoOut:
        p = await self.repo.create(
            code=data.code.upper(), type=data.type, value=data.value,
            is_active=data.is_active, expires_at=data.expires_at, max_uses=data.max_uses,
        )
        await self.db.commit()
        return self._out(p)

    async def update(self, pid: str, data: PromoUpdate) -> PromoOut:
        p = await self.repo.get(uuid.UUID(pid))
        if not p:
            raise NotFoundError("Promo not found")
        for k, v in data.model_dump(exclude_unset=True).items():
            setattr(p, k, v)
        await self.db.commit()
        return self._out(p)

    async def delete(self, pid: str):
        p = await self.repo.get(uuid.UUID(pid))
        if not p:
            raise NotFoundError("Promo not found")
        await self.db.delete(p)
        await self.db.commit()