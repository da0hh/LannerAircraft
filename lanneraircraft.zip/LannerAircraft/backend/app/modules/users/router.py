from fastapi import APIRouter
from app.shared.deps import UserDep
from app.modules.auth.schemas import UserOut

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/profile", response_model=UserOut)
async def profile(user: UserDep):
    return UserOut(
        id=str(user.id), telegram_id=user.telegram_id, username=user.username,
        first_name=user.first_name, last_name=user.last_name, is_admin=user.is_admin,
    )