import uuid
from typing import Annotated
from fastapi import Depends, Header
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import get_db
from app.core.security import verify_session_token
from app.core.errors import UnauthorizedError, ForbiddenError
from app.modules.users.models import User
from sqlalchemy import select


async def get_current_user(
    authorization: Annotated[str | None, Header()] = None,
    db: AsyncSession = Depends(get_db),
) -> User:
    if not authorization or not authorization.startswith("Bearer "):
        raise UnauthorizedError("Missing bearer token", code="NO_TOKEN")
    token = authorization.split(" ", 1)[1]
    payload = verify_session_token(token)

    user = await db.get(User, uuid.UUID(payload["uid"]))
    if not user:
        raise UnauthorizedError("User not found", code="USER_NOT_FOUND")
    return user


async def get_admin_user(user: User = Depends(get_current_user)) -> User:
    if not user.is_admin:
        raise ForbiddenError("Admin access required", code="ADMIN_REQUIRED")
    return user


DbDep = Annotated[AsyncSession, Depends(get_db)]
UserDep = Annotated[User, Depends(get_current_user)]
AdminDep = Annotated[User, Depends(get_admin_user)]