from enum import StrEnum


class OrderStatus(StrEnum):
    CREATED = "CREATED"
    PENDING_PAYMENT = "PENDING_PAYMENT"
    PAID = "PAID"
    PROCESSING = "PROCESSING"
    SHIPPED = "SHIPPED"
    DELIVERED = "DELIVERED"
    CANCELLED = "CANCELLED"


class DeliveryMethod(StrEnum):
    CDEK = "CDEK"
    RUSSIAN_POST = "RUSSIAN_POST"
    YANDEX = "YANDEX"
    OZON = "OZON"


class PromoType(StrEnum):
    PERCENT = "PERCENT"
    FIXED = "FIXED"