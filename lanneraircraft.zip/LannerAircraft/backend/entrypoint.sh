#!/usr/bin/env bash
set -e

echo "Waiting for database..."
python - <<'PY'
import time, asyncio
from sqlalchemy.ext.asyncio import create_async_engine
from app.config.settings import settings

async def wait():
    for i in range(30):
        try:
            e = create_async_engine(settings.DATABASE_URL)
            async with e.connect():
                pass
            await e.dispose()
            print("DB ready")
            return
        except Exception as ex:
            print(f"DB not ready ({i}): {ex}")
            time.sleep(2)
    raise SystemExit("DB unavailable")

asyncio.run(wait())
PY

echo "Running migrations..."
alembic upgrade head || echo "No migrations yet (run autogenerate first)"

echo "Starting API..."
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers ${UVICORN_WORKERS:-2}