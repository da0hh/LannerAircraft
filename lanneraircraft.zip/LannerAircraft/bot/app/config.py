from pydantic_settings import BaseSettings, SettingsConfigDict


class BotSettings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    BOT_TOKEN: str
    WEBAPP_URL: str
    DATABASE_URL: str
    PAYMENT_PROVIDER: str = "mock"
    TELEGRAM_PROVIDER_TOKEN: str = ""
    PAYMENT_CURRENCY: str = "RUB"
    ADMIN_TELEGRAM_IDS: str = ""
    LOG_LEVEL: str = "INFO"

    @property
    def admin_ids(self) -> set[int]:
        raw = self.ADMIN_TELEGRAM_IDS.strip()
        if not raw:
            return set()
        return {int(x) for x in raw.split(",") if x.strip().isdigit()}


settings = BotSettings()