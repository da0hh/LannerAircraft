from aiogram import Dispatcher
from app.handlers import start, payments, common


def register_handlers(dp: Dispatcher) -> None:
    dp.include_router(start.router)
    dp.include_router(payments.router)
    dp.include_router(common.router)