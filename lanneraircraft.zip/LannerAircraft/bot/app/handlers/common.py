from aiogram import Router
from aiogram.types import Message

from app.keyboards import main_menu_kb

router = Router(name="common")


@router.message()
async def fallback(message: Message):
    await message.answer(
        "Используй кнопку ниже, чтобы открыть магазин 👇",
        reply_markup=main_menu_kb(),
    )