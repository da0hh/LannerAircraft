from aiogram import Router, F
from aiogram.types import Message, PreCheckoutQuery

from app.texts import PAYMENT_SUCCESS
from app.services.payments import mark_order_paid
from app.services.notify import notify_admins_new_payment
from app.logging import get_logger

router = Router(name="payments")
log = get_logger("bot.payments.handler")


@router.pre_checkout_query()
async def pre_checkout(query: PreCheckoutQuery):
    await query.answer(ok=True)


@router.message(F.successful_payment)
async def successful_payment(message: Message):
    sp = message.successful_payment
    payload = sp.invoice_payload
    try:
        order_number = int(payload.replace("order_", ""))
    except ValueError:
        log.error("bad_payload", payload=payload)
        return

    charge_id = sp.telegram_payment_charge_id or sp.provider_payment_charge_id
    order = await mark_order_paid(order_number, charge_id)

    total = sp.total_amount / 100
    currency = sp.currency

    await message.answer(PAYMENT_SUCCESS.format(
        number=order_number, total=total, currency=currency,
    ))

    if order:
        customer = f"{order.delivery.first_name} {order.delivery.last_name}" \
            if order.delivery else "—"
        phone = order.delivery.phone if order.delivery else "—"
        await notify_admins_new_payment(
            message.bot, order_number=order_number,
            total=order.total, currency=order.currency,
            customer=customer, phone=phone,
        )