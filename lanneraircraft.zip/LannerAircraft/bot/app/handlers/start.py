from aiogram import Router
from aiogram.filters import CommandStart, Command
from aiogram.types import Message

from app.keyboards import main_menu_kb
from app.texts import WELCOME, HELP
from app.services.users import upsert_user

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message):
    u = message.from_user
    await upsert_user(
        telegram_id=u.id, username=u.username,
        first_name=u.first_name, last_name=u.last_name,
    )
    await message.answer(WELCOME, reply_markup=main_menu_kb())


@router.message(Command("shop"))
async def cmd_shop(message: Message):
    await message.answer(WELCOME, reply_markup=main_menu_kb())


@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(HELP, reply_markup=main_menu_kb())