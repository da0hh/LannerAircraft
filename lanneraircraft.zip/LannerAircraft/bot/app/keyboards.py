from aiogram.types import (
    InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo,
)
from app.config import settings


def main_menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🛍 Открыть магазин",
            web_app=WebAppInfo(url=settings.WEBAPP_URL),
        )],
        [InlineKeyboardButton(text="📦 Мои заказы",
                              web_app=WebAppInfo(url=f"{settings.WEBAPP_URL}/orders"))],
    ])