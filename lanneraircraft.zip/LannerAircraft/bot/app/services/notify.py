from aiogram import Bot
from app.config import settings
from app.logging import get_logger

log = get_logger("bot.notify")


async def notify_admins_new_payment(bot: Bot, *, order_number: int,
                                    total, currency: str,
                                    customer: str, phone: str) -> None:
    text = (
        f"💰 <b>Новая оплата</b>\n\n"
        f"Заказ №{order_number}\n"
        f"Сумма: {total} {currency}\n"
        f"Клиент: {customer}\n"
        f"Телефон: {phone}"
    )
    for admin_id in settings.admin_ids:
        try:
            await bot.send_message(admin_id, text)
        except Exception as e:
            log.warning("admin_notify_failed", admin=admin_id, error=str(e))