from types import SimpleNamespace
from sqlalchemy import text
from app.db import SessionLocal
from app.logging import get_logger

log = get_logger("bot.payments")


async def mark_order_paid(order_number: int, charge_id: str):
    async with SessionLocal() as db:
        dup = await db.execute(
            text("SELECT id FROM orders WHERE payment_charge_id = :cid"),
            {"cid": charge_id},
        )
        if dup.first():
            log.info("payment_duplicate", charge_id=charge_id)
            return None

        upd = await db.execute(
            text("""
                UPDATE orders
                SET status = 'PAID',
                    payment_charge_id = :cid
                WHERE number = :num
                  AND status <> 'PAID'
                RETURNING id, number
            """),
            {"cid": charge_id, "num": order_number},
        )
        order_row = upd.mappings().first()
        if not order_row:
            log.warning("order_not_found_or_already_paid", number=order_number)
            await db.rollback()
            return None

        await db.commit()

        dres = await db.execute(
            text("""
                SELECT first_name, last_name, phone
                FROM deliveries
                WHERE order_id = :oid
            """),
            {"oid": order_row["id"]},
        )
        drow = dres.mappings().first()
        delivery = SimpleNamespace(**dict(drow)) if drow else None

        log.info("order_paid", number=order_number)
        return SimpleNamespace(number=order_row["number"], delivery=delivery)