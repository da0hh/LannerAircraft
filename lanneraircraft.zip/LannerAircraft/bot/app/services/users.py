import uuid
from sqlalchemy import text
from app.db import SessionLocal


async def upsert_user(*, telegram_id: int, username: str | None,
                      first_name: str | None, last_name: str | None) -> dict:
    async with SessionLocal() as db:
        res = await db.execute(
            text("""
                INSERT INTO users (id, telegram_id, username, first_name, last_name, is_admin)
                VALUES (:id, :tid, :un, :fn, :ln, false)
                ON CONFLICT (telegram_id) DO UPDATE
                SET username = EXCLUDED.username,
                    first_name = EXCLUDED.first_name,
                    last_name = EXCLUDED.last_name
                RETURNING id, telegram_id, username, first_name, last_name, is_admin
            """),
            {"id": uuid.uuid4(), "tid": telegram_id, "un": username,
             "fn": first_name, "ln": last_name},
        )
        row = res.mappings().one()
        await db.commit()
        return dict(row)