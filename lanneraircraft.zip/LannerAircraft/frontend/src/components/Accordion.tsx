import { useState, type ReactNode } from "react";
import { haptic } from "@/lib/telegram";

interface Props {
  title: string;
  children: ReactNode;
  defaultOpen?: boolean;
}

export function Accordion({ title, children, defaultOpen = false }: Props) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className={`accordion ${open ? "accordion--open" : ""}`}>
      <button
        className="accordion__head"
        onClick={() => {
          haptic("light");
          setOpen((v) => !v);
        }}
      >
        <span>{title}</span>
        <span className="accordion__chevron">{open ? "−" : "+"}</span>
      </button>
      {open && <div className="accordion__body">{children}</div>}
    </div>
  );
}