import type { ReactNode } from "react";
import { useAuth } from "@/hooks/useAuth";

export function AdminGuard({ children }: { children: ReactNode }) {
  const { user, ready } = useAuth();
  const isAdmin = (user as { is_admin?: boolean } | null)?.is_admin;

  if (!ready) {
    return <div className="page"><p>Загрузка…</p></div>;
  }

  if (!isAdmin) {
    return (
      <div className="page">
        <h2 className="page__title">Доступ запрещён</h2>
        <p>Эта страница только для администраторов.</p>
      </div>
    );
  }

  return <>{children}</>;
}