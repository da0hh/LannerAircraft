import type { Banner as BannerType } from "@/types";

export function BannerCarousel({ banners }: { banners: BannerType[] }) {
  if (!banners.length) return null;
  return (
    <div className="banners">
      {banners.map((b) => (
        <div key={b.id} className="banner">
          <img src={b.image_url} alt={b.title} />
          <div className="banner__title">{b.title}</div>
        </div>
      ))}
    </div>
  );
}