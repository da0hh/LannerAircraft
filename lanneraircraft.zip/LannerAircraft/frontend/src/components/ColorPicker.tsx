import type { ProductColor } from "@/types";
import { haptic } from "@/lib/telegram";

interface Props {
  colors: ProductColor[];
  selected: string | null;
  onSelect: (id: string) => void;
}

export function ColorPicker({ colors, selected, onSelect }: Props) {
  return (
    <div className="picker">
      <div className="picker__label">Цвет</div>
      <div className="picker__swatches">
        {colors.map((c) => (
          <button
            key={c.id}
            className={`swatch ${selected === c.id ? "swatch--active" : ""}`}
            style={{ background: c.hex }}
            title={c.name}
            onClick={() => {
              haptic("light");
              onSelect(c.id);
            }}
            aria-label={c.name}
          />
        ))}
      </div>
    </div>
  );
}