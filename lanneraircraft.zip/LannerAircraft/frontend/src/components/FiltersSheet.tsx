import { useFilters } from "@/store/filters";
import {
  GENDER_OPTIONS, FIT_OPTIONS, TYPE_OPTIONS, NECKLINE_OPTIONS,
  COLOR_OPTIONS, SIZE_OPTIONS, SORT_OPTIONS,
} from "@/lib/filterOptions";
import { haptic } from "@/lib/telegram";
import { useState } from "react";

export function FiltersSheet({
  onClose,
  onOpenSizeGuide,
}: {
  onClose: () => void;
  onOpenSizeGuide: () => void;
}) {
  const draft = useFilters((s) => s.draft);
  const toggle = useFilters((s) => s.toggleArray);
  const setDraft = useFilters((s) => s.setDraft);
  const apply = useFilters((s) => s.apply);
  const reset = useFilters((s) => s.reset);

  const [priceMin, setPriceMin] = useState(draft.price_min?.toString() ?? "");
  const [priceMax, setPriceMax] = useState(draft.price_max?.toString() ?? "");

  const handleApply = () => {
    haptic("light");
    setDraft({
      price_min: priceMin ? Number(priceMin) : undefined,
      price_max: priceMax ? Number(priceMax) : undefined,
    });
    // применяем после патча цены — в следующем тике
    setTimeout(() => {
      apply();
      onClose();
    }, 0);
  };

  const handleReset = () => {
    haptic("light");
    reset();
    setPriceMin("");
    setPriceMax("");
  };

  const Chips = ({
    options,
    selected,
    onToggle,
  }: {
    options: { value: string; label: string }[];
    selected: string[];
    onToggle: (v: string) => void;
  }) => (
    <div className="chips">
      {options.map((o) => (
        <button
          key={o.value}
          className={`chip ${selected.includes(o.value) ? "chip--active" : ""}`}
          onClick={() => {
            haptic("light");
            onToggle(o.value);
          }}
        >
          {o.label}
        </button>
      ))}
    </div>
  );

  return (
    <>
      <div className="sheet__overlay" onClick={onClose} />
      <div className="sheet sheet--filters">
        <div className="sheet__handle" />
        <div className="sheet__scroll">
          <h3 className="sheet__title">Фильтры</h3>

          <section className="filter-block">
            <div className="filter-block__label">Сортировка</div>
            <div className="chips">
              {SORT_OPTIONS.map((o) => (
                <button
                  key={o.value}
                  className={`chip ${draft.sort === o.value ? "chip--active" : ""}`}
                  onClick={() => {
                    haptic("light");
                    setDraft({ sort: o.value });
                  }}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </section>

          <section className="filter-block">
            <div className="filter-block__label">Пол</div>
            <Chips options={GENDER_OPTIONS} selected={draft.gender} onToggle={(v) => toggle("gender", v)} />
          </section>

          <section className="filter-block">
            <div className="filter-block__label">Фасон</div>
            <Chips options={FIT_OPTIONS} selected={draft.fit} onToggle={(v) => toggle("fit", v)} />
          </section>

          <section className="filter-block">
            <div className="filter-block__label">Тип</div>
            <Chips options={TYPE_OPTIONS} selected={draft.type} onToggle={(v) => toggle("type", v)} />
          </section>

          <section className="filter-block">
            <div className="filter-block__label">Горловина</div>
            <Chips options={NECKLINE_OPTIONS} selected={draft.neckline} onToggle={(v) => toggle("neckline", v)} />
          </section>

          <section className="filter-block">
            <div className="filter-block__label">Цвет</div>
            <div className="chips chips--colors">
              {COLOR_OPTIONS.map((c) => (
                <button
                  key={c.value}
                  className={`color-swatch ${draft.color.includes(c.value) ? "color-swatch--active" : ""}`}
                  style={{ background: c.hex }}
                  title={c.value}
                  onClick={() => {
                    haptic("light");
                    toggle("color", c.value);
                  }}
                />
              ))}
            </div>
          </section>

          <section className="filter-block">
            <div className="filter-block__label filter-block__label--row">
              <span>Размер</span>
              <button className="size-guide-btn" onClick={onOpenSizeGuide}>
                Таблица размеров
              </button>
            </div>
            <div className="chips">
              {SIZE_OPTIONS.map((s) => (
                <button
                  key={s}
                  className={`chip ${draft.variant_size.includes(s) ? "chip--active" : ""}`}
                  onClick={() => {
                    haptic("light");
                    toggle("variant_size", s);
                  }}
                >
                  {s}
                </button>
              ))}
            </div>
          </section>

          <section className="filter-block">
            <div className="filter-block__label">Цена, ₽</div>
            <div className="price-range">
              <input
                type="number"
                inputMode="numeric"
                placeholder="от"
                value={priceMin}
                onChange={(e) => setPriceMin(e.target.value)}
              />
              <span>—</span>
              <input
                type="number"
                inputMode="numeric"
                placeholder="до"
                value={priceMax}
                onChange={(e) => setPriceMax(e.target.value)}
              />
            </div>
          </section>
        </div>

        <div className="sheet__actions">
          <button className="sheet__reset" onClick={handleReset}>
            Сбросить
          </button>
          <button className="sheet__apply" onClick={handleApply}>
            Показать товары
          </button>
        </div>
      </div>
    </>
  );
}