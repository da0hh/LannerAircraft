import { type ReactNode } from "react";
import { Link } from "react-router-dom";
import { TabBar } from "./TabBar";
import { useUi } from "@/store/ui";

export function Layout({ children }: { children: ReactNode }) {
  const toasts = useUi((s) => s.toasts);
  const toggleFilters = useUi((s) => s.toggleFilters);

  return (
    <div className="layout">
      <header className="topbar">
        <Link to="/" className="topbar__logo">
          <img src="/types_logos/logo.png" alt="Lanner Aircraft" />
        </Link>
        <div className="topbar__actions">
          <button
            className="topbar__btn"
            onClick={toggleFilters}
            aria-label="Фильтры"
          >
            🎚 Фильтры
          </button>
          <Link to="/favourites" className="topbar__btn" aria-label="Избранное">
            ♡ Избранное
          </Link>
        </div>
      </header>

      <main className="layout__content">{children}</main>
      <TabBar />

      <div className="toasts">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast--${t.type}`}>
            {t.message}
          </div>
        ))}
      </div>
    </div>
  );
}