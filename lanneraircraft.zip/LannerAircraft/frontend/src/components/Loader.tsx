export function Loader({ full = false }: { full?: boolean }) {
  return (
    <div className={full ? "loader loader--full" : "loader"}>
      <div className="spinner" />
    </div>
  );
}