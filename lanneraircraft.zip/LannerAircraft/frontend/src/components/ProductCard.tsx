import { Link, useNavigate } from "react-router-dom";
import type { ProductListItem } from "@/types";
import { formatPrice } from "@/lib/format";
import { useFavorites } from "@/store/favourites";
import { haptic } from "@/lib/telegram";
import { toMediaUrl } from "@/lib/media";
import { useState } from "react";

export function ProductCard({ product }: { product: ProductListItem }) {
  const { has, toggle } = useFavorites();
  const navigate = useNavigate();
  const fav = has(product.id);
  const [imgError, setImgError] = useState(false);

  const img = toMediaUrl(product.image);

  return (
    <div className="card">
      <Link to={`/product/${product.id}`} className="card__link">
        <div className="card__image">
          {img && !imgError ? (
            <img
              src={img}
              alt={product.name}
              loading="lazy"
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="card__placeholder" />
          )}
        </div>
        <div className="card__name">{product.name}</div>
        <div className="card__price">{formatPrice(product.price)}</div>
      </Link>

      <button
        className={`card__fav ${fav ? "card__fav--active" : ""}`}
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          haptic("medium");
          toggle(product.id);
        }}
        aria-label="В избранное"
      >
        {fav ? "♥" : "♡"}
      </button>

      <button
        className="card__cart"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          haptic("light");
          navigate(`/product/${product.id}?pick=1`);
        }}
      >
        🛒 В корзину
      </button>
    </div>
  );
}