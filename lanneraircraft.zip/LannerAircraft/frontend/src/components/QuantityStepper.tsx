import { haptic } from "@/lib/telegram";

interface Props {
  value: number;
  min?: number;
  max?: number;
  onChange: (v: number) => void;
}

export function QuantityStepper({ value, min = 1, max = 99, onChange }: Props) {
  const dec = () => {
    if (value > min) {
      haptic("light");
      onChange(value - 1);
    }
  };
  const inc = () => {
    if (value < max) {
      haptic("light");
      onChange(value + 1);
    }
  };
  return (
    <div className="stepper">
      <button onClick={dec} disabled={value <= min}>−</button>
      <span>{value}</span>
      <button onClick={inc} disabled={value >= max}>+</button>
    </div>
  );
}