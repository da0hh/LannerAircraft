const ROWS = [
  { size: "XS", chest: "42–44", length: 66 },
  { size: "S", chest: "44–46", length: 68 },
  { size: "M", chest: "46–48", length: 70 },
  { size: "L", chest: "50–52", length: 72 },
  { size: "XL", chest: "54–56", length: 74 },
  { size: "XXL", chest: "58–60", length: 76 },
];

export function SizeGuide({ onClose }: { onClose: () => void }) {
  return (
    <>
      <div className="sheet__overlay" onClick={onClose} />
      <div className="sheet sheet--guide">
        <div className="sheet__handle" />
        <h3 className="sheet__title">Таблица размеров</h3>
        <table className="size-table">
          <thead>
            <tr>
              <th>Размер</th>
              <th>Обхват груди, см</th>
              <th>Длина, см</th>
            </tr>
          </thead>
          <tbody>
            {ROWS.map((r) => (
              <tr key={r.size}>
                <td>{r.size}</td>
                <td>{r.chest}</td>
                <td>{r.length}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <button className="sheet__apply" onClick={onClose}>
          Понятно
        </button>
      </div>
    </>
  );
}