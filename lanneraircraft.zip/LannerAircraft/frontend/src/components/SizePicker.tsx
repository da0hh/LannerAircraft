import type { ProductSize } from "@/types";
import { haptic } from "@/lib/telegram";

interface Props {
  sizes: ProductSize[];
  selected: string | null;
  availableSizeIds: Set<string>;
  onSelect: (id: string) => void;
}

export function SizePicker({ sizes, selected, availableSizeIds, onSelect }: Props) {
  return (
    <div className="picker">
      <div className="picker__label">Размер</div>
      <div className="picker__sizes">
        {sizes.map((s) => {
          const disabled = !availableSizeIds.has(s.id);
          return (
            <button
              key={s.id}
              disabled={disabled}
              className={`size-btn ${selected === s.id ? "size-btn--active" : ""} ${
                disabled ? "size-btn--disabled" : ""
              }`}
              onClick={() => {
                if (disabled) return;
                haptic("light");
                onSelect(s.id);
              }}
            >
              {s.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}