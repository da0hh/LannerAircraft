import { NavLink } from "react-router-dom";
import { useCart } from "@/store/cart";

const tabs = [
  { to: "/", label: "Каталог", icon: "🏠" },
  { to: "/categories", label: "Категории", icon: "🗂️" },
  { to: "/cart", label: "Корзина", icon: "🛒", badge: true },
  { to: "/profile", label: "Профиль", icon: "👤" },
];

export function TabBar() {
  const count = useCart((s) => s.cart?.count ?? 0);
  return (
    <nav className="tabbar">
      {tabs.map((t) => (
        <NavLink
          key={t.to}
          to={t.to}
          end={t.to === "/"}
          className={({ isActive }) =>
            `tabbar__item ${isActive ? "tabbar__item--active" : ""}`
          }
        >
          <span className="tabbar__icon">
            {t.icon}
            {t.badge && count > 0 && (
              <span className="tabbar__badge">{count}</span>
            )}
          </span>
          <span className="tabbar__label">{t.label}</span>
        </NavLink>
      ))}
    </nav>
  );
}