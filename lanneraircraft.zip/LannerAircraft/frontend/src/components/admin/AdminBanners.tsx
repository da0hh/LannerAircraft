import { useEffect, useState } from "react";
import { adminApi } from "@/lib/adminApi";
import { useUi } from "@/store/ui";
import type { components } from "@/api/schema";
import "./admin.css";

type BannerOut = components["schemas"]["BannerOut"];

const empty = {
  title: "",
  image_url: "",
  link: "",
  position: 0,
  is_active: true,
};

export function AdminBanners() {
  const notify = useUi((s) => s.notify);
  const [items, setItems] = useState<BannerOut[]>([]);
  const [loading, setLoading] = useState(true);

  const [form, setForm] = useState({ ...empty });
  const [editId, setEditId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const data = await adminApi.listBanners();
      setItems(data);
    } catch (err) {
      console.error("LOAD BANNERS ERROR:", err);
      notify("Не удалось загрузить баннеры", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const resetForm = () => {
    setForm({ ...empty });
    setEditId(null);
  };

  const submit = async () => {
    if (!form.image_url.trim()) {
      notify("Укажите URL картинки", "error");
      return;
    }
    const body = {
      title: form.title.trim(),
      image_url: form.image_url.trim(),
      link: form.link.trim() || null,
      position: Number(form.position) || 0,
      is_active: form.is_active,
    };
    try {
      if (editId) {
        await adminApi.updateBanner(editId, body);
        notify("Баннер обновлён", "success");
      } else {
        await adminApi.createBanner(body);
        notify("Баннер создан", "success");
      }
      resetForm();
      load();
    } catch (err) {
      console.error("SAVE BANNER ERROR:", err);
      notify("Не удалось сохранить баннер", "error");
    }
  };

  const startEdit = (b: BannerOut) => {
    setEditId(b.id);
    setForm({
      title: b.title,
      image_url: b.image_url,
      link: b.link ?? "",
      position: b.position,
      is_active: b.is_active,
    });
  };

  const remove = async (bid: string) => {
    if (!confirm("Удалить баннер?")) return;
    try {
      await adminApi.deleteBanner(bid);
      notify("Удалено", "success");
      load();
    } catch (err) {
      console.error("DELETE BANNER ERROR:", err);
      notify("Не удалось удалить", "error");
    }
  };

  return (
    <div className="admin-banners">
      <div className="admin-banners__form">
        <h3>{editId ? "Редактирование баннера" : "Новый баннер"}</h3>
        <input
          placeholder="Заголовок"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
        />
        <input
          placeholder="URL картинки *"
          value={form.image_url}
          onChange={(e) => setForm({ ...form, image_url: e.target.value })}
        />
        <input
          placeholder="Ссылка (необязательно)"
          value={form.link}
          onChange={(e) => setForm({ ...form, link: e.target.value })}
        />
        <input
          type="number"
          placeholder="Позиция"
          value={form.position}
          onChange={(e) =>
            setForm({ ...form, position: Number(e.target.value) })
          }
        />
        <label className="admin-banners__check">
          <input
            type="checkbox"
            checked={form.is_active}
            onChange={(e) => setForm({ ...form, is_active: e.target.checked })}
          />
          Активен
        </label>
        <div className="admin-banners__actions">
          <button onClick={submit}>{editId ? "Сохранить" : "Добавить"}</button>
          {editId && <button onClick={resetForm}>Отмена</button>}
        </div>
      </div>

      {loading ? (
        <p>Загрузка…</p>
      ) : items.length === 0 ? (
        <p>Баннеров нет</p>
      ) : (
        <div className="admin-banners__list">
          {items.map((b) => (
            <div className="admin-banner" key={b.id}>
              <img
                className="admin-banner__img"
                src={b.image_url}
                alt={b.title}
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).style.opacity = "0.3";
                  (e.currentTarget as HTMLImageElement).alt = "битая ссылка";
                }}
              />
              <div className="admin-banner__info">
                <b>{b.title || "(без заголовка)"}</b>
                <span>поз. {b.position}</span>
                <span>{b.is_active ? "активен" : "скрыт"}</span>
                {b.link && <span className="admin-banner__link">{b.link}</span>}
              </div>
              <div className="admin-banner__buttons">
                <button onClick={() => startEdit(b)}>Изменить</button>
                <button onClick={() => remove(b.id)}>Удалить</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}