import { useEffect, useState } from "react";
import { adminApi } from "@/lib/adminApi";
import { api } from "@/lib/api";
import { useUi } from "@/store/ui";
import type { components } from "@/api/schema";
import "./admin.css";

type CategoryOut = components["schemas"]["CategoryOut"];

const slugify = (s: string) =>
  s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9а-я\s-]/gi, "")
    .replace(/\s+/g, "-");

export function AdminCategories() {
  const notify = useUi((s) => s.notify);
  const [items, setItems] = useState<CategoryOut[]>([]);
  const [loading, setLoading] = useState(true);

  // форма создания
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");

  // редактирование
  const [editId, setEditId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [editSlug, setEditSlug] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const data = await api.get<CategoryOut[]>("/categories");
      setItems(data);
    } catch (err) {
      console.error("LOAD CATEGORIES ERROR:", err);
      notify("Не удалось загрузить категории", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const create = async () => {
    if (!name.trim()) {
      notify("Введите название", "error");
      return;
    }
    try {
      await adminApi.createCategory({
        name: name.trim(),
        slug: (slug.trim() || slugify(name)),
      });
      setName("");
      setSlug("");
      notify("Категория создана", "success");
      load();
    } catch (err) {
      console.error("CREATE CATEGORY ERROR:", err);
      notify("Не удалось создать категорию", "error");
    }
  };

  const startEdit = (c: CategoryOut) => {
    setEditId(c.id);
    setEditName(c.name);
    setEditSlug(c.slug);
  };

  const cancelEdit = () => {
    setEditId(null);
    setEditName("");
    setEditSlug("");
  };

  const saveEdit = async (cid: string) => {
    try {
      await adminApi.updateCategory(cid, {
        name: editName.trim(),
        slug: editSlug.trim(),
      });
      cancelEdit();
      notify("Сохранено", "success");
      load();
    } catch (err) {
      console.error("UPDATE CATEGORY ERROR:", err);
      notify("Не удалось сохранить", "error");
    }
  };

  const remove = async (cid: string) => {
    if (!confirm("Удалить категорию?")) return;
    try {
      await adminApi.deleteCategory(cid);
      notify("Удалено", "success");
      load();
    } catch (err) {
      console.error("DELETE CATEGORY ERROR:", err);
      notify("Не удалось удалить", "error");
    }
  };

  return (
    <div className="admin-cats">
      <div className="admin-cats__create">
        <input
          placeholder="Название"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          placeholder="slug (авто, если пусто)"
          value={slug}
          onChange={(e) => setSlug(e.target.value)}
        />
        <button onClick={create}>Добавить</button>
      </div>

      {loading ? (
        <p>Загрузка…</p>
      ) : items.length === 0 ? (
        <p>Категорий нет</p>
      ) : (
        <div className="admin-cats__list">
          {items.map((c) => (
            <div className="admin-cat" key={c.id}>
              {editId === c.id ? (
                <>
                  <input
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                  />
                  <input
                    value={editSlug}
                    onChange={(e) => setEditSlug(e.target.value)}
                  />
                  <button onClick={() => saveEdit(c.id)}>Сохранить</button>
                  <button onClick={cancelEdit}>Отмена</button>
                </>
              ) : (
                <>
                  <b>{c.name}</b>
                  <span className="admin-cat__slug">/{c.slug}</span>
                  <button onClick={() => startEdit(c)}>Изменить</button>
                  <button onClick={() => remove(c.id)}>Удалить</button>
                </>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}