import { useEffect, useState } from "react";
import { adminApi } from "@/lib/adminApi";
import { useUi } from "@/store/ui";
import type { components } from "@/api/schema";

type OrderOut = components["schemas"]["OrderOut"];
type OrderStatus = components["schemas"]["OrderStatus"];

const STATUSES: OrderStatus[] = [
  "CREATED",
  "PENDING_PAYMENT",
  "PAID",
  "PROCESSING",
  "SHIPPED",
  "DELIVERED",
  "CANCELLED",
];

const STATUS_LABEL: Record<OrderStatus, string> = {
  CREATED: "Создан",
  PENDING_PAYMENT: "Ждёт оплаты",
  PAID: "Оплачен",
  PROCESSING: "В обработке",
  SHIPPED: "Отправлен",
  DELIVERED: "Доставлен",
  CANCELLED: "Отменён",
};

export function AdminOrders() {
  const notify = useUi((s) => s.notify);
  const [orders, setOrders] = useState<OrderOut[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<OrderStatus | "">("");

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      try {
        const data = await adminApi.listOrders(filter || undefined);
        if (!cancelled) setOrders(data);
      } catch (err) {
        console.error("LOAD ORDERS ERROR:", err);
        notify("Не удалось загрузить заказы", "error");
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    load();
    return () => {
      cancelled = true;
    };
  }, [filter, notify]);

  const changeStatus = async (oid: string, status: OrderStatus) => {
    try {
      const updated = await adminApi.updateOrderStatus(oid, { status });
      setOrders((prev) => prev.map((o) => (o.id === oid ? updated : o)));
      notify("Статус обновлён", "success");
    } catch (err) {
      console.error("UPDATE STATUS ERROR:", err);
      notify("Не удалось обновить статус", "error");
    }
  };

  return (
    <div className="admin-orders">
      <div className="admin-orders__filter">
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as OrderStatus | "")}
        >
          <option value="">Все статусы</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {STATUS_LABEL[s]}
            </option>
          ))}
        </select>
      </div>

      {loading ? (
        <p>Загрузка…</p>
      ) : orders.length === 0 ? (
        <p>Заказов нет</p>
      ) : (
        <div className="admin-orders__list">
          {orders.map((o) => (
            <div className="admin-order" key={o.id}>
              <div className="admin-order__head">
                <b>Заказ #{o.number}</b>
                <span>
                  {o.total} {o.currency}
                </span>
              </div>

              <div className="admin-order__items">
                {o.items.map((it, i) => (
                  <div key={i} className="admin-order__item">
                    {it.product_name} · {it.color_name} · {it.size_label} ×
                    {it.quantity}
                  </div>
                ))}
              </div>

              {o.delivery && (
                <div className="admin-order__delivery">
                  {o.delivery.first_name} {o.delivery.last_name},{" "}
                  {o.delivery.phone}
                  {o.delivery.address ? `, ${o.delivery.address}` : ""}
                </div>
              )}

              <select
                value={o.status}
                onChange={(e) =>
                  changeStatus(o.id, e.target.value as OrderStatus)
                }
              >
                {STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {STATUS_LABEL[s]}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}