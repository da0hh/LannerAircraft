import { useEffect, useState } from "react";
import { adminApi } from "@/lib/adminApi";
import { api } from "@/lib/api";
import { useUi } from "@/store/ui";
import type { components } from "@/api/schema";
import "./admin.css";

type ProductListItem = components["schemas"]["ProductListItem"];
type ProductDetail = components["schemas"]["ProductDetail"];
type ProductCreate = components["schemas"]["ProductCreate"];
type ProductUpdate = components["schemas"]["ProductUpdate"];
type SizeOut = components["schemas"]["SizeOut"];
type ColorOut = components["schemas"]["ColorOut"];

const emptyCreate: ProductCreate = {
  name: "",
  sku: "",
  description: "",
  price: 0 as unknown as ProductCreate["price"],
  composition: "",
  density: "",
  care: "",
  extra_info: "",
  category_id: null,
  is_active: true,
};

export function AdminProducts() {
  const notify = useUi((s) => s.notify);

  const [items, setItems] = useState<ProductListItem[]>([]);
  const [loading, setLoading] = useState(true);

  const [showCreate, setShowCreate] = useState(false);
  const [draft, setDraft] = useState<ProductCreate>(emptyCreate);

  const [openId, setOpenId] = useState<string | null>(null);
  const [detail, setDetail] = useState<ProductDetail | null>(null);
  const [edit, setEdit] = useState<ProductUpdate>({});

  const [allSizes, setAllSizes] = useState<SizeOut[]>([]);

  const [imgUrl, setImgUrl] = useState("");
  const [colorName, setColorName] = useState("");
  const [colorHex, setColorHex] = useState("#000000");
  const [varColor, setVarColor] = useState("");
  const [varSize, setVarSize] = useState("");
  const [varStock, setVarStock] = useState("0");
  const [stockEdits, setStockEdits] = useState<Record<string, string>>({});

  const load = async () => {
    setLoading(true);
    try {
      const data = await api.get<ProductListItem[]>("/products?size=50");
      const list = Array.isArray(data)
        ? data
        : ((data as unknown as { items: ProductListItem[] }).items ?? []);
      setItems(list);
    } catch (err) {
      console.error("LOAD PRODUCTS ERROR:", err);
      notify("Не удалось загрузить товары", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadDetail = async (pid: string) => {

    try {
      const d = await api.get<ProductDetail>(`/products/${pid}`);
      setDetail(d);

      const initial: Record<string, string> = {};
      d.variants.forEach((v) => {
        initial[v.id] = String(v.stock);
      });

      setStockEdits(initial);
      setEdit({
        name: d.name,
        description: d.description,
        price: d.price,
        composition: d.composition,
        density: d.density,
        care: d.care,
        extra_info: d.extra_info,
        category_id: d.category_id,
        is_active: d.is_active,
      });
      if (d.sizes?.length) setAllSizes(d.sizes);
    } catch (err) {
      console.error("LOAD DETAIL ERROR:", err);
      notify("Не удалось загрузить товар", "error");
    }
  };

  const toggleOpen = async (pid: string) => {
    if (openId === pid) {
      setOpenId(null);
      setDetail(null);
      return;
    }
    setOpenId(pid);
    setDetail(null);
    await loadDetail(pid);
  };

  const createProduct = async () => {
    if (!draft.name.trim() || !draft.sku.trim()) {
      notify("Название и артикул обязательны", "error");
      return;
    }
    try {
      const created = await adminApi.createProduct({
        ...draft,
        name: draft.name.trim(),
        sku: draft.sku.trim(),
        price: Number(draft.price) as unknown as ProductCreate["price"],
      });
      notify("Товар создан", "success");
      setShowCreate(false);
      setDraft(emptyCreate);
      await load();
      toggleOpen(created.id);
    } catch (err) {
      console.error("CREATE PRODUCT ERROR:", err);
      notify("Не удалось создать товар", "error");
    }
  };

  const saveEdit = async (pid: string) => {
    try {
      await adminApi.updateProduct(pid, {
        ...edit,
        price:
          edit.price != null
            ? (Number(edit.price) as unknown as ProductUpdate["price"])
            : undefined,
      });
      notify("Сохранено", "success");
      await load();
      await loadDetail(pid);
    } catch (err) {
      console.error("UPDATE PRODUCT ERROR:", err);
      notify("Не удалось сохранить", "error");
    }
  };

  const removeProduct = async (pid: string) => {
    if (!confirm("Удалить товар?")) return;
    try {
      await adminApi.deleteProduct(pid);
      notify("Удалено", "success");
      if (openId === pid) {
        setOpenId(null);
        setDetail(null);
      }
      await load();
    } catch (err) {
      console.error("DELETE PRODUCT ERROR:", err);
      notify("Не удалось удалить", "error");
    }
  };

  const addImage = async (pid: string) => {
    if (!imgUrl.trim()) return;
    try {
      await adminApi.addImage(pid, {
        url: imgUrl.trim(),
        position: detail?.images.length ?? 0,
      });
      setImgUrl("");
      notify("Фото добавлено", "success");
      await loadDetail(pid);
    } catch (err) {
      console.error("ADD IMAGE ERROR:", err);
      notify("Не удалось добавить фото", "error");
    }
  };

  const addColor = async (pid: string) => {
    if (!colorName.trim()) return;
    try {
      await adminApi.addColor(pid, { name: colorName.trim(), hex: colorHex });
      setColorName("");
      setColorHex("#000000");
      notify("Цвет добавлен", "success");
      await loadDetail(pid);
    } catch (err) {
      console.error("ADD COLOR ERROR:", err);
      notify("Не удалось добавить цвет", "error");
    }
  };

  const addVariant = async (pid: string) => {
    if (!varColor || !varSize) {
      notify("Выберите цвет и размер", "error");
      return;
    }
    try {
      await adminApi.upsertVariant(pid, {
        color_id: varColor,
        size_id: varSize,
        stock: Number(varStock) || 0,
      });
      setVarStock("0");
      notify("Наличие обновлено", "success");
      await loadDetail(pid);
    } catch (err) {
      console.error("UPSERT VARIANT ERROR:", err);
      notify("Не удалось обновить наличие", "error");
    }
  };

    const saveStock = async (pid: string, v: components["schemas"]["VariantOut"]) => {
    const raw = stockEdits[v.id];
    const stock = Number(raw);
    if (Number.isNaN(stock) || stock < 0) {
      notify("Некорректное количество", "error");
      return;
    }
    try {
      await adminApi.upsertVariant(pid, {
        color_id: v.color_id,
        size_id: v.size_id,
        stock,
      });
      notify("Остаток обновлён", "success");
      await loadDetail(pid);
    } catch (err) {
      console.error("SAVE STOCK ERROR:", err);
      notify("Не удалось обновить остаток", "error");
    }
  };

  const sizesForSelect: SizeOut[] = detail?.sizes?.length
    ? detail.sizes
    : allSizes;
  const colorsForSelect: ColorOut[] = detail?.colors ?? [];

  return (
    <div className="admin-products">
        <div className="admin-products__top">
          <button
            className={`admin-btn ${showCreate ? "admin-btn--ghost" : ""}`}
            onClick={() => setShowCreate((v) => !v)}
          >
            {showCreate ? "Отмена" : "+ Новый товар"}
          </button>
          <button className="admin-btn admin-btn--ghost" onClick={load}>
            ↻ Обновить
          </button>
      </div>

      {showCreate && (
        <div className="admin-product-form">
          <input
            placeholder="Название"
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
          />
          <input
            placeholder="Артикул (SKU)"
            value={draft.sku}
            onChange={(e) => setDraft({ ...draft, sku: e.target.value })}
          />
          <input
            placeholder="Цена, ₽"
            type="number"
            value={String(draft.price)}
            onChange={(e) =>
              setDraft({
                ...draft,
                price: e.target.value as unknown as ProductCreate["price"],
              })
            }
          />
          <input
            placeholder="Категория ID (необязательно)"
            value={draft.category_id ?? ""}
            onChange={(e) =>
              setDraft({ ...draft, category_id: e.target.value || null })
            }
          />
          <textarea
            placeholder="Описание"
            value={draft.description}
            onChange={(e) =>
              setDraft({ ...draft, description: e.target.value })
            }
          />
          <input
            placeholder="Состав (100% хлопок)"
            value={draft.composition}
            onChange={(e) =>
              setDraft({ ...draft, composition: e.target.value })
            }
          />
          <input
            placeholder="Плотность (180 г/м²)"
            value={draft.density}
            onChange={(e) => setDraft({ ...draft, density: e.target.value })}
          />
          <input
            placeholder="Уход"
            value={draft.care}
            onChange={(e) => setDraft({ ...draft, care: e.target.value })}
          />

          <label className="admin-toggle">
            <span className="admin-toggle__label">
              Товар активен
              <small>показывать в каталоге</small>
            </span>
            <span className="admin-toggle__switch">
              <input
                type="checkbox"
                checked={draft.is_active}
                onChange={(e) =>
                  setDraft({ ...draft, is_active: e.target.checked })
                }
              />
              <span className="admin-toggle__slider" />
            </span>
          </label>
          <button onClick={createProduct}>Создать</button>
        </div>
      )}

      {loading ? (
        <p>Загрузка…</p>
      ) : items.length === 0 ? (
        <p>Товаров нет</p>
      ) : (
        <div className="admin-products__list">
          {items.map((p) => (
            <div className="admin-product" key={p.id}>
              <div className="admin-product__row" onClick={() => toggleOpen(p.id)}>
                {p.image && (
                  <img className="admin-product__thumb" src={p.image} alt="" />
                )}
                <div className="admin-product__info">
                  <b>{p.name}</b>
                  <span className="admin-product__sku">{p.sku}</span>
                </div>
                <span className="admin-product__price">{String(p.price)} ₽</span>
                <span
                  className={`admin-product__badge ${
                    p.is_active ? "is-on" : "is-off"
                  }`}
                >
                  {p.is_active ? "вкл" : "выкл"}
                </span>
              </div>

              {openId === p.id && (
                <div className="admin-product__edit">
                  {!detail ? (
                    <p>Загрузка…</p>
                  ) : (
                    <>
                      <div className="admin-product-form">
                        <input
                          placeholder="Название"
                          value={edit.name ?? ""}
                          onChange={(e) =>
                            setEdit({ ...edit, name: e.target.value })
                          }
                        />
                        <input
                          placeholder="Цена, ₽"
                          type="number"
                          value={String(edit.price ?? "")}
                          onChange={(e) =>
                            setEdit({
                              ...edit,
                              price:
                                e.target.value as unknown as ProductUpdate["price"],
                            })
                          }
                        />
                        <input
                          placeholder="Категория ID"
                          value={edit.category_id ?? ""}
                          onChange={(e) =>
                            setEdit({
                              ...edit,
                              category_id: e.target.value || null,
                            })
                          }
                        />
                        <textarea
                          placeholder="Описание"
                          value={edit.description ?? ""}
                          onChange={(e) =>
                            setEdit({ ...edit, description: e.target.value })
                          }
                        />
                        <input
                          placeholder="Состав"
                          value={edit.composition ?? ""}
                          onChange={(e) =>
                            setEdit({ ...edit, composition: e.target.value })
                          }
                        />
                        <input
                          placeholder="Плотность"
                          value={edit.density ?? ""}
                          onChange={(e) =>
                            setEdit({ ...edit, density: e.target.value })
                          }
                        />
                        <input
                          placeholder="Уход"
                          value={edit.care ?? ""}
                          onChange={(e) =>
                            setEdit({ ...edit, care: e.target.value })
                          }
                        />
                        <label className="admin-toggle">
                          <span className="admin-toggle__label">
                            Товар активен
                            <small>показывать в каталоге</small>
                          </span>
                          <span className="admin-toggle__switch">
                            <input
                              type="checkbox"
                              checked={edit.is_active ?? true}
                              onChange={(e) =>
                                setEdit({ ...edit, is_active: e.target.checked })
                              }
                            />
                            <span className="admin-toggle__slider" />
                          </span>
                        </label>
                        <div className="admin-product__actions">
                          <button onClick={() => saveEdit(p.id)}>
                            Сохранить
                          </button>
                          <button
                            className="danger"
                            onClick={() => removeProduct(p.id)}
                          >
                            Удалить товар
                          </button>
                        </div>
                      </div>

                      <div className="admin-block">
                        <h4>Фото</h4>
                        <div className="admin-thumbs">
                          {detail.images.map((im) => (
                            <img key={im.id} src={im.url} alt="" />
                          ))}
                        </div>
                        <div className="admin-inline">
                          <input
                            placeholder="URL фото (/media/...)"
                            value={imgUrl}
                            onChange={(e) => setImgUrl(e.target.value)}
                          />
                          <button onClick={() => addImage(p.id)}>
                            Добавить
                          </button>
                        </div>
                      </div>

                      <div className="admin-block">
                        <h4>Цвета</h4>
                        <div className="admin-colors">
                          {detail.colors.map((c) => (
                            <span key={c.id} className="admin-color">
                              <i style={{ background: c.hex }} />
                              {c.name}
                            </span>
                          ))}
                        </div>
                        <div className="admin-inline">
                          <input
                            placeholder="Название цвета"
                            value={colorName}
                            onChange={(e) => setColorName(e.target.value)}
                          />
                          <input
                            type="color"
                            value={colorHex}
                            onChange={(e) => setColorHex(e.target.value)}
                          />
                          <button onClick={() => addColor(p.id)}>
                            Добавить
                          </button>
                        </div>
                      </div>

                      <div className="admin-block">
                        <h4>Наличие (размер × цвет)</h4>

                        {detail.variants.length > 0 ? (
                          <div className="admin-stock-table">
                            {detail.variants.map((v) => (
                              <div className="admin-stock-row" key={v.id}>
                                <span className="admin-stock-name">
                                  {v.size_label} / {v.color_name}
                                </span>
                                <input
                                  className="admin-stock-input"
                                  type="number"
                                  min={0}
                                  value={stockEdits[v.id] ?? String(v.stock)}
                                  onChange={(e) =>
                                    setStockEdits((s) => ({
                                      ...s,
                                      [v.id]: e.target.value,
                                    }))
                                  }
                                />
                                <span
                                  className={`admin-stock-badge ${
                                    Number(stockEdits[v.id] ?? v.stock) > 0
                                      ? "is-on"
                                      : "is-off"
                                  }`}
                                >
                                  {Number(stockEdits[v.id] ?? v.stock) > 0
                                    ? "в наличии"
                                    : "нет"}
                                </span>
                                <button
                                  className="admin-btn admin-btn--sm"
                                  onClick={() => saveStock(p.id, v)}
                                >
                                  Сохранить
                                </button>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="admin-hint">Вариантов пока нет.</p>
                        )}

                        <h4 style={{ marginTop: 12 }}>Добавить комбинацию</h4>
                        <div className="admin-inline">
                          <select
                            value={varColor}
                            onChange={(e) => setVarColor(e.target.value)}
                          >
                            <option value="">Цвет</option>
                            {colorsForSelect.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.name}
                              </option>
                            ))}
                          </select>
                          <select
                            value={varSize}
                            onChange={(e) => setVarSize(e.target.value)}
                          >
                            <option value="">Размер</option>
                            {sizesForSelect.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.label}
                              </option>
                            ))}
                          </select>
                          <input
                            type="number"
                            min={0}
                            placeholder="Кол-во"
                            value={varStock}
                            onChange={(e) => setVarStock(e.target.value)}
                          />
                          <button
                            className="admin-btn admin-btn--sm"
                            onClick={() => addVariant(p.id)}
                          >
                            Добавить
                          </button>
                        </div>
                        {!colorsForSelect.length && (
                          <p className="admin-hint">
                            Сначала добавьте хотя бы один цвет.
                          </p>
                        )}
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}