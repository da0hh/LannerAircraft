import { useEffect, useState } from "react";
import { adminApi } from "@/lib/adminApi";
import { useUi } from "@/store/ui";
import type { components } from "@/api/schema";
import "./admin.css";

type PromoOut = components["schemas"]["PromoOut"];
type PromoType = components["schemas"]["PromoType"]; // "PERCENT" | "FIXED"

const empty = {
  code: "",
  type: "PERCENT" as PromoType,
  value: "",
  max_uses: "", // "" => без лимита => 0
  expires_at: "",
  is_active: true,
};

export function AdminPromos() {
  const notify = useUi((s) => s.notify);
  const [items, setItems] = useState<PromoOut[]>([]);
  const [loading, setLoading] = useState(true);

  const [form, setForm] = useState({ ...empty });
  const [editId, setEditId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const data = await adminApi.listPromos();
      setItems(data);
    } catch (err) {
      console.error("LOAD PROMOS ERROR:", err);
      notify("Не удалось загрузить промокоды", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const resetForm = () => {
    setForm({ ...empty });
    setEditId(null);
  };

    const submit = async () => {
    if (!form.code.trim()) {
      notify("Укажите код", "error");
      return;
    }
    if (!form.value.trim()) {
      notify("Укажите размер скидки", "error");
      return;
    }

    const base = {
      type: form.type,
      value: String(form.value).trim(),
      max_uses: form.max_uses === "" ? 0 : Number(form.max_uses),
      expires_at: form.expires_at
        ? new Date(form.expires_at).toISOString()
        : null,
      is_active: form.is_active,
    };

    try {
      if (editId) {
        await adminApi.updatePromo(editId, base as any);
        notify("Промокод обновлён", "success");
      } else {
        await adminApi.createPromo({
          code: form.code.trim().toUpperCase(),
          ...base,
        } as any);
        notify("Промокод создан", "success");
      }
      resetForm();
      load();
    } catch (err) {
      console.error("SAVE PROMO ERROR:", err);
      notify("Не удалось сохранить промокод", "error");
    }
  };

  const startEdit = (p: PromoOut) => {
    setEditId(p.id);
    setForm({
      code: p.code,
      type: p.type,
      value: p.value,
      max_uses: !p.max_uses ? "" : String(p.max_uses),
      expires_at: p.expires_at
        ? new Date(p.expires_at).toISOString().slice(0, 16)
        : "",
      is_active: p.is_active,
    });
  };

  const remove = async (pid: string) => {
    if (!confirm("Удалить промокод?")) return;
    try {
      await adminApi.deletePromo(pid);
      notify("Удалено", "success");
      load();
    } catch (err) {
      console.error("DELETE PROMO ERROR:", err);
      notify("Не удалось удалить", "error");
    }
  };

  return (
    <div className="admin-promos">
      <div className="admin-promos__form">
        <h3>{editId ? "Редактирование промокода" : "Новый промокод"}</h3>

        <input
          placeholder="Код (например SALE20)"
          value={form.code}
          onChange={(e) => setForm({ ...form, code: e.target.value })}
        />

        <div className="admin-promos__row">
          <select
            value={form.type}
            onChange={(e) =>
              setForm({ ...form, type: e.target.value as PromoType })
            }
          >
            <option value="PERCENT">Процент %</option>
            <option value="FIXED">Фикс. сумма ₽</option>
          </select>
          <input
            type="number"
            placeholder="Размер скидки"
            value={form.value}
            onChange={(e) => setForm({ ...form, value: e.target.value })}
          />
        </div>

        <input
          type="number"
          placeholder="Лимит использований (пусто = без лимита)"
          value={form.max_uses}
          onChange={(e) => setForm({ ...form, max_uses: e.target.value })}
        />

        <label className="admin-promos__field">
          <span>Действует до</span>
          <input
            type="datetime-local"
            value={form.expires_at}
            onChange={(e) => setForm({ ...form, expires_at: e.target.value })}
          />
        </label>

        <label className="admin-promos__check">
          <input
            type="checkbox"
            checked={form.is_active}
            onChange={(e) => setForm({ ...form, is_active: e.target.checked })}
          />
          Активен
        </label>

        <div className="admin-promos__actions">
          <button onClick={submit}>{editId ? "Сохранить" : "Добавить"}</button>
          {editId && <button onClick={resetForm}>Отмена</button>}
        </div>
      </div>

      {loading ? (
        <p>Загрузка…</p>
      ) : items.length === 0 ? (
        <p>Промокодов нет</p>
      ) : (
        <div className="admin-promos__list">
          {items.map((p) => (
            <div className="admin-promo" key={p.id}>
              <div className="admin-promo__info">
                <b>{p.code}</b>
                <span>
                  {p.type === "PERCENT" ? `${p.value}%` : `${p.value} ₽`}
                </span>
                <span>
                  {!p.max_uses
                    ? "без лимита"
                    : `${p.used_count ?? 0}/${p.max_uses}`}
                </span>
                <span>
                  {p.expires_at
                    ? `до ${new Date(p.expires_at).toLocaleDateString()}`
                    : "бессрочно"}
                </span>
                <span>{p.is_active ? "активен" : "скрыт"}</span>
              </div>
              <div className="admin-promo__buttons">
                <button onClick={() => startEdit(p)}>Изменить</button>
                <button onClick={() => remove(p.id)}>Удалить</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}