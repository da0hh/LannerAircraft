import { useEffect, useState } from "react";
import { api, setToken, ApiError } from "@/lib/api";
import { getInitData } from "@/lib/telegram";
import type { AuthResponse, UserOut } from "@/types";

export function useAuth() {
  const [user, setUser] = useState<UserOut | null>(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const initData = getInitData();
    api
      .post<AuthResponse>("/auth/telegram", { init_data: initData }, { auth: false })
      .then((res) => {
        setToken(res.token);
        setUser(res.user);
      })
      .catch((e: ApiError) => {
        setUser(null);
        setError(e.message);
      })
      .finally(() => setReady(true));
  }, []);

  return { user, ready, error };
}