import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export interface Banner {
  id: string;
  title: string;
  image_url: string;
  link: string | null;
  position: number;
}

export function useBanners() {
  return useQuery({
    queryKey: ["banners"],
    queryFn: () => api.get<Banner[]>("/banners"),
    staleTime: 5 * 60 * 1000,
  });
}