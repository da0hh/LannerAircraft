export * from "./useProducts";
export { useProducts as useCatalog } from "./useProducts";