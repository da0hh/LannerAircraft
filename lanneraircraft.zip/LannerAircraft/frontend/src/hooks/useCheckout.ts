import { useState, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { api, ApiError } from "@/lib/api";
import { useCart } from "./useCart";
import { useTelegram } from "./useTelegram";
import type { DeliveryMethod } from "./useDelivery";

export interface CheckoutForm {
  firstName: string;
  lastName: string;
  phone: string;
  deliveryMethod: DeliveryMethod;
  city: string;
  address: string;
  pvzCode: string | null;
  comment: string;
  promoCode: string | null;
}

export interface CreateOrderResponse {
  order_id: string;
  number: number;
  total: string;
  invoice_url: string | null;
}

const emptyForm: CheckoutForm = {
  firstName: "",
  lastName: "",
  phone: "",
  deliveryMethod: "pickup",
  city: "",
  address: "",
  pvzCode: null,
  comment: "",
  promoCode: null,
};

export function useCheckout() {
  const { items, clear } = useCart();
  const { initData, openInvoice, showAlert, haptic } = useTelegram();
  const [form, setForm] = useState<CheckoutForm>(emptyForm);

  const update = useCallback(
    <K extends keyof CheckoutForm>(key: K, value: CheckoutForm[K]) =>
      setForm((f) => ({ ...f, [key]: value })),
    []
  );

  const validate = useCallback((): string | null => {
    if (!form.firstName.trim()) return "Укажите имя";
    if (!form.phone.trim()) return "Укажите телефон";
    if (!/^\+?\d[\d\s\-()]{9,}$/.test(form.phone)) return "Некорректный телефон";
    if (form.deliveryMethod === "courier" && !form.address.trim())
      return "Укажите адрес доставки";
    if (form.deliveryMethod === "cdek" && !form.pvzCode)
      return "Выберите пункт выдачи";
    if (!items.length) return "Корзина пуста";
    return null;
  }, [form, items]);

  const mutation = useMutation({
    mutationFn: (payload: CheckoutForm) =>
      api.post<CreateOrderResponse>(
        "/orders",
        {
          init_data: initData,
          customer: {
            first_name: payload.firstName,
            last_name: payload.lastName,
            phone: payload.phone,
          },
          delivery: {
            method: payload.deliveryMethod,
            city: payload.city || null,
            address: payload.address || null,
            pvz_code: payload.pvzCode,
            comment: payload.comment || null,
          },
          promo_code: payload.promoCode,
          items: items.map((i) => ({
            variant_id: i.variantId,
            quantity: i.quantity,
          })),
        }
      ),
  });

  const submit = useCallback(async (): Promise<CreateOrderResponse | null> => {
    const err = validate();
    if (err) {
      haptic("error");
      showAlert(err);
      return null;
    }

    try {
      const res = await mutation.mutateAsync(form);

      if (res.invoice_url) {
        const status = await openInvoice(res.invoice_url);
        if (status === "paid") {
          haptic("success");
          clear();
          return res;
        }
        if (status === "failed") {
          haptic("error");
          showAlert("Не удалось провести оплату");
        }
        return status === "paid" ? res : null;
      }

      haptic("success");
      clear();
      return res;
    } catch (e) {
      haptic("error");
      if (e instanceof ApiError) {
        showAlert(
          e.code === "OUT_OF_STOCK"
            ? "Некоторые товары закончились"
            : e.message || "Ошибка при оформлении заказа"
        );
      } else {
        showAlert("Ошибка сети");
      }
      return null;
    }
  }, [form, validate, mutation, openInvoice, haptic, showAlert, clear]);

  return {
    form,
    update,
    submit,
    validate,
    isSubmitting: mutation.isPending,
    reset: () => setForm(emptyForm),
  };
}