import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export type DeliveryMethod = "pickup" | "courier" | "cdek";

export interface DeliveryOption {
  method: DeliveryMethod;
  title: string;
  description: string;
  cost: string;
  min_days: number;
  max_days: number;
  requires_address: boolean;
  requires_pvz: boolean;
}

export interface PvzPoint {
  code: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
}

export function useDeliveryOptions(subtotal: number) {
  return useQuery({
    queryKey: ["delivery-options", subtotal],
    queryFn: () =>
      api.get<DeliveryOption[]>(`/delivery/options?subtotal=${subtotal.toFixed(2)}`),
    staleTime: 60 * 1000,
  });
}

export function usePvzPoints(city: string | null) {
  return useQuery({
    queryKey: ["pvz", city],
    queryFn: () => api.get<PvzPoint[]>(`/delivery/pvz?city=${encodeURIComponent(city ?? "")}`),
    enabled: !!city && city.length >= 2,
  });
}