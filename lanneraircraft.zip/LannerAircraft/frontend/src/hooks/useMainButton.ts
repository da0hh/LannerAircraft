import { useEffect } from "react";
import { useTelegram } from "./useTelegram";

interface Options {
  text: string;
  visible: boolean;
  active?: boolean;
  loading?: boolean;
  onClick: () => void;
}

export function useMainButton({
  text,
  visible,
  active = true,
  loading = false,
  onClick,
}: Options) {
  const { mainButton } = useTelegram();

  useEffect(() => {
    if (!mainButton) return;
    mainButton.setText(text);
    mainButton.onClick(onClick);
    return () => mainButton.offClick(onClick);
  }, [mainButton, text, onClick]);

  useEffect(() => {
    if (!mainButton) return;
    if (visible) mainButton.show();
    else mainButton.hide();
    return () => mainButton.hide();
  }, [mainButton, visible]);

  useEffect(() => {
    if (!mainButton) return;
    if (loading) mainButton.showProgress();
    else mainButton.hideProgress();
    if (active && !loading) mainButton.enable();
    else mainButton.disable();
  }, [mainButton, active, loading]);
}