import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useTelegram } from "./useTelegram";

export interface OrderListItem {
  id: string;
  number: number;
  status: string;
  total: string;
  items_count: number;
  created_at: string;
  preview_images: string[];
}

export interface OrderItemDetail {
  product_name: string;
  slug: string;
  color_name: string;
  size_label: string;
  quantity: number;
  unit_price: string;
  image_url: string | null;
}

export interface OrderDetail {
  id: string;
  number: number;
  status: string;
  subtotal: string;
  discount: string;
  delivery_cost: string;
  total: string;
  promo_code: string | null;
  created_at: string;
  delivery: {
    method: string;
    city: string | null;
    address: string | null;
    pvz_code: string | null;
    comment: string | null;
    tracking: string | null;
  };
  items: OrderItemDetail[];
}

export function useOrders() {
  const { initData, isTelegram } = useTelegram();
  return useQuery({
    queryKey: ["orders"],
    queryFn: () =>
      api.get<OrderListItem[]>(
        `/orders/my?init_data=${encodeURIComponent(initData)}`
      ),
    enabled: isTelegram && !!initData,
  });
}

export function useOrder(orderId: string | undefined) {
  const { initData } = useTelegram();
  return useQuery({
    queryKey: ["order", orderId],
    queryFn: () =>
      api.get<OrderDetail>(
        `/orders/${orderId}?init_data=${encodeURIComponent(initData)}`
      ),
    enabled: !!orderId && !!initData,
  });
}