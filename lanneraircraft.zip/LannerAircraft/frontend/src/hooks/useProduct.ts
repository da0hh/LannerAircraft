import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

export interface ProductVariant {
  id: string;
  color_id: string;
  size_id: string;
  stock: number;
}

export interface ProductColor {
  id: string;
  name: string;
  hex: string;
}

export interface ProductSize {
  id: string;
  label: string;
  sort: number;
}

export interface ProductImage {
  id: string;
  url: string;
  position: number;
}

export interface ProductDetail {
  id: string;
  name: string;
  slug: string;
  sku: string;
  description: string;
  composition: string;
  density: string;
  care: string;
  price: string;
  old_price: string | null;
  images: ProductImage[];
  colors: ProductColor[];
  sizes: ProductSize[];
  variants: ProductVariant[];
  category: { id: string; name: string; slug: string } | null;
}

export function useProduct(slug: string | undefined) {
  return useQuery({
    queryKey: ["product", slug],
    queryFn: () => api.get<ProductDetail>(`/products/${slug}`),
    enabled: !!slug,
  });
}

export function findVariant(
  product: ProductDetail | undefined,
  colorId: string | null,
  sizeId: string | null
): ProductVariant | null {
  if (!product || !colorId || !sizeId) return null;
  return product.variants.find((v) => v.color_id === colorId && v.size_id === sizeId) ?? null;
}

export function availableSizesForColor(
  product: ProductDetail | undefined,
  colorId: string | null
): Set<string> {
  const set = new Set<string>();
  if (!product || !colorId) return set;
  product.variants.forEach((v) => {
    if (v.color_id === colorId && v.stock > 0) set.add(v.size_id);
  });
  return set;
}

export function availableColors(product: ProductDetail | undefined): Set<string> {
  const set = new Set<string>();
  if (!product) return set;
  product.variants.forEach((v) => {
    if (v.stock > 0) set.add(v.color_id);
  });
  return set;
}