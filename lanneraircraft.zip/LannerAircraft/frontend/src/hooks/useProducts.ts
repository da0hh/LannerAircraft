import type { ProductListItem } from "@/types";
import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { api } from "@/lib/api";

export const SIZE_OPTIONS = ["S", "M", "L", "XL"] as const;

export interface Category {
  id: string;
  name: string;
  slug: string;
  image_url: string | null;
  product_count: number;
}

export interface ProductCard {
  id: string;
  name: string;
  slug: string;
  price: string;
  old_price: string | null;
  image_url: string | null;
  in_stock: boolean;
  colors: { id: string; hex: string }[];
}

export interface CatalogParams {
  category_id?: string;
  search?: string;
  sort?: "popular" | "price_asc" | "price_desc" | "new";
  type?: string;
  gender?: string[];
  fit?: string[];
  neckline?: string[];
  color?: string[];
  variant_size?: string[];
  price_min?: number;
  price_max?: number;
  page?: number;
  size?: number;
}

export interface CatalogResponse {
  items: ProductListItem[];
  total: number;
  page: number;
  size: number;
}

function buildQuery(p: CatalogParams): string {
  const q = new URLSearchParams();
  const add = (k: string, v: unknown) => {
    if (v === undefined || v === null || v === "") return;
    q.append(k, String(v));
  };
  add("category_id", p.category_id);
  add("search", p.search);
  add("sort", p.sort);
  add("type", p.type);
  add("price_min", p.price_min);
  add("price_max", p.price_max);
  add("page", p.page);
  add("size", p.size);
  p.gender?.forEach((v) => add("gender", v));
  p.fit?.forEach((v) => add("fit", v));
  p.neckline?.forEach((v) => add("neckline", v));
  p.color?.forEach((v) => add("color", v));
  p.variant_size?.forEach((v) => add("variant_size", v));
  const s = q.toString();
  return s ? `?${s}` : "";
}

export function useCategories() {
  return useQuery({
    queryKey: ["categories"],
    queryFn: () => api.get<Category[]>("/categories"),
    staleTime: 5 * 60 * 1000,
  });
}

export function useProducts(params: CatalogParams) {
  return useQuery({
    queryKey: ["catalog", params],
    queryFn: () => api.get<CatalogResponse>(`/products${buildQuery(params)}`),
    placeholderData: keepPreviousData,
  });
}