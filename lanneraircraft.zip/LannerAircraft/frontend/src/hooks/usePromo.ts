import { useState, useCallback } from "react";
import { api, ApiError } from "@/lib/api";

export interface AppliedPromo {
  code: string;
  discount_type: "percent" | "fixed";
  discount_value: string;
  discount_amount: string;
}

export function usePromo(subtotal: number) {
  const [promo, setPromo] = useState<AppliedPromo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const apply = useCallback(
    async (code: string) => {
      setLoading(true);
      setError(null);
      try {
        const res = await api.post<AppliedPromo>("/promo/validate", {
          code: code.trim().toUpperCase(),
          subtotal: subtotal.toFixed(2),
        });
        setPromo(res);
        return true;
      } catch (e) {
        if (e instanceof ApiError) {
          setError(
            e.code === "PROMO_NOT_FOUND"
              ? "Промокод не найден"
              : e.code === "PROMO_EXPIRED"
              ? "Промокод истёк"
              : e.code === "PROMO_MIN_SUBTOTAL"
              ? "Сумма заказа слишком мала для этого промокода"
              : e.code === "PROMO_LIMIT_REACHED"
              ? "Лимит использований исчерпан"
              : "Не удалось применить промокод"
          );
        } else {
          setError("Ошибка сети");
        }
        setPromo(null);
        return false;
      } finally {
        setLoading(false);
      }
    },
    [subtotal]
  );

  const reset = useCallback(() => {
    setPromo(null);
    setError(null);
  }, []);

  return { promo, error, loading, apply, reset };
}