import { useEffect, useMemo, useCallback } from "react";

type TgWebApp = {
  initData: string;
  initDataUnsafe: {
    user?: { id: number; first_name: string; last_name?: string; username?: string; photo_url?: string };
    start_param?: string;
  };
  colorScheme: "light" | "dark";
  themeParams: Record<string, string>;
  viewportHeight: number;
  isExpanded: boolean;
  ready: () => void;
  expand: () => void;
  close: () => void;
  MainButton: {
    text: string;
    isVisible: boolean;
    isActive: boolean;
    show: () => void;
    hide: () => void;
    enable: () => void;
    disable: () => void;
    setText: (t: string) => void;
    onClick: (cb: () => void) => void;
    offClick: (cb: () => void) => void;
    showProgress: (leaveActive?: boolean) => void;
    hideProgress: () => void;
  };
  BackButton: {
    isVisible: boolean;
    show: () => void;
    hide: () => void;
    onClick: (cb: () => void) => void;
    offClick: (cb: () => void) => void;
  };
  HapticFeedback: {
    impactOccurred: (style: "light" | "medium" | "heavy" | "rigid" | "soft") => void;
    notificationOccurred: (type: "error" | "success" | "warning") => void;
    selectionChanged: () => void;
  };
  openInvoice: (url: string, cb: (status: "paid" | "cancelled" | "failed" | "pending") => void) => void;
  showConfirm: (message: string, cb: (ok: boolean) => void) => void;
  showAlert: (message: string, cb?: () => void) => void;
  setHeaderColor: (color: string) => void;
  setBackgroundColor: (color: string) => void;
  onEvent: (event: string, cb: () => void) => void;
  offEvent: (event: string, cb: () => void) => void;
};

declare global {
  interface Window {
    Telegram?: { WebApp: TgWebApp };
  }
}

export function useTelegram() {
  const tg = useMemo<TgWebApp | null>(() => window.Telegram?.WebApp ?? null, []);

    useEffect(() => {
    if (!tg) {
      const mq = window.matchMedia("(prefers-color-scheme: dark)");
      const applySystem = () =>
        document.documentElement.setAttribute(
          "data-theme",
          mq.matches ? "dark" : "light"
        );
      applySystem();
      mq.addEventListener?.("change", applySystem);
      return () => mq.removeEventListener?.("change", applySystem);
    }

    tg.ready();
    tg.expand();

    const applyTheme = () => {
      document.documentElement.setAttribute("data-theme", tg.colorScheme);

      const p = tg.themeParams;
      if (p.bg_color) {
        tg.setHeaderColor(p.bg_color);
        tg.setBackgroundColor(p.bg_color);
      }
    };

    applyTheme();
    tg.onEvent("themeChanged", applyTheme);

    return () => tg.offEvent("themeChanged", applyTheme);
  }, [tg]);

  const user = tg?.initDataUnsafe.user ?? null;
  const startParam = tg?.initDataUnsafe.start_param ?? null;
  const initData = tg?.initData ?? "";

  const haptic = useCallback(
    (type: "light" | "medium" | "heavy" | "success" | "error" | "warning" | "select") => {
      if (!tg) return;
      if (type === "success" || type === "error" || type === "warning") {
        tg.HapticFeedback.notificationOccurred(type);
      } else if (type === "select") {
        tg.HapticFeedback.selectionChanged();
      } else {
        tg.HapticFeedback.impactOccurred(type);
      }
    },
    [tg]
  );

  const showConfirm = useCallback(
    (message: string) =>
      new Promise<boolean>((resolve) => {
        if (!tg) return resolve(window.confirm(message));
        tg.showConfirm(message, resolve);
      }),
    [tg]
  );

  const showAlert = useCallback(
    (message: string) => {
      if (!tg) return window.alert(message);
      tg.showAlert(message);
    },
    [tg]
  );

  const openInvoice = useCallback(
    (url: string) =>
      new Promise<"paid" | "cancelled" | "failed" | "pending">((resolve) => {
        if (!tg) return resolve("failed");
        tg.openInvoice(url, resolve);
      }),
    [tg]
  );

  const close = useCallback(() => tg?.close(), [tg]);

  return {
    tg,
    user,
    initData,
    startParam,
    isTelegram: !!tg,
    colorScheme: tg?.colorScheme ?? "light",
    haptic,
    showConfirm,
    showAlert,
    openInvoice,
    close,
    mainButton: tg?.MainButton ?? null,
    backButton: tg?.BackButton ?? null,
  };
}