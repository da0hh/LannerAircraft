import { api } from "@/lib/api";
import type { components } from "@/api/schema";

type OrderOut = components["schemas"]["OrderOut"];
type OrderStatus = components["schemas"]["OrderStatus"];
type OrderStatusUpdate = components["schemas"]["OrderStatusUpdate"];

type ProductDetail = components["schemas"]["ProductDetail"];
type ProductCreate = components["schemas"]["ProductCreate"];
type ProductUpdate = components["schemas"]["ProductUpdate"];

type CategoryOut = components["schemas"]["CategoryOut"];
type CategoryCreate = components["schemas"]["CategoryCreate"];
type CategoryUpdate = components["schemas"]["CategoryUpdate"];

type PromoOut = components["schemas"]["PromoOut"];
type PromoCreate = components["schemas"]["PromoCreate"];
type PromoUpdate = components["schemas"]["PromoUpdate"];

type BannerOut = components["schemas"]["BannerOut"];
type BannerCreate = components["schemas"]["BannerCreate"];
type BannerUpdate = components["schemas"]["BannerUpdate"];

type ImageCreate = components["schemas"]["ImageCreate"];
type ColorCreate = components["schemas"]["ColorCreate"];
type VariantUpsert = components["schemas"]["VariantUpsert"];

export const adminApi = {
  // ─── Orders ───
  listOrders: (status?: OrderStatus) =>
    api.get<OrderOut[]>(
      `/admin/orders${status ? `?status=${status}` : ""}`
    ),
  updateOrderStatus: (oid: string, body: OrderStatusUpdate) =>
    api.patch<OrderOut>(`/admin/orders/${oid}/status`, body),

  // ─── Categories ───
  createCategory: (body: CategoryCreate) =>
    api.post<CategoryOut>("/admin/categories", body),
  updateCategory: (cid: string, body: CategoryUpdate) =>
    api.patch<CategoryOut>(`/admin/categories/${cid}`, body),
  deleteCategory: (cid: string) =>
    api.delete<unknown>(`/admin/categories/${cid}`),

  // ─── Products ───
  createProduct: (body: ProductCreate) =>
    api.post<ProductDetail>("/admin/products", body),
  updateProduct: (pid: string, body: ProductUpdate) =>
    api.patch<ProductDetail>(`/admin/products/${pid}`, body),
  deleteProduct: (pid: string) =>
    api.delete<unknown>(`/admin/products/${pid}`),
  addImage: (pid: string, body: ImageCreate) =>
    api.post<unknown>(`/admin/products/${pid}/images`, body),
  addColor: (pid: string, body: ColorCreate) =>
    api.post<components["schemas"]["ColorOut"]>(
      `/admin/products/${pid}/colors`,
      body
    ),
  upsertVariant: (pid: string, body: VariantUpsert) =>
    api.post<unknown>(`/admin/products/${pid}/variants`, body),

  // ─── Promo ───
  listPromos: () => api.get<PromoOut[]>("/admin/promo-codes"),
  createPromo: (body: PromoCreate) =>
    api.post<PromoOut>("/admin/promo-codes", body),
  updatePromo: (pid: string, body: PromoUpdate) =>
    api.patch<PromoOut>(`/admin/promo-codes/${pid}`, body),
  deletePromo: (pid: string) =>
    api.delete<unknown>(`/admin/promo-codes/${pid}`),

  // ─── Banners ───
  listBanners: () => api.get<BannerOut[]>("/admin/banners"),
  createBanner: (body: BannerCreate) =>
    api.post<BannerOut>("/admin/banners", body),
  updateBanner: (bid: string, body: BannerUpdate) =>
    api.patch<BannerOut>(`/admin/banners/${bid}`, body),
  deleteBanner: (bid: string) =>
    api.delete<unknown>(`/admin/banners/${bid}`),
};