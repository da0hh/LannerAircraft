export const GENDER_OPTIONS = [
  { value: "male", label: "Мужской" },
  { value: "female", label: "Женский" },
  { value: "unisex", label: "Унисекс" },
];

export const FIT_OPTIONS = [
  { value: "classic", label: "Классический" },
  { value: "oversize", label: "Оверсайз" },
  { value: "slim", label: "Приталенный" },
];

export const NECKLINE_OPTIONS = [
  { value: "round", label: "Круглый" },
  { value: "v", label: "V-образный" },
  { value: "polo", label: "Поло" },
];

export const TYPE_OPTIONS = [
  { value: "basic", label: "Базовая" },
  { value: "print", label: "С принтом" },
];

export const SORT_OPTIONS = [
  { value: "popular", label: "Популярные" },
  { value: "price_asc", label: "Сначала дешёвые" },
  { value: "price_desc", label: "Сначала дорогие" },
  { value: "new", label: "Новинки" },
] as const;

export const COLOR_OPTIONS = [
  { value: "Чёрный", hex: "#000000" },
  { value: "Белый", hex: "#FFFFFF" },
  { value: "Серый", hex: "#808080" },
];

export const SIZE_OPTIONS = ["XS", "S", "M", "L", "XL", "2XL", "3XL", "4XL", "5XL", "6XL"];
