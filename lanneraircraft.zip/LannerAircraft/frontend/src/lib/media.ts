export function toMediaUrl(src?: string | null): string {
  if (!src) return '';
  if (src.startsWith('/media/')) return src;
  const m = src.match(/\/media\/.+$/);
  if (m) return m[0];
  if (/^https?:\/\//i.test(src)) return src;
  return `/media/${src.replace(/^\//, '')}`;
}