export const tg = window.Telegram?.WebApp;

/** Проверка поддерживаемой версии Bot API */
function versionAtLeast(target: string): boolean {
  if (!tg?.version) return false;
  const cur = tg.version.split(".").map(Number);
  const req = target.split(".").map(Number);
  for (let i = 0; i < req.length; i++) {
    if ((cur[i] ?? 0) > (req[i] ?? 0)) return true;
    if ((cur[i] ?? 0) < (req[i] ?? 0)) return false;
  }
  return true;
}

const HAPTIC_SUPPORTED = () => !!tg?.HapticFeedback && versionAtLeast("6.1");

/* ---------- Init ---------- */

export function initTelegram() {
  if (!tg) return;
  try {
    tg.ready();
    tg.expand();
    // header color тоже под защитой версии
    if (versionAtLeast("6.1")) {
      try { tg.setHeaderColor("bg_color"); } catch { /* ignore */ }
    }
  } catch { /* ignore */ }
}

/* ---------- Init data (для авторизации) ---------- */

export function getInitData(): string {
  return tg?.initData ?? "";
}

export function getInitDataUnsafe() {
  return tg?.initDataUnsafe ?? null;
}

/* ---------- Haptic ---------- */

export function haptic(
  style: "light" | "medium" | "heavy" | "rigid" | "soft" = "medium"
) {
  if (HAPTIC_SUPPORTED()) {
    try { tg!.HapticFeedback.impactOccurred(style); } catch { /* ignore */ }
  }
}

export function hapticSuccess() {
  if (HAPTIC_SUPPORTED()) {
    try { tg!.HapticFeedback.notificationOccurred("success"); } catch { /* ignore */ }
  }
}

export function hapticError() {
  if (HAPTIC_SUPPORTED()) {
    try { tg!.HapticFeedback.notificationOccurred("error"); } catch { /* ignore */ }
  }
}

export function hapticWarning() {
  if (HAPTIC_SUPPORTED()) {
    try { tg!.HapticFeedback.notificationOccurred("warning"); } catch { /* ignore */ }
  }
}

export function hapticSelection() {
  if (HAPTIC_SUPPORTED()) {
    try { tg!.HapticFeedback.selectionChanged(); } catch { /* ignore */ }
  }
}

/* ---------- Header / background color ---------- */

export function setHeaderColor(color: string) {
  if (tg && versionAtLeast("6.1")) {
    try { tg.setHeaderColor(color as `#${string}`); } catch { /* ignore */ }
  }
}

export function setBackgroundColor(color: string) {
  if (tg && versionAtLeast("6.1")) {
    try { tg.setBackgroundColor(color as `#${string}`); } catch { /* ignore */ }
  }
}

/* ---------- Back button ---------- */

export const backButton = {
  show(onClick: () => void) {
    if (tg?.BackButton && versionAtLeast("6.1")) {
      try {
        tg.BackButton.onClick(onClick);
        tg.BackButton.show();
      } catch { /* ignore */ }
    }
  },
  hide(onClick: () => void) {
    if (tg?.BackButton && versionAtLeast("6.1")) {
      try {
        tg.BackButton.offClick(onClick);
        tg.BackButton.hide();
      } catch { /* ignore */ }
    }
  },
};