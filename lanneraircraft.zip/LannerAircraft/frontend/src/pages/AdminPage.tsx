import { useState } from "react";
import { AdminGuard } from "@/components/AdminGuard";
import { AdminOrders } from "@/components/admin/AdminOrders";
import { AdminCategories } from "@/components/admin/AdminCategories";
import { AdminBanners } from "@/components/admin/AdminBanners";
import { AdminPromos } from "@/components/admin/AdminPromos";
import { AdminProducts } from "@/components/admin/AdminProducts";

type Tab = "orders" | "products" | "categories" | "promos" | "banners";

export function AdminPage() {
  const [tab, setTab] = useState<Tab>("orders");

  return (
    <AdminGuard>
      <div className="page admin">
        <h2 className="page__title">Администрирование</h2>

        <div className="admin__tabs">
          <button
            className={`admin__tab ${tab === "orders" ? "is-active" : ""}`}
            onClick={() => setTab("orders")}
          >
            Заказы
          </button>
          <button
            className={`admin__tab ${tab === "products" ? "is-active" : ""}`}
            onClick={() => setTab("products")}
          >
            Товары
          </button>
          <button
            className={`admin__tab ${tab === "categories" ? "is-active" : ""}`}
            onClick={() => setTab("categories")}
          >
            Категории
          </button>
          <button
            className={`admin__tab ${tab === "promos" ? "is-active" : ""}`}
            onClick={() => setTab("promos")}
          >
            Промокоды
          </button>
          <button
            className={`admin__tab ${tab === "banners" ? "is-active" : ""}`}
            onClick={() => setTab("banners")}
          >
            Баннеры
          </button>
        </div>

        <div className="admin__content">
          {tab === "orders" && <AdminOrders />}
          {tab === "products" && <AdminProducts />}
          {tab === "categories" && <AdminCategories />}
          {tab === "promos" && <AdminPromos />}
          {tab === "banners" && <AdminBanners />}
        </div>
      </div>
    </AdminGuard>
  );
}