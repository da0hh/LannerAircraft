import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useCart } from "@/store/cart";
import { QuantityStepper } from "@/components/QuantityStepper";
import { Loader } from "@/components/Loader";
import { formatPrice } from "@/lib/format";
import { tg, haptic } from "@/lib/telegram";

export function CartPage() {
  const { cart, loading, fetch, updateQty, remove } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    fetch();
  }, [fetch]);

  const hasItems = !!cart && cart.items.length > 0;

  useEffect(() => {
    if (!tg) return;
    if (hasItems && cart) {
      tg.MainButton.setText(`Оформить · ${formatPrice(cart.subtotal)}`);
      tg.MainButton.enable();
      tg.MainButton.show();
      const onClick = () => navigate("/checkout");
      tg.MainButton.onClick(onClick);
      return () => {
        tg.MainButton.offClick(onClick);
        tg.MainButton.hide();
      };
    }
    tg.MainButton.hide();
  }, [hasItems, cart, navigate]);

  if (loading && !cart) return <Loader full />;

  if (!hasItems || !cart) {
    return (
      <div className="page empty-page">
        <div className="empty">Корзина пуста 🛒</div>
      </div>
    );
  }

  return (
    <div className="page cart">
      <h1 className="page__title">Корзина</h1>
      <div className="cart__list">
        {cart.items.map((item) => (
          <div key={item.id} className="cart-item">
            <div className="cart-item__img">
              {item.image ? <img src={item.image} alt="" /> : <div className="card__placeholder" />}
            </div>
            <div className="cart-item__body">
              <div className="cart-item__name">{item.product_name}</div>
              <div className="cart-item__meta">
                {item.color_name} · {item.size_label}
              </div>
              <div className="cart-item__price">
                {formatPrice(item.unit_price)}
              </div>
              <div className="cart-item__controls">
                <QuantityStepper
                  value={item.quantity}
                  max={item.stock}
                  onChange={(q) => updateQty(item.id, q)}
                />
                <button
                  className="cart-item__remove"
                  onClick={() => {
                    haptic("medium");
                    remove(item.id);
                  }}
                >
                  Удалить
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="cart__summary">
        <span>Итого</span>
        <span>{formatPrice(cart.subtotal)}</span>
      </div>
    </div>
  );
}