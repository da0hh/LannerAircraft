import { useState } from "react";
import { useProducts, useCategories } from "@/hooks/useProducts";
import { useBanners } from "@/hooks/useBanners";
import { ProductCard } from "@/components/ProductCard";
import { BannerCarousel } from "@/components/Banner";
import { Loader } from "@/components/Loader";
import { FiltersSheet } from "@/components/FiltersSheet";
import { SizeGuide } from "@/components/SizeGuide";
import { haptic } from "@/lib/telegram";
import { useUi } from "@/store/ui";
import { useFilters, appliedToParams } from "@/store/filters";
import { useSearchParams } from "react-router-dom";

export function CatalogPage() {
  const [searchParams] = useSearchParams();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string | undefined>(
    searchParams.get("category") ?? undefined
  );
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false);

  const { data: categories } = useCategories();
  const { data: banners } = useBanners();

  const applied = useFilters((s) => s.applied);
  const activeCount = useFilters((s) => s.activeCount());
  const openDraftFromApplied = useFilters((s) => s.openDraftFromApplied);

  const { data, isLoading } = useProducts({
    category_id: category,
    search: search || undefined,
    ...appliedToParams(applied),
  });
  const products = data?.items;

  const filtersOpen = useUi((s) => s.filtersOpen);
  const openFilters = useUi((s) => s.openFilters);
  const closeFilters = useUi((s) => s.closeFilters);

  const handleOpenFilters = () => {
    haptic("light");
    openDraftFromApplied();
    openFilters();
  };

  return (
    <div className="page catalog">
      <div className="search">
        <input
          type="text"
          placeholder="Поиск товаров…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Категории быстрым рядом + кнопка Фильтры */}
      <div className="catalog__toolbar">
        <div className="chips chips--scroll">
          <button
            className={`chip ${!category ? "chip--active" : ""}`}
            onClick={() => { haptic("light"); setCategory(undefined); }}
          >
            Все
          </button>
          {categories?.map((c) => (
            <button
              key={c.id}
              className={`chip ${category === c.id ? "chip--active" : ""}`}
              onClick={() => { haptic("light"); setCategory(c.id); }}
            >
              {c.name}
            </button>
          ))}
        </div>
        <button className="filters-btn" onClick={handleOpenFilters}>
          Фильтры{activeCount > 0 ? ` · ${activeCount}` : ""}
        </button>
      </div>

      {banners && <BannerCarousel banners={banners} />}

      {isLoading ? (
        <Loader />
      ) : products && products.length > 0 ? (
        <div className="grid">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      ) : (
        <div className="empty">Ничего не найдено</div>
      )}

      {filtersOpen && (
        <FiltersSheet
          onClose={closeFilters}
          onOpenSizeGuide={() => setSizeGuideOpen(true)}
        />
      )}

      {sizeGuideOpen && <SizeGuide onClose={() => setSizeGuideOpen(false)} />}
    </div>
  );
}