import { useNavigate } from "react-router-dom";
import { useCategories } from "@/hooks/useProducts";
import { Loader } from "@/components/Loader";
import { haptic } from "@/lib/telegram";

export function CategoriesPage() {
  const { data: categories, isLoading } = useCategories();
  const navigate = useNavigate();

  return (
    <div className="page categories">
      <h2 className="page__title">Категории</h2>
      {isLoading ? (
        <Loader />
      ) : (
        <div className="category-list">
          <button
            className="category-list__item"
            onClick={() => { haptic("light"); navigate("/"); }}
          >
            Все товары
          </button>
          {categories?.map((c) => (
            <button
              key={c.id}
              className="category-list__item"
              onClick={() => {
                haptic("light");
                navigate(`/?category=${c.id}`);
              }}
            >
              {c.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}