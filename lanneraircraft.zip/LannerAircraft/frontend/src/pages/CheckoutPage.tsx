import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCart } from "@/store/cart";
import { useUi } from "@/store/ui";
import { api } from "@/lib/api";
import { formatPrice } from "@/lib/format";
import { tg, haptic, hapticSuccess, hapticError } from "@/lib/telegram";
import type { DeliveryMethod, DeliveryOption } from "@/types";

interface CheckoutResponse {
  order_number: number;
  invoice_url: string;
}

export function CheckoutPage() {
  const { cart, fetch, clear } = useCart();
  const notify = useUi((s) => s.notify);
  const navigate = useNavigate();

  const [method, setMethod] = useState<DeliveryMethod>("courier");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [pvz, setPvz] = useState("");
  const [comment, setComment] = useState("");
  const [promo, setPromo] = useState("");
  const [promoInfo, setPromoInfo] = useState<{ valid: boolean; discount?: string } | null>(null);
  const [options, setOptions] = useState<DeliveryOption[]>([]);

  useEffect(() => { fetch(); }, [fetch]);

  useEffect(() => {
    api.get<DeliveryOption[]>("/delivery/options").then(setOptions).catch(() => {});
  }, []);

  const deliveryCost = useMemo(() => {
    const opt = options.find((o) => o.method === method);
    return opt ? parseFloat(opt.cost) : 0;
  }, [options, method]);

  const subtotal = cart ? parseFloat(cart.subtotal) : 0;
  const discount = promoInfo?.valid ? parseFloat(promoInfo.discount ?? "0") : 0;
  const total = Math.max(0, subtotal - discount) + deliveryCost;

  const checkPromo = async () => {
    if (!promo.trim()) return;
    try {
      const res = await api.post<{ valid: boolean; discount: string }>(
        "/promo/validate",
        { code: promo.trim(), subtotal: cart?.subtotal }
      );
      setPromoInfo(res);
      if (res.valid) { hapticSuccess(); notify("Промокод применён", "success"); }
      else { hapticError(); notify("Промокод недействителен", "error"); }
    } catch {
      hapticError();
      notify("Ошибка проверки промокода", "error");
    }
  };

  const valid =
    firstName.trim() && lastName.trim() && phone.trim() &&
    (method === "courier" ? address.trim() : true) &&
    (method === "cdek" ? pvz.trim() : true) &&
    (cart?.items.length ?? 0) > 0;

  const submit = async () => {
    if (!valid) return;
    try {
      tg?.MainButton.showProgress();
      const res = await api.post<CheckoutResponse>("/orders/checkout", {
        delivery: {
          method,
          first_name: firstName,
          last_name: lastName,
          phone,
          address: method === "courier" ? address : null,
          pvz_code: method === "cdek" ? pvz : null,
          comment: comment || null,
        },
        promo_code: promoInfo?.valid ? promo.trim() : null,
      });

      hapticSuccess();
      // Открытие Telegram Invoice
      if (tg?.openInvoice) {
        tg.openInvoice(res.invoice_url, async (status) => {
          if (status === "paid") {
            await clear();
            notify("Заказ оплачен!", "success");
            navigate("/orders");
          } else if (status === "failed") {
            notify("Оплата не прошла", "error");
          }
        });
      } else {
        notify(`Заказ №${res.order_number} создан`, "success");
        navigate("/orders");
      }
    } catch {
      hapticError();
      notify("Не удалось оформить заказ", "error");
    } finally {
      tg?.MainButton.hideProgress();
    }
  };

  useEffect(() => {
    if (!tg) return;
    tg.MainButton.setText(`Оплатить · ${formatPrice(total)}`);
    if (valid) tg.MainButton.enable(); else tg.MainButton.disable();
    tg.MainButton.show();
    tg.MainButton.onClick(submit);
    return () => {
      tg.MainButton.offClick(submit);
      tg.MainButton.hide();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [valid, total, method, firstName, lastName, phone, address, pvz, comment, promoInfo]);

  return (
    <div className="page checkout">
      <h1 className="page__title">Оформление</h1>

      <section className="form-block">
        <h2>Способ доставки</h2>
        <div className="delivery-methods">
          {options.map((o) => (
            <button
              key={o.method}
              className={`delivery-method ${method === o.method ? "delivery-method--active" : ""}`}
              onClick={() => { haptic("light"); setMethod(o.method); }}
            >
              <span>{o.title}</span>
              <span>{parseFloat(o.cost) === 0 ? "Бесплатно" : formatPrice(o.cost)}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="form-block">
        <h2>Получатель</h2>
        <input placeholder="Имя" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
        <input placeholder="Фамилия" value={lastName} onChange={(e) => setLastName(e.target.value)} />
        <input placeholder="Телефон" value={phone} inputMode="tel" onChange={(e) => setPhone(e.target.value)} />

        {method === "courier" && (
          <input placeholder="Адрес доставки" value={address} onChange={(e) => setAddress(e.target.value)} />
        )}
        {method === "cdek" && (
          <input placeholder="Код ПВЗ СДЭК" value={pvz} onChange={(e) => setPvz(e.target.value)} />
        )}
        <textarea placeholder="Комментарий (необязательно)" value={comment} onChange={(e) => setComment(e.target.value)} />
      </section>

      <section className="form-block">
        <h2>Промокод</h2>
        <div className="promo-row">
          <input placeholder="Введите код" value={promo} onChange={(e) => { setPromo(e.target.value); setPromoInfo(null); }} />
          <button onClick={checkPromo}>Применить</button>
        </div>
        {promoInfo?.valid && <div className="promo-ok">Скидка {formatPrice(promoInfo.discount ?? "0")}</div>}
      </section>

      <section className="summary">
        <div className="summary__row"><span>Товары</span><span>{formatPrice(subtotal)}</span></div>
        {discount > 0 && <div className="summary__row summary__row--discount"><span>Скидка</span><span>−{formatPrice(discount)}</span></div>}
        <div className="summary__row"><span>Доставка</span><span>{deliveryCost === 0 ? "Бесплатно" : formatPrice(deliveryCost)}</span></div>
        <div className="summary__row summary__row--total"><span>Итого</span><span>{formatPrice(total)}</span></div>
      </section>
    </div>
  );
}