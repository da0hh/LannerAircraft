import { useEffect } from "react";
import { useFavorites } from "@/store/favourites";
import { ProductCard } from "@/components/ProductCard";
import { Loader } from "@/components/Loader";
import type { ProductListItem } from "@/types";

export function FavoritesPage() {
  const items = useFavorites((s) => s.items);
  const loading = useFavorites((s) => s.loading);
  const fetch = useFavorites((s) => s.fetch);

  useEffect(() => {
    fetch();
  }, [fetch]);

  // приводим FavoriteOut -> ProductListItem, чтобы ProductCard рендерился как на главной
  const products: ProductListItem[] = (items ?? []).map((f) => ({
    id: f.id,
    name: (f as any).name,
    price: (f as any).price,
    image: (f as any).image ?? (f as any).image_url ?? null,
    in_stock: (f as any).in_stock ?? true,
  })) as ProductListItem[];

  return (
    <div className="page catalog">
      <div className="page__header">
        <h1>Избранное</h1>
      </div>

      {loading ? (
        <Loader />
      ) : products.length > 0 ? (
        <div className="grid">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      ) : (
        <div className="empty">В избранном пока пусто ♡</div>
      )}
    </div>
  );
}