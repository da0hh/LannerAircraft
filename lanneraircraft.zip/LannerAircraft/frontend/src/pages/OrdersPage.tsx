import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Loader } from "@/components/Loader";
import { formatPrice, orderStatusLabel, formatDate } from "@/lib/format";
import type { Order } from "@/types";

export function OrdersPage() {
  const { data: orders, isLoading } = useQuery({
    queryKey: ["orders"],
    queryFn: () => api.get<Order[]>("/orders"),
  });

  if (isLoading) return <Loader full />;

  return (
    <div className="page orders">
      <h1 className="page__title">Мои заказы</h1>
      {orders && orders.length > 0 ? (
        <div className="orders__list">
          {orders.map((o) => (
            <div key={o.id} className="order-card">
              <div className="order-card__head">
                <span className="order-card__num">Заказ №{o.number}</span>
                <span className={`order-status order-status--${o.status}`}>
                  {orderStatusLabel(o.status)}
                </span>
              </div>
              <div className="order-card__date">{formatDate(o.created_at)}</div>
              <div className="order-card__items">
                {o.items.map((it, i) => (
                  <div key={i} className="order-line">
                    <div className="order-line__img">
                      {it.image_url ? <img src={it.image_url} alt="" /> : <div className="card__placeholder" />}
                    </div>
                    <div className="order-line__body">
                      <div>{it.product_name}</div>
                      <div className="order-line__meta">
                        {it.color_name} · {it.size_label} · {it.quantity} шт.
                      </div>
                    </div>
                    <div className="order-line__price">{formatPrice(it.unit_price)}</div>
                  </div>
                ))}
              </div>
              {o.delivery?.tracking && (
                <div className="order-card__track">Трек: {o.delivery.tracking}</div>
              )}
              <div className="order-card__total">
                <span>Итого</span>
                <span>{formatPrice(o.total)}</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty">Заказов пока нет 📦</div>
      )}
    </div>
  );
}