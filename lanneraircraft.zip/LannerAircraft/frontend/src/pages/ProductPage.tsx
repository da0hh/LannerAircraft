import { useEffect, useMemo, useState } from "react";
import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import { useProduct } from "@/hooks/useProduct";
import { Loader } from "@/components/Loader";
import { ColorPicker } from "@/components/ColorPicker";
import { SizePicker } from "@/components/SizePicker";
import { QuantityStepper } from "@/components/QuantityStepper";
import { Accordion } from "@/components/Accordion";
import { formatPrice } from "@/lib/format";
import { useCart } from "@/store/cart";
import { useFavorites } from "@/store/favourites";
import { useUi } from "@/store/ui";
import { tg, haptic, hapticSuccess } from "@/lib/telegram";
import { toMediaUrl } from "@/lib/media";

export function ProductPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { data: product, isLoading } = useProduct(id);
  const add = useCart((s) => s.addItem);
  const { has, toggle } = useFavorites();
  const notify = useUi((s) => s.notify);

  const [searchParams] = useSearchParams();
  const shouldPick = searchParams.get("pick") === "1";

  const [colorId, setColorId] = useState<string | null>(null);
  const [sizeId, setSizeId] = useState<string | null>(null);
  const [qty, setQty] = useState(1);
  const [imgIndex, setImgIndex] = useState(0);
  const [imgError, setImgError] = useState(false);

  // Скролл к выбору при pick=1
  useEffect(() => {
    if (shouldPick && product) {
      haptic("light");
      const el = document.querySelector(".product__info");
      el?.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [shouldPick, product]);

  // Сброс ошибки картинки при смене изображения
  useEffect(() => {
    setImgError(false);
  }, [imgIndex, product]);

  // Доступные размеры для выбранного цвета
  const availableSizeIds = useMemo(() => {
    if (!product) return new Set<string>();
    return new Set(
      product.variants
        .filter((v) => (colorId ? v.color_id === colorId : true) && v.stock > 0)
        .map((v) => v.size_id)
    );
  }, [product, colorId]);

  const selectedVariant = useMemo(() => {
    if (!product || !colorId || !sizeId) return null;
    return product.variants.find(
      (v) => v.color_id === colorId && v.size_id === sizeId
    );
  }, [product, colorId, sizeId]);

  const canAdd = !!selectedVariant && selectedVariant.stock >= qty;

  // MainButton
  useEffect(() => {
    if (!tg) return;
    tg.MainButton.setText(
      canAdd ? `В корзину · ${formatPrice(product?.price ?? "0")}` : "Выберите цвет и размер"
    );
    if (canAdd) tg.MainButton.enable();
    else tg.MainButton.disable();
    tg.MainButton.show();

    const onClick = async () => {
      if (!canAdd || !selectedVariant) return;
      try {
        tg.MainButton.showProgress();
        await add(selectedVariant.id, qty);
        hapticSuccess();
        notify("Добавлено в корзину", "success");
      } catch {
        notify("Не удалось добавить", "error");
      } finally {
        tg.MainButton.hideProgress();
      }
    };
    tg.MainButton.onClick(onClick);
    return () => {
      tg.MainButton.offClick(onClick);
      tg.MainButton.hide();
    };
  }, [canAdd, selectedVariant, qty, product, add, notify]);

  if (isLoading || !product) return <Loader full />;

  const fav = has(product.id);
  const mainImg = toMediaUrl(product.images[imgIndex]?.url);

  return (
    <div className="page product">
      <div className="gallery">
        <div className="gallery__main">
          {mainImg && !imgError ? (
            <img
              src={mainImg}
              alt={product.name}
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="card__placeholder" />
          )}
          <button
            className={`gallery__fav ${fav ? "gallery__fav--active" : ""}`}
            onClick={() => { haptic("medium"); toggle(product.id); }}
          >
            {fav ? "♥" : "♡"}
          </button>
        </div>

        {product.images.length > 1 && (
          <div className="gallery__thumbs">
            {product.images.map((img, i) => (
              <button
                key={i}
                className={`thumb ${i === imgIndex ? "thumb--active" : ""}`}
                onClick={() => setImgIndex(i)}
              >
                <img src={toMediaUrl(img.url)} alt="" />
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="product__info">
        <h1 className="product__name">{product.name}</h1>
        <div className="product__price">{formatPrice(product.price)}</div>
        <div className="product__sku">Артикул: {product.sku}</div>

        <ColorPicker
          colors={product.colors}
          selected={colorId}
          onSelect={(id) => { setColorId(id); setSizeId(null); }}
        />
        <SizePicker
          sizes={product.sizes}
          selected={sizeId}
          availableSizeIds={availableSizeIds}
          onSelect={setSizeId}
        />

        <div className="product__qty">
          <span>Количество</span>
          <QuantityStepper
            value={qty}
            max={selectedVariant?.stock ?? 99}
            onChange={setQty}
          />
        </div>

        <button
          className="product__add-btn"
          onClick={async () => {
            if (!colorId) {
              haptic("medium");
              notify("Выберите цвет", "error");
              return;
            }
            if (!sizeId) {
              haptic("medium");
              notify("Выберите размер", "error");
              return;
            }
            if (!selectedVariant || selectedVariant.stock < qty) {
              haptic("medium");
              notify("Нет в наличии", "error");
              return;
            }
            try {
              haptic("medium");
              await add(selectedVariant.id, qty);
              hapticSuccess();
              notify("Добавлено в корзину", "success");
            } catch (err) {
              console.error("ADD TO CART ERROR:", err);
              notify("Не удалось добавить", "error");
            }
          }}
        >
          В корзину · {formatPrice(product.price)}
        </button>

        {selectedVariant && selectedVariant.stock < 5 && (
          <div className="product__stock-warn">
            Осталось всего {selectedVariant.stock} шт.
          </div>
        )}

        <div className="product__accordions">
          <Accordion title="Описание" defaultOpen>
            <p>{product.description}</p>
          </Accordion>
          <Accordion title="Характеристики">
            <ul className="specs">
              <li><span>Состав</span><span>{product.composition}</span></li>
              <li><span>Плотность</span><span>{product.density}</span></li>
            </ul>
          </Accordion>
          <Accordion title="Уход">
            <p>{product.care}</p>
          </Accordion>
        </div>
      </div>
    </div>
  );
}