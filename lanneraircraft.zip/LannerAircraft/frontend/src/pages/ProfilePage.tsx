import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { haptic } from "@/lib/telegram";
import { clearToken } from "@/lib/api";

export function ProfilePage() {
  const navigate = useNavigate();
  const { user, ready } = useAuth();

  const u = user as (typeof user & {
    first_name?: string;
    last_name?: string;
    username?: string;
    is_admin?: boolean;
  }) | null;

  const name =
    [u?.first_name, u?.last_name].filter(Boolean).join(" ") ||
    u?.username ||
    "Гость";

  const go = (to: string) => {
    haptic("light");
    navigate(to);
  };

  const logout = () => {
    haptic("medium");
    clearToken();
    // перезагружаем приложение, чтобы сбросить состояние авторизации
    window.location.reload();
  };

  return (
    <div className="page profile">
      <h2 className="page__title">Профиль</h2>

      <div className="profile__card">
        <div className="profile__avatar">
          {name.slice(0, 1).toUpperCase()}
        </div>
        <div className="profile__name">{ready ? name : "…"}</div>
        {u?.username && <div className="profile__username">@{u.username}</div>}
      </div>

      <div className="profile__menu">
        <button className="profile__item" onClick={() => go("/orders")}>
          Мои заказы
        </button>
        <button className="profile__item" onClick={() => go("/favorites")}>
          Избранное
        </button>

        {/* Кнопка админки — видна только админам */}
        {u?.is_admin && (
          <button className="profile__item" onClick={() => go("/admin")}>
            Админ-панель
          </button>
        )}
      </div>
    </div>
  );
}