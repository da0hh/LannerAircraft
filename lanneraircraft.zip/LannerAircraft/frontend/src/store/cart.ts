import { create } from "zustand";
import { api } from "@/lib/api";
import type { components } from "@/api/schema";

type CartOut = components["schemas"]["CartOut"];

interface CartState {
  cart: CartOut | null;
  loading: boolean;
  fetch: () => Promise<void>;
  addItem: (variantId: string, quantity?: number) => Promise<void>;
  updateQty: (itemId: string, quantity: number) => Promise<void>;
  remove: (itemId: string) => Promise<void>;
}

export const useCart = create<CartState>((set) => ({
  cart: null,
  loading: false,

  fetch: async () => {
    set({ loading: true });
    try {
      const cart = await api.get<CartOut>("/cart");
      set({ cart });
    } finally {
      set({ loading: false });
    }
  },

  addItem: async (variantId, quantity = 1) => {
    const cart = await api.post<CartOut>("/cart/items", {
      variant_id: variantId,
      quantity,
    });
    set({ cart });
  },

  updateQty: async (itemId, quantity) => {
    const cart = await api.patch<CartOut>(`/cart/items/${itemId}`, {
      quantity,
    });
    set({ cart });
  },

  remove: async (itemId) => {
    const cart = await api.delete<CartOut>(`/cart/items/${itemId}`);
    set({ cart });
  },
}));