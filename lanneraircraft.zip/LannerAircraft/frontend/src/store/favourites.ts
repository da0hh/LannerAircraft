import { create } from "zustand";
import { api } from "@/lib/api";
import type { components } from "@/api/schema";

type FavoriteOut = components["schemas"]["FavoriteOut"];

interface FavoritesState {
  items: FavoriteOut[];
  loading: boolean;
  fetch: () => Promise<void>;
  add: (productId: string) => Promise<void>;
  remove: (productId: string) => Promise<void>;
  has: (productId: string) => boolean;
  toggle: (productId: string) => Promise<void>;
}

export const useFavorites = create<FavoritesState>((set, get) => ({
  items: [],
  loading: false,

  fetch: async () => {
    set({ loading: true });
    try {
      const items = await api.get<FavoriteOut[]>("/favorites");
      set({ items: items ?? [] });
    } finally {
      set({ loading: false });
    }
  },

  add: async (productId) => {
    await api.post(`/favorites/${productId}`);
    await get().fetch();
  },

  remove: async (productId) => {
    await api.delete(`/favorites/${productId}`);
    set({ items: get().items.filter((f) => f.id !== productId) });
  },

  has: (productId) => get().items.some((f) => f.id === productId),

  toggle: async (productId) => {
    if (get().has(productId)) {
      await get().remove(productId);
    } else {
      await get().add(productId);
    }
  },
}));