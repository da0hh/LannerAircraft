import { create } from "zustand";
import type { CatalogParams } from "@/hooks/useProducts";

export type FilterState = {
  gender: string[];
  fit: string[];
  type: string[];
  neckline: string[];
  color: string[];
  variant_size: string[];
  price_min?: number;
  price_max?: number;
  sort: NonNullable<CatalogParams["sort"]>;
};

const EMPTY: FilterState = {
  gender: [],
  fit: [],
  type: [],
  neckline: [],
  color: [],
  variant_size: [],
  price_min: undefined,
  price_max: undefined,
  sort: "popular",
};

type Store = {
  applied: FilterState;
  draft: FilterState;
  setDraft: (patch: Partial<FilterState>) => void;
  toggleArray: (key: keyof FilterState, value: string) => void;
  apply: () => void;
  reset: () => void;
  openDraftFromApplied: () => void;
  activeCount: () => number;
};

export const useFilters = create<Store>((set, get) => ({
  applied: EMPTY,
  draft: EMPTY,

  setDraft: (patch) => set((s) => ({ draft: { ...s.draft, ...patch } })),

  toggleArray: (key, value) =>
    set((s) => {
      const cur = s.draft[key] as string[];
      const next = cur.includes(value)
        ? cur.filter((x) => x !== value)
        : [...cur, value];
      return { draft: { ...s.draft, [key]: next } };
    }),

  apply: () => set((s) => ({ applied: s.draft })),

  reset: () => set({ draft: EMPTY }),

  openDraftFromApplied: () => set((s) => ({ draft: s.applied })),

  activeCount: () => {
    const a = get().applied;
    let n = 0;
    n += a.gender.length + a.fit.length + a.type.length + a.neckline.length;
    n += a.color.length + a.variant_size.length;
    if (a.price_min !== undefined) n++;
    if (a.price_max !== undefined) n++;
    return n;
  },
}));

export function appliedToParams(a: FilterState): Partial<CatalogParams> {
  return {
    gender: a.gender.length ? a.gender : undefined,
    fit: a.fit.length ? a.fit : undefined,
    type: a.type.length ? a.type : undefined,
    neckline: a.neckline.length ? a.neckline : undefined,
    color: a.color.length ? a.color : undefined,
    variant_size: a.variant_size.length ? a.variant_size : undefined,
    price_min: a.price_min,
    price_max: a.price_max,
    sort: a.sort,
  };
}