import { create } from "zustand";

export interface Toast {
  id: string;
  message: string;
  type: "info" | "success" | "error";
}

interface UiState {
  toasts: Toast[];
  notify: (message: string, type?: Toast["type"]) => void;
  dismiss: (id: string) => void;

  filtersOpen: boolean;
  openFilters: () => void;
  toggleFilters: () => void;
  closeFilters: () => void;
}

export const useUi = create<UiState>((set) => ({
  toasts: [],
  notify: (message, type = "info") => {
    const id = Math.random().toString(36).slice(2);
    set((s) => ({ toasts: [...s.toasts, { id, message, type }] }));
    setTimeout(() => {
      set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }));
    }, 3000);
  },
  dismiss: (id) =>
    set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),

  filtersOpen: false,
  openFilters: () => set({ filtersOpen: true }),
  toggleFilters: () => set((s) => ({ filtersOpen: !s.filtersOpen })),
  closeFilters: () => set({ filtersOpen: false }),
}));