import type { components } from "@/api/schema";

type S = components["schemas"];

export type UserOut = S["UserOut"];
export type AuthResponse = S["AuthResponse"];
export type TelegramAuthRequest = S["TelegramAuthRequest"];

export type CategoryOut = S["CategoryOut"];
export type ProductListItem = S["ProductListItem"];
export type ProductDetail = S["ProductDetail"];
export type ColorOut = S["ColorOut"];
export type ImageOut = S["ImageOut"];
export type SizeOut = S["SizeOut"];
export type VariantOut = S["VariantOut"];
export type ProductsPage = S["Page_ProductListItem_"];

export type CartOut = S["CartOut"];
export type CartItemOut = S["CartItemOut"];
export type AddItemRequest = S["AddItemRequest"];
export type UpdateItemRequest = S["UpdateItemRequest"];
export type ApplyPromoRequest = S["ApplyPromoRequest"];
export type PromoResult = S["PromoResult"];

// --- Favorites ---
export type FavoriteOut = S["FavoriteOut"];

// --- Delivery / Orders ---
export type DeliveryOption = S["DeliveryOption"];
export type DeliveryInput = S["DeliveryInput"];
export type DeliveryMethod = S["DeliveryMethod"];
export type OrderOut = S["OrderOut"];
export type OrderItemOut = S["OrderItemOut"];
export type OrderStatus = S["OrderStatus"];
export type OrderCreateRequest = S["OrderCreateRequest"];

export type CreatePaymentRequest = S["CreatePaymentRequest"];
export type CreatePaymentResponse = S["CreatePaymentResponse"];

export type BannerOut = S["BannerOut"];

export type Money = string;
export type UUID = string;

export interface ApiErrorShape {
  code: string;
  message: string;
  details?: unknown;
}